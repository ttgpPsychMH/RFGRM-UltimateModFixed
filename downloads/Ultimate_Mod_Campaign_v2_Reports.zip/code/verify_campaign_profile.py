#!/usr/bin/env python3
"""Independently check the moderated archives against originals and prior release."""
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from verify_balance import read_raw, values, relations, index_elements

BASE = Path('/workspace/rfgrm-vpp-analysis')
OUT = BASE / 'campaign_profile'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def normalized(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def main():
    audit = json.loads((OUT / 'parameters.json').read_text())
    grouped = defaultdict(dict)
    for r in audit:
        require(r['path'] not in grouped[r['package'], r['file']], 'Duplicate audit path')
        grouped[r['package'], r['file']][r['path']] = r
    report = dict(status='passed', packages={}, changed_values=0, preserved_values=0,
                  arithmetic_values=0, spawn_fields=0, representative_checks=[],
                  game_runtime_tested=False)
    payloads = {}
    for pkg in ('misc', 'table'):
        after = read_raw(OUT / 'game_files' / (pkg + '.vpp_pc'))
        before = read_raw(BASE / 'comfort_review_10ms/game_files' / (pkg + '.vpp_pc'))
        payloads[pkg] = after
        require(after.keys() == before.keys(), 'Filename set changed')
        original_dir = BASE / ('ultimate_mod_misc/original' if pkg == 'misc' else 'table/original')
        detail = dict(file_count=len(after), xml_valid=0, xml_exceptions={},
                      changed_files=[], unchanged_binary_assets=0,
                      no_new_min_max_violations=True, blast_companions_checked=0)
        for name, blob in after.items():
            require(blob == (OUT / 'roundtrip' / pkg / name).read_bytes(), 'Independent extraction mismatch')
            require(blob == (OUT / 'extracted' / pkg / name).read_bytes(), 'Generated extraction mismatch')
            events = grouped.get((pkg, name), {})
            expected_changes = {path for path, r in events.items() if r['planned'] != r['previous_release']}
            if not expected_changes:
                require(blob == before[name], 'Unexpected byte change: ' + name)
            if blob != before[name]:
                detail['changed_files'].append(name)
            if not name.endswith('.xtbl'):
                require(blob == before[name], 'Binary asset changed')
                detail['unchanged_binary_assets'] += 1
                continue
            original_blob = (original_dir / name).read_bytes()
            try:
                tree = ET.fromstring(blob)
            except ET.ParseError as error:
                require(name == 'credits.xtbl' and blob == before[name] == original_blob,
                        'New XML failure: ' + name)
                detail['xml_exceptions'][name] = str(error)
                continue
            detail['xml_valid'] += 1
            if not events:
                continue
            old_tree, original_tree = ET.fromstring(before[name]), ET.fromstring(original_blob)
            current, prior, original = values(tree), values(old_tree), values(original_tree)
            require(current.keys() == prior.keys(), 'XML structure changed: ' + name)
            actual_changes = {p for p in current if current[p] != prior[p]}
            require(actual_changes == expected_changes, 'Audit scope mismatch: ' + pkg + '/' + name)
            for path, r in events.items():
                require(current[path] == normalized(r['planned']), 'Wrong output value')
                require(prior[path] == normalized(r['previous_release']), 'Wrong prior release value')
                require(original[path] == normalized(r['original']), 'Wrong original value')
                if r['preserved_configuration']:
                    require(current[path] == prior[path], 'Protected configuration changed')
                    report['preserved_values'] += 1
                else:
                    expected = Decimal(r['original']) * Decimal(r['factor_numerator']) / Decimal(r['factor_denominator'])
                    if r['maximum'] is not None:
                        expected = min(expected, Decimal(r['maximum']))
                    if 'Int' in r['schema_types']:
                        expected = expected.to_integral_value(rounding=ROUND_CEILING)
                    else:
                        expected = expected.quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)
                    require(Decimal(current[path]) == expected, 'Formula not based on original: ' + path)
                    report['arithmetic_values'] += 1
                if r['tag'] in {'SpawnDelay', 'spawn_delay'}:
                    require(r['rule'] == 'spawn_original_div3', 'Missed spawn field')
                    require(Decimal(current[path]) == (Decimal(original[path])/3).to_integral_value(rounding=ROUND_CEILING),
                            'Wrong spawn delay')
                    report['spawn_fields'] += 1
                if r['rule'] == 'extra_radius_companion_x3':
                    parent = path.rsplit('/', 1)[0]
                    matching = parent + '/Radius[1]'
                    require(matching in events and events[matching]['rule'] == 'explosion_radius_x3',
                            'Unrelated blast companion changed')
                    require(r['authorized_exception'] and not r['originally_modified'], 'Bad companion authorization')
                    require(original[path] == r['mod'] == r['previous_release'], 'Companion was not originally untouched')
                    detail['blast_companions_checked'] += 1
            require(not (relations(tree) - relations(old_tree) - relations(original_tree)),
                    'New min/max violation: ' + pkg + '/' + name)
            # Check proportions for every existing positive companion of changed blast radii.
            old_nodes, new_nodes = index_elements(original_tree), index_elements(tree)
            for path, r in events.items():
                if r['rule'] != 'explosion_radius_x3' or r['tag'] != 'Radius':
                    continue
                parent = path.rsplit('/', 1)[0]
                for tag in ('CrumbleRadius', 'KnockdownRadius', 'FlinchRadius'):
                    old_value = old_nodes[parent].findtext(tag)
                    if old_value is not None and Decimal(old_value) > 0:
                        require(Decimal(new_nodes[parent].findtext(tag)) == Decimal(old_value) * 3,
                                'Blast falloff did not follow radius')
            report['changed_values'] += len(actual_changes)
        detail['sha256'] = hashlib.sha256((OUT/'game_files'/(pkg+'.vpp_pc')).read_bytes()).hexdigest()
        report['packages'][pkg] = detail

    def sample(pkg, file, xpath, expected):
        actual = ET.fromstring(payloads[pkg][file]).findtext(xpath)
        require(actual == expected, 'Representative value failed: ' + str((pkg, xpath, actual, expected)))
        report['representative_checks'].append(dict(package=pkg,file=file,xpath=xpath,value=actual))

    for pkg in ('misc','table'):
        sample(pkg,'character.xtbl',".//Character[Name='rfg_PC']/max_speed",'10')
        sample(pkg,'character.xtbl',".//Character[Name='rfg_PC']/max_hit_points",'5500')
        sample(pkg,'explosions.xtbl',".//Explosion[Name='remote_charge']/Radius",'9')
        sample(pkg,'explosions.xtbl',".//Explosion[Name='remote_charge']/CrumbleRadius",'11.25')
        sample(pkg,'explosions.xtbl',".//Explosion[Name='remote_charge']/KnockdownRadius",'16.5')
        sample(pkg,'explosions.xtbl',".//Explosion[Name='remote_charge']/FlinchRadius",'27')
        for name, expected in [('sledgehammer_melee_side','75000'),('sledgehammer_melee_side_u1','40000'),
                               ('sledgehammer_melee_side_u2','50000'),('sledgehammer_melee_side_gold','500000')]:
            sample(pkg,'melee.xtbl',f".//MeleeMove[Name='{name}']/MoveDataList/AnimSet[AnimSetName='Player.xtbl']/Damage/DefaultDamage",expected)
        sample(pkg,'weapons.xtbl',".//Weapon[Name='sledgehammer']/Damage_Scaling_Max/NPC_Damage",'0')
        sample(pkg,'weapons.xtbl',".//Weapon[Name='golden_hammer']/MeleeAttacks/StandingPrimary",'sledgehammer_melee_side_gold')
    sample('misc','difficulty.xtbl',".//Difficulty_Items/Item[Name='MENU_PLAYER_DAMAGE_TAKEN']/Easy",'0.03')
    sample('misc','character.xtbl',".//Character[Name='Kyle']/max_hit_points",'2000')
    sample('misc','character.xtbl',".//Character[Name='Admiral_Kobel']/max_hit_points",'1200')
    require(report['spawn_fields'] == 128, 'Wrong spawn count')
    require(report['changed_values'] == 1241, 'Wrong change count')
    require(report['preserved_values'] == 1075, 'Wrong preserved count')
    (OUT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='representative_checks'},indent=2))
    print('Representative checks:',len(report['representative_checks']))


if __name__ == '__main__':
    main()
