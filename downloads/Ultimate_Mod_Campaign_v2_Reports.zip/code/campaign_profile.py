#!/usr/bin/env python3
"""Moderate the 10 m/s profile while preserving player protection and hammers."""
import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal, ROUND_HALF_UP
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

from rebalance_rules import xml_inventory, fmt
from verify_balance import read_raw


def sha(data):
    return hashlib.sha256(data).hexdigest()


def choice(row):
    """Return original multiplier, rationale and optional maximum, or preserve."""
    rule, tag, path, file = row["rule"], row["tag"], row["path"], row["file"]
    if tag in {"SpawnDelay", "spawn_delay"}:
        return 1, 3, "spawn_original_div3", None
    if rule.startswith("hammer_"):
        return None
    if rule in {"main_player_hp_x10", "main_player_speed_x2_explicit_override", "player_damage_div20",
                "ally_hp_x5", "enemy_hp_x3", "confirmed_keep_mod_height",
                "player_vehicle_damage_or_impulse_div10"}:
        return None
    if rule.startswith("keep_mod_"):
        return None
    if file == "character.xtbl":
        if tag == "knock_down_hits":
            return None
        if tag == "max_speed":
            return 3, 1, "non_main_movement_x3", None
    if file == "difficulty.xtbl":
        if any(name in path for name in ["MENU_PLAYER_REGEN_DELAY", "MENU_PLAYER_REGEN_RATE", "MENU_PLAYER_VEHICLE_DAMAGE"]):
            return None
        if "MENU_UPGRADE_COST_MULTIPLIER" in path:
            return 1, 3, "upgrade_cost_div3", None
        if any(name in path for name in ["MENU_PLAYER_AMMO_CRATES", "MENU_PLAYER_AMMO_PICKUP"]):
            return 5, 1, "ammo_pickup_x5", None
        if any(name in path for name in ["MENU_MORALE_BOOSTS", "MENU_CONTROL_PARKER"]):
            return 3, 1, "difficulty_misc_bonus_x3", None
    if file == "vehicles.xtbl":
        return (5, 1, "vehicle_hp_x5", None) if tag == "Max_Hitpoints" else (3, 1, "vehicle_dynamics_x3", None)
    if file == "explosions.xtbl":
        if tag in {"Radius", "CrumbleRadius", "KnockdownRadius", "FlinchRadius"}:
            return 3, 1, "explosion_radius_x3", None
        return 5, 1, "explosion_damage_x5", None
    if file == "weapons.xtbl":
        if tag == "Player_Vehicle_Damage":
            return None
        if tag in {"NPC_Damage", "Vehicle_Damage", "Magazine_Size", "Num_Magazines", "Max_Rounds", "Max_Rounds_Upgrade", "Ammo_Box_Restock", "To_Spread_Max"}:
            return 5, 1, "weapon_damage_or_ammo_x5", None
        if tag in {"Recoil_Kick", "Spread_Min", "Spread_Max", "Spread_Fine_Aim_Min", "Overheat_Percent_Per_Shot"}:
            return 1, 5, "weapon_recoil_spread_heat_div5", None
        if tag in {"Default_Refire_Delay", "Default_Reload_Delay", "Reload_Delay", "Overheat_Cool_Down_Time", "Min_Engagement_Distance", "Sound_Radius"}:
            return 1, 3, "weapon_delay_or_noise_div3", None
        if tag in {"Range_Max", "Range_Red", "Max_Engagement_Distance", "Headshot_Multiplier", "Start_Speed", "Max_Speed", "Autoaim_override", "Threshold"}:
            return 3, 1, "weapon_range_projectile_or_curve_x3", None
    if file == "melee.xtbl" and tag in {"HitRange", "HitRadius", "ImpactForce"}:
        return 3, 1, "melee_reach_or_impulse_x3", None
    if rule in {"required_enemy_count_div10", "courier_escape_speed_div10"}:
        return 1, 3, "mission_requirement_or_courier_speed_div3", None
    if rule == "reward_x10":
        return 5, 1, "reward_x5", None
    if rule == "activity_time_ammo_or_vehicle_health_x10":
        if tag in {"Time_To_Complete", "Par_Time", "Time_Limit"}:
            return 3, 1, "mission_time_x3", None
        if tag == "Vehicle_Health":
            return 5, 1, "mission_vehicle_health_fraction_cap1", Decimal(1)
        return 5, 1, "mission_ammo_or_vehicle_hp_x5", None
    if rule == "vehicle_damage_or_bonus_requirement_div10":
        if "Vehicle_player_damage_factor" in path:
            return None
        return 1, 3, "bonus_height_requirement_div3", None
    raise ValueError("Unclassified profile row: " + str((file, path, rule)))


def number(original, numerator, denominator, kinds, maximum=None):
    exact = Fraction(Decimal(original)) * Fraction(numerator, denominator)
    if maximum is not None and exact > Fraction(maximum):
        exact = Fraction(maximum)
        mode = "clamped_to_schema_maximum"
    else:
        mode = "exact"
    if "Int" in kinds:
        rounded = (exact.numerator + exact.denominator - 1) // exact.denominator
        return str(rounded), mode if exact.denominator == 1 else "ceil_to_integer"
    value = Decimal(exact.numerator) / Decimal(exact.denominator)
    rounded = value.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    return fmt(rounded), mode if Fraction(rounded) == exact else "rounded_to_6_decimals"


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--analysis-root",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args();root,out=args.analysis_root,args.output
    sys.path.insert(0,str(root))
    from repair_ultimate import pack_raw
    from vpp_compare import extract
    source=root/"comfort_review_10ms"
    audit=json.loads((source/"parameters.json").read_text())
    parent=json.loads((source/"speed_patch_validation.json").read_text())
    grouped=defaultdict(list)
    for r in audit:
        r["previous_release"]=r["planned"]
        r["previous_rule"]=r["rule"]
        target=choice(r)
        r["preserved_configuration"]=target is None
        if target:
            num,den,label,maximum=target
            val,rounding=number(r["original"],num,den,r["schema_types"],maximum)
            r.update(planned=val,rule=label,factor_numerator=num,factor_denominator=den,
                     factor=str(Fraction(num,den)),rounding=rounding,
                     maximum=str(maximum) if maximum is not None else None)
        else:
            r.update(factor_numerator=None,factor_denominator=None,maximum=None)
        grouped[(r["package"],r["file"])].append(r)
    out.mkdir(parents=True,exist_ok=False);(out/"game_files").mkdir()
    packages=[];file_rows=[]
    for pkg in ["misc","table"]:
        src=source/"game_files"/(pkg+".vpp_pc");template=src.read_bytes()
        trusted=next(x for x in parent["packages"] if x["package"]==pkg)
        assert sha(template)==trusted["output_sha256"]
        files=read_raw(src);initial=files.copy()
        original_dir=root/("ultimate_mod_misc/original" if pkg=="misc" else "table/original")
        for name,blob in list(files.items()):
            events=grouped.get((pkg,name),[])
            if not events:
                continue
            _,before=xml_inventory(blob)
            _,original=xml_inventory((original_dir/name).read_bytes())
            # Keep each existing positive falloff radius proportional when an
            # already-targeted blast radius changes. This extends the prior
            # authorized companion-bound exception, not unrelated explosions.
            radius_events=[r for r in events if r["tag"]=="Radius" and r["rule"]=="explosion_radius_x3"]
            existing={r["path"] for r in events}
            for radius in radius_events:
                n=original[radius["path"]]
                for tag in ["CrumbleRadius","KnockdownRadius","FlinchRadius"]:
                    child=n.parent.child(tag)
                    if child is None or child.path in existing:
                        continue
                    try:
                        if Decimal(child.value)<=0:continue
                    except Exception:continue
                    val,rounding=number(child.value,3,1,["Float"])
                    r=dict(package=pkg,file=name,path=child.path,tag=tag,original=child.value,
                           mod=child.value,previous_release=before[child.path].value,planned=val,
                           previous_rule="unmodified_original_radius_companion",rule="extra_radius_companion_x3",
                           factor="3",factor_numerator=3,factor_denominator=1,maximum=None,
                           rounding=rounding,schema_types=["Float"],originally_modified=False,
                           authorized_exception=True,preserved_configuration=False)
                    events.append(r);audit.append(r);existing.add(child.path)
            replacements=[]
            for r in events:
                node=before[r["path"]]
                assert node.value==r["previous_release"], (name,r["path"],node.value,r["previous_release"])
                if node.value==r["planned"]:continue
                raw=blob[node.text_start:node.text_end]
                a=node.text_start+len(raw)-len(raw.lstrip());b=node.text_end-(len(raw)-len(raw.rstrip()))
                replacements.append((a,b,r["planned"].encode("ascii")))
            result=blob
            for a,b,value in sorted(replacements,reverse=True):result=result[:a]+value+result[b:]
            _,after=xml_inventory(result)
            assert before.keys()==after.keys()
            expected={r["path"]:r["planned"] for r in events}
            for key,node in after.items():assert node.value==expected.get(key,before[key].value)
            files[name]=result
        extracted=out/"extracted"/pkg;extracted.mkdir(parents=True)
        for name,data in files.items():
            (extracted/name).write_bytes(data)
            file_rows.append(dict(package=pkg,file=name,previous_sha256=sha(initial[name]),
                                  output_sha256=sha(data),bytes=len(data),changed=data!=initial[name]))
        assert pack_raw(template,initial)==template
        result=pack_raw(template,files);path=out/"game_files"/(pkg+".vpp_pc");path.write_bytes(result)
        mf=extract(path,out/"roundtrip"/pkg)
        assert all(e["sha256"]==sha(files[e["name"]]) for e in mf["entries"])
        (out/(pkg+"_manifest.json")).write_text(json.dumps(mf,indent=2))
        packages.append(dict(name=pkg,file_count=len(files),bytes=len(result),source_sha256=sha(template),
                             sha256=sha(result),writer_calibration_passed=True,roundtrip_passed=True))
        print(pkg,len(files),"files packed and verified",flush=True)
    (out/"parameters.json").write_text(json.dumps(audit,indent=2),encoding="utf-8")
    for name,rows in [("parameters.csv",audit),("files.csv",file_rows)]:
        fields=list(dict.fromkeys(k for r in rows for k in r))
        with (out/name).open("w",encoding="utf-8-sig",newline="") as stream:
            w=csv.DictWriter(stream,fieldnames=fields);w.writeheader();w.writerows(rows)
    changed=[r for r in audit if r["previous_release"]!=r["planned"]]
    summary=dict(packages=packages,changed_parameters=len(changed),
                 changes_by_package=dict(Counter(r["package"] for r in changed)),
                 changes_by_rule=dict(Counter(r["rule"] for r in changed)),
                 spawn_fields=sum(r["tag"] in {"SpawnDelay","spawn_delay"} for r in audit),
                 preserved_values=sum(r["preserved_configuration"] for r in audit),
                 new_radius_companions=sum(r["rule"]=="extra_radius_companion_x3" for r in audit),
                 game_runtime_tested=False)
    (out/"summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=="__main__":main()
