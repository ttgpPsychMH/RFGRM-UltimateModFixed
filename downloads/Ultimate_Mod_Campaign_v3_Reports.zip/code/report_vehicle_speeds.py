"""Report explicit vehicle speed settings; do not infer live engine precedence."""
from collections import Counter
import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from verify_balance import read_raw

BASE = Path('/workspace/rfgrm-vpp-analysis')
OUT = Path('/workspace/RFGRM-UltimateModFixed/reports')
TAGS = {'forward': 'EnforcedMaxSpeed', 'reverse': 'EnforcedMaxRSpeed', 'ai': 'AIEnforcedMaxSpeed'}


def rounded(value):
    return format(value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP), 'f').rstrip('0').rstrip('.')


def speed_cell(raw):
    if raw == '':
        return '—'
    return f'{raw} ({rounded(Decimal(raw)*Decimal("1.609344"))})'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile',default='campaign_profile')
    parser.add_argument('--title',default='Campaign v2')
    parser.add_argument('--factor',default='3')
    args=parser.parse_args()
    factor=Decimal(args.factor)
    factor_label=args.factor.replace('.',',')
    OUT.mkdir(exist_ok=True)
    archives = {}
    hashes = {}
    summary = json.loads((BASE/args.profile/'summary.json').read_text())
    for pkg in ('misc','table'):
        path = BASE/args.profile/'game_files'/(pkg+'.vpp_pc')
        hashes[pkg] = hashlib.sha256(path.read_bytes()).hexdigest()
        assert hashes[pkg] == next(r['sha256'] for r in summary['packages'] if r['name']==pkg)
        archives[pkg] = read_raw(path)
    rows = []
    groups = []
    for file, record_tag in [('vehicles.xtbl','Vehicle'),('dlc01_vehicles.xtbl','Vehicle'),
                             ('vehicle_groups.xtbl','Vehicle_Group'),('vehicle_defaults.xtbl','Defaults')]:
        documents = {'original': (BASE/'table/original'/file).read_bytes(),
                     'misc': archives['misc'][file], 'table': archives['table'][file]}
        # The two original game archives contain identical copies of these tables.
        assert documents['original'] == (BASE/'ultimate_mod_misc/original'/file).read_bytes()
        records = {}
        for version, data in documents.items():
            root = ET.fromstring(data)
            nodes = root.findall('Table/'+record_tag)
            records[version] = {(n.findtext('Name'),n.findtext('_Editor/Category') or ''): n for n in nodes}
            assert len(nodes) == len(records[version])
        assert records['original'].keys()==records['misc'].keys()==records['table'].keys()
        for key, original in records['original'].items():
            row = dict(file=file, vehicle_id=key[0], category=key[1], display_name=original.findtext('Display_Name') or '',
                       vehicle_class=original.findtext('VehicleClass') or '', group=original.findtext('Group') or '')
            for version in ('original','misc','table'):
                node = records[version][key]
                for label, tag in TAGS.items():
                    raw = node.findtext(tag) or ''
                    row[version+'_'+label+'_raw'] = raw
                    if label != 'ai':
                        row[version+'_'+label+'_kmh'] = rounded(Decimal(raw)*Decimal('1.609344')) if raw else ''
                        row[version+'_'+label+'_mps'] = rounded(Decimal(raw)*Decimal('0.44704')) if raw else ''
                for label, path in [('torque','Engine/Torque'),('min_rpm','Engine/Min_RPM'),('max_rpm','Engine/Max_RPM')]:
                    row[version+'_'+label] = node.findtext(path) or ''
            for version in ('misc','table'):
                old, new = row['original_forward_raw'], row[version+'_forward_raw']
                row[version+'_forward_ratio'] = rounded(Decimal(new)/Decimal(old)) if old and new and Decimal(old)>0 else ''
            (rows if record_tag=='Vehicle' else groups).append(row)

    assert len(rows)==146
    assert sum(r['original_forward_raw']!=r['misc_forward_raw'] for r in rows)==62
    assert sum(r['original_reverse_raw']!=r['misc_reverse_raw'] for r in rows)==6
    assert sum(bool(r['original_forward_raw']) for r in rows)==133
    assert all(r['original_forward_raw']==r['table_forward_raw'] for r in rows)
    assert all(r['original_reverse_raw']==r['table_reverse_raw'] for r in rows)
    assert all(r['original_ai_raw']==r['misc_ai_raw']==r['table_ai_raw'] for r in rows)
    for r in rows:
        if r['original_forward_raw']!=r['misc_forward_raw']:
            assert Decimal(r['misc_forward_raw'])==factor*Decimal(r['original_forward_raw'])
        if r['original_reverse_raw']!=r['misc_reverse_raw']:
            assert Decimal(r['misc_reverse_raw'])==factor*Decimal(r['original_reverse_raw'])
    for filename, data in [('vehicle-speeds.csv',rows),('vehicle-speed-groups.csv',groups)]:
        with (OUT/filename).open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(data[0]),lineterminator='\n');writer.writeheader();writer.writerows(data)

    lines = ['# Tốc độ toàn bộ cấu hình xe — '+args.title, '',
             'Đối chiếu hai VPP đang phát hành với hai bản BACKUP original. Tiện ích nhảy RSL không đổi các số liệu này.', '',
             '- Có **146 cấu hình xe**: 130 trong `vehicles.xtbl`, 16 trong `dlc01_vehicles.xtbl`. Bao gồm biến thể, mục thử nghiệm và xe chưa chắc xuất hiện trong phần chơi đang dùng; không có nghĩa là 146 loại xe khác nhau có thể lái.',
             '- **133** cấu hình khai báo giới hạn tiến riêng; **13** walker/flyer không khai báo trường đó.',
             f'- Trong `misc.vpp_pc`: **62** giới hạn tiến tăng ×{factor_label}, **71** giới hạn tiến còn lại giữ gốc; **6** giới hạn lùi tăng ×{factor_label}. DLC giữ nguyên.',
             '- Trong `table.vpp_pc`: toàn bộ giới hạn tiến/lùi ở hai bảng xe vẫn bằng original.',
             f'- Các giá trị `AIEnforcedMaxSpeed` khai báo riêng (60 cấu hình) giữ nguyên trong cả hai gói. Không thể suy ra AI chắc chắn lái nhanh ×{factor_label} từ giới hạn tiến của xe.', '',
             '**Đây là giới hạn cấu hình, chưa phải tốc độ đo khi lái.** Mô tả gốc của `EnforcedMaxSpeed` ghi rõ đơn vị MPH và giới hạn động cơ Havok/các giới hạn khác có thể khiến xe không đạt tới số này. Động cơ, RPM, số truyền, độ bám, địa hình, lực cản và nhiệm vụ cũng ảnh hưởng tốc độ.', '',
             '**Hai gói có dữ liệu trùng nhưng khác giá trị.** Chưa xác nhận thứ tự engine ưu tiên nạp chúng, nên báo cáo hiển thị riêng từng gói; chưa thể kết luận mọi xe trong game thực sự chạy theo cột `misc` hay `table` chỉ từ các VPP.', '',
             '[Tải CSV đầy đủ](https://raw.githubusercontent.com/ttgpPsychMH/RFGRM-UltimateModFixed/main/reports/vehicle-speeds.csv) · [CSV nhóm/default](https://raw.githubusercontent.com/ttgpPsychMH/RFGRM-UltimateModFixed/main/reports/vehicle-speed-groups.csv)', '',
             '## Giới hạn tốc độ tiến của tất cả cấu hình', '',
             'Mỗi ô là **mph (km/h)**. Dấu **—** nghĩa là không khai báo riêng; không có nghĩa bằng 0 hoặc chắc chắn kế thừa 90 mph. Các cột km/h đã làm tròn đến hai chữ số. Có thể dùng Ctrl+F để tìm ID hoặc tên xe.', '']
    for file in ('vehicles.xtbl','dlc01_vehicles.xtbl'):
        lines += ['### '+file, '', '| ID | Tên trong dữ liệu | Original | misc hiện tại | table hiện tại | misc/gốc |',
                  '|---|---|---:|---:|---:|---:|']
        for r in rows:
            if r['file']!=file:continue
            cells=[r['vehicle_id'],r['display_name'],speed_cell(r['original_forward_raw']),speed_cell(r['misc_forward_raw']),speed_cell(r['table_forward_raw']),('×'+r['misc_forward_ratio']) if r['misc_forward_ratio'] else '—']
            lines.append('| '+' | '.join(c.replace('|','\\|') for c in cells)+' |')
        lines.append('')
    lines += ['## Những giới hạn lùi đã thay đổi', '',
              'Đơn vị **mph (km/h)**. Các giới hạn lùi khai báo khác giữ gốc; xem CSV để có toàn bộ giá trị và các trường không khai báo riêng.', '',
              '| ID | Original | misc hiện tại | table hiện tại |', '|---|---:|---:|---:|']
    for r in rows:
        if r['original_reverse_raw']!=r['misc_reverse_raw']:
            lines.append('| '+' | '.join([r['vehicle_id']]+[speed_cell(r[v+'_reverse_raw']) for v in ('original','misc','table')])+' |')
    lines += ['', '## Nhóm xe và dữ liệu mặc định', '',
              '`vehicle_groups.xtbl` và `vehicle_defaults.xtbl` không đổi giữa gốc và hai gói mod. Small/Medium/Large có giới hạn tiến riêng 60/50/45; Tank/Flyer/Mech không có. Bản ghi `Vehicle Defaults` có giới hạn tiến 90, lùi 35. Không áp các con số này như tốc độ thực tế của walker/flyer: dữ liệu hiện có chưa xác nhận cách các lớp xe đặc biệt sử dụng chúng.', '',
              '## Lưu ý khi đọc kết quả', '',
              '- Tăng mô-men xoắn hoặc RPM có thể làm xe tăng tốc khác đi ngay cả khi giới hạn tốc độ tiến vẫn giữ gốc. CSV kèm torque, Min/Max RPM để đối chiếu; không dùng RPM để tự suy ra vận tốc tối đa.',
              '- `Max_Speed_Steering` là thông số điều khiển lái, không dùng thay cho giới hạn tốc độ xe trong bảng.',
              '- Các override của nhiệm vụ, tốc độ điều khiển AI và trạng thái vật lý có thể ảnh hưởng vận tốc thực; chưa chạy game để đo chúng.', '',
              '## Nguồn và kiểm tra', '',
              'Đọc trực tiếp hai VPP hiện tại bằng bộ kiểm tra cấu trúc độc lập; đối chiếu tập ID và giá trị với original. Công thức quy đổi: 1 mph = 1.609344 km/h = 0.44704 m/s. Không sửa bất kỳ dữ liệu game nào khi lập báo cáo.', '',
              'SHA-256 của VPP nguồn:', '']
    for pkg in ('misc','table'):lines.append('- `'+pkg+'.vpp_pc`: `'+hashes[pkg]+'`')
    (OUT/'vehicle-speeds.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    result = dict(configurations=len(rows),counts_by_file=dict(Counter(r['file'] for r in rows)),explicit_forward_limits=133,
                  missing_forward_limits=13,misc_changed_forward=62,misc_changed_reverse=6,table_changed_forward=0,
                  explicit_ai_limits=sum(bool(r['original_ai_raw']) for r in rows),ai_limits_unchanged=True,
                  vehicle_speed_factor=str(factor),profile=args.profile,
                  source_sha256=hashes,runtime_speed_measured=False,engine_load_precedence_verified=False)
    (OUT/'vehicle-speeds-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    print('Changed forward cap range (misc):', min(Decimal(r['misc_forward_raw']) for r in rows if r['misc_forward_ratio']==args.factor),
          max(Decimal(r['misc_forward_raw']) for r in rows if r['misc_forward_ratio']==args.factor))


if __name__=='__main__':
    main()
