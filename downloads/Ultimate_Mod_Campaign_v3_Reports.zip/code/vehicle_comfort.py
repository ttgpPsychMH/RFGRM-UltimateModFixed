"""Reduce only audited vehicle speed/engine fields to 1.5x original."""
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from rebalance_rules import xml_inventory, fmt
from verify_balance import read_raw, values, relations

BASE=Path('/workspace/rfgrm-vpp-analysis')
SOURCE=BASE/'campaign_profile'
OUT=BASE/'vehicle_comfort_1_5x'
SELECTED={'EnforcedMaxSpeed','EnforcedMaxRSpeed','Torque','Min_RPM','Opt_RPM','Max_RPM'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    sys.path.insert(0,str(BASE))
    from repair_ultimate import pack_raw
    from vpp_compare import extract
    audit=json.loads((SOURCE/'parameters.json').read_text())
    previous=json.loads((SOURCE/'summary.json').read_text())
    selected=[]
    for r in audit:
        r['previous_release']=r['planned']
        r['previous_rule']=r['rule']
        change=r['file']=='vehicles.xtbl' and r['rule']=='vehicle_dynamics_x3' and r['tag'] in SELECTED
        r['preserved_configuration']=not change
        if change:
            assert Decimal(r['original'])>0
            r.update(planned=fmt(Decimal(r['original'])*Decimal('1.5')),rule='vehicle_speed_engine_x1_5',
                     factor='1.5',factor_numerator=3,factor_denominator=2,rounding='exact',maximum=None)
            selected.append(r)
    assert len(selected)==349 and all(r['package']=='misc' for r in selected)
    OUT.mkdir(exist_ok=False)
    (OUT/'game_files').mkdir()
    summary=dict(packages=[],changed_parameters=len(selected),preserved_values=len(audit)-len(selected),
                 changed_by_tag=dict(Counter(r['tag'] for r in selected)),game_runtime_tested=False)
    validation=dict(status='passed',packages={},arithmetic_values_checked=0,
                    preserved_audit_values_checked=0,source='Campaign v2',game_runtime_tested=False)
    file_rows=[]
    for pkg in ('misc','table'):
        source_path=SOURCE/'game_files'/(pkg+'.vpp_pc')
        template=source_path.read_bytes()
        assert sha(template)==next(r['sha256'] for r in previous['packages'] if r['name']==pkg)
        before=read_raw(source_path)
        after=before.copy()
        rows=[r for r in selected if r['package']==pkg]
        if rows:
            blob=before['vehicles.xtbl']
            _,nodes=xml_inventory(blob)
            edits=[]
            for row in rows:
                n=nodes[row['path']]
                assert n.value==row['previous_release']
                raw=blob[n.text_start:n.text_end]
                start=n.text_start+len(raw)-len(raw.lstrip())
                end=n.text_end-(len(raw)-len(raw.rstrip()))
                edits.append((start,end,row['planned'].encode('ascii')))
            for start,end,value in sorted(edits,reverse=True):blob=blob[:start]+value+blob[end:]
            after['vehicles.xtbl']=blob
        assert pack_raw(template,before)==template
        result=pack_raw(template,after)
        path=OUT/'game_files'/(pkg+'.vpp_pc')
        path.write_bytes(result)
        manifest=extract(path,OUT/'roundtrip'/pkg)
        independent=read_raw(path)
        assert independent.keys()==before.keys()
        manifest_hash={e['name']:e['sha256'] for e in manifest['entries']}
        valid_xml=0;exceptions={}
        original_dir=BASE/('ultimate_mod_misc/original' if pkg=='misc' else 'table/original')
        for name,blob in independent.items():
            assert sha(blob)==manifest_hash[name]
            expected_changed=pkg=='misc' and name=='vehicles.xtbl'
            if not expected_changed:assert blob==before[name]
            file_rows.append(dict(package=pkg,file=name,changed=blob!=before[name],
                                  previous_sha256=sha(before[name]),output_sha256=sha(blob)))
            if not name.endswith('.xtbl'):continue
            try:ET.fromstring(blob)
            except ET.ParseError as error:
                assert name=='credits.xtbl' and blob==before[name]==(original_dir/name).read_bytes()
                exceptions[name]=str(error)
            else:valid_xml+=1
        # Independent ElementTree interpretation verifies every vehicle field.
        old_tree=ET.fromstring(before['vehicles.xtbl'])
        new_tree=ET.fromstring(independent['vehicles.xtbl'])
        original_tree=ET.fromstring((original_dir/'vehicles.xtbl').read_bytes())
        old_map,new_map,original_map=values(old_tree),values(new_tree),values(original_tree)
        assert old_map.keys()==new_map.keys()
        actual={p for p in old_map if old_map[p]!=new_map[p]}
        assert actual=={r['path'] for r in rows}
        for r in rows:
            assert Decimal(new_map[r['path']])==Decimal(original_map[r['path']])*Decimal('1.5')
            assert new_map[r['path']]==r['planned']
            validation['arithmetic_values_checked']+=1
        assert not (relations(new_tree)-relations(old_tree)-relations(original_tree))
        # Check all other audited settings, including HP, hammers and speed 10.
        maps={}
        for r in audit:
            if r['package']!=pkg:continue
            if r['file'] not in maps:
                maps[r['file']]=values(ET.fromstring(independent[r['file']]))
            assert maps[r['file']][r['path']]==r['planned'].replace('\r\n','\n').replace('\r','\n')
            if r['preserved_configuration']:
                assert r['planned']==r['previous_release']
                validation['preserved_audit_values_checked']+=1
        summary['packages'].append(dict(name=pkg,file_count=len(after),bytes=len(result),
                                       source_sha256=sha(template),sha256=sha(result),
                                       writer_calibration_passed=True,roundtrip_passed=True))
        validation['packages'][pkg]=dict(file_count=len(after),changed_files=['vehicles.xtbl'] if rows else [],
                                        unchanged_entire_archive=result==template,xml_valid=valid_xml,
                                        unchanged_original_xml_exceptions=exceptions,
                                        no_new_min_max_violations=True,roundtrip_passed=True,
                                        independent_reader_passed=True)
        (OUT/(pkg+'_manifest.json')).write_text(json.dumps(manifest,indent=2))
        print(pkg,'validated',flush=True)
    assert validation['arithmetic_values_checked']==349
    assert validation['preserved_audit_values_checked']==1967
    for filename,records in [('parameters.csv',audit),('files.csv',file_rows)]:
        with (OUT/filename).open('w',encoding='utf-8-sig',newline='') as stream:
            fields=list(dict.fromkeys(k for row in records for k in row))
            w=csv.DictWriter(stream,fieldnames=fields);w.writeheader();w.writerows(records)
    for name,data in [('parameters.json',audit),('summary.json',summary),('validation.json',validation)]:
        (OUT/name).write_text(json.dumps(data,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
