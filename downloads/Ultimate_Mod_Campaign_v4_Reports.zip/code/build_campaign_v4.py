#!/usr/bin/env python3
"""Build Campaign V4 from verified originals; preserve V3 vehicle values only.

Inputs under --analysis-root: campaign_v4_originals/{misc,table}, their
manifests and raw_original_game_files, and vehicle_comfort_1_5x/roundtrip.
All patches replace numeric text spans, leaving XML structure/references intact.
"""
import argparse
from collections import Counter
import csv
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

from rebalance_rules import xml_inventory, schema_types, decimal, fmt
from verify_balance import read_raw, values, relations, index_elements

D = Decimal
HANDHELD = {'Entries:EDF', 'Entries:Guerilla', 'Entries:Marauder'}
PLAYER_NAMES = {'rfg_PC', 'rfg_PC_DLC'}
ORDINARY_BLASTS = {'remote_charge', 'mine', 'rocket', 'gauss_rifle',
                   'gauss_rifle_npc', 'nano_rifle_exp', 'grinder_explosive',
                   'DLC_remote_charge', 'DLC_missilepod'}
SELECTED_BLASTS = ORDINARY_BLASTS | {'thermo_rocket'}
RADII = {'Radius', 'CrumbleRadius', 'KnockdownRadius'}
BLAST_DAMAGE = {'human_damage_min', 'Human_Damage_Max',
                'vehicle_damage_min', 'vehicle_damage_max'}
AMMO = {'Max_Rounds', 'Max_Rounds_Upgrade', 'Ammo_Box_Restock', 'Num_Magazines'}
INCOMING = {'Player_Damage', 'Player_Vehicle_Damage'}
MELEE_INCOMING = {'PlayerDamage', 'PlayerDamageFromNPC'}
GUN_CLASSES = {'bullet', 'arc_welder', 'nano_rifle', 'grinder', 'harpoon'}
REINFORCEMENT_FILES = {
    'activity_house_arrest.xtbl': {'spawn_delay'},
    'raid_data.xtbl': {'SpawnDelay'},
    'guerrilla_reinforcement.xtbl': {'respawn_delay'},
    'reinforcement_profile.xtbl': {'spawn_delay'},
}
DIFFICULTY = {
    'MENU_PLAYER_DAMAGE_TAKEN': ('0.05', 'player_incoming_difficulty_div20'),
    'MENU_PLAYER_FALLING_DAMAGE': ('0.05', 'player_falling_difficulty_div20'),
    'MENU_PLAYER_REGEN_DELAY': ('0.1', 'player_regen_delay_div10'),
    'MENU_PLAYER_REGEN_RATE': ('10', 'player_regen_rate_x10'),
    'MENU_PLAYER_VEHICLE_DAMAGE': ('0.1', 'player_vehicle_difficulty_div10'),
}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def canonical_file(name):
    return name.removeprefix('dlc01_')


def record_of(node):
    p = node
    while p.parent and p.parent.tag != 'Table':
        p = p.parent
    return p if p.parent and p.parent.tag == 'Table' else None


def is_campaign(record):
    if record is None:
        return False
    name = record.get('Name') or ''
    category = record.get('_Editor/Category') or ''
    # Some MP characters have no Multiplayer category (EddieMP, SladeMP).
    return not (re.search(r'(^mp_|_mp$)', name, re.I) or name.endswith('MP')
                or any(s in name.lower() for s in ('test', 'debug'))
                or any(s in category.lower() for s in ('multiplayer', 'mp ', 'mp:', 'test')))


def decision(filename, node):
    """Explicit field/record allowlist; never act on schemas or editor templates."""
    record = record_of(node)
    if not is_campaign(record) or node.children:
        return None
    original = decimal(node.value)
    if original is None or original <= 0:
        return None  # Preserve zeros, negative engine sentinels and text references.
    base, tag = canonical_file(filename), node.tag
    name = record.get('Name') or ''
    dlc = filename.startswith('dlc01_')
    if base == 'character.xtbl':
        if name in PLAYER_NAMES:
            return {'max_hit_points': ('10', 'player_hp_x10'),
                    'max_speed': ('2', 'player_speed_10_mps'),
                    'knock_down_hits': ('10', 'player_knockdown_resistance_x10')}.get(tag)
        if tag == 'max_hit_points':
            team = record.get('Team')
            if dlc:
                # These two mission actors have scripted faction/plot roles.
                # Do not guess their runtime alliance from Team=Guerilla.
                if name in {'mis_DLC_Dan', 'mis_DLC_RFCommander'}:
                    return None
                if team in {'Marauder', 'Civilian'} or (record.get('_Editor/Category') or '').endswith(':Prisoner'):
                    return '3', 'dlc_ally_or_prisoner_hp_x3'
                if team == 'EDF':
                    return '2', 'dlc_enemy_hp_x2'
            else:
                if team in {'Guerilla', 'Civilian'}:
                    return '3', 'ally_hp_x3'
                if team in {'EDF', 'Marauder'}:
                    return '2', 'enemy_hp_x2'
    if base == 'difficulty.xtbl' and tag in {'Easy', 'Medium', 'Hard', 'Insane'}:
        item = node.ancestor('Item')
        return DIFFICULTY.get(item.get('Name') if item else '')
    if base == 'weapons.xtbl':
        if tag in INCOMING:
            return '0.05', 'player_incoming_weapon_div20'
        category = record.get('_Editor/Category')
        kind = record.get('Weapon_Class') or ''
        if category not in HANDHELD or kind.startswith('melee'):
            return None
        if tag in AMMO and (kind in GUN_CLASSES or record.get('Explosion') in SELECTED_BLASTS):
            return '5', 'handheld_ammo_x5'
        if tag in {'NPC_Damage', 'Vehicle_Damage'}:
            explosion = record.get('Explosion')
            if explosion in SELECTED_BLASTS:
                return ('1.5', 'thermobaric_direct_damage_x1_5') if explosion == 'thermo_rocket' else ('2', 'explosive_weapon_direct_damage_x2')
            # NPC-exclusive grenades and singularity gadgets retain offense.
            if not explosion and kind in GUN_CLASSES:
                return '3', 'gun_damage_x3'
    if base == 'explosions.xtbl' and name in SELECTED_BLASTS:
        if tag in RADII and name != 'thermo_rocket':
            return '1.5', 'explosion_radii_x1_5'
        if tag == 'Structural_Damage':
            return '1.5', 'explosion_structural_damage_x1_5'
        if tag in BLAST_DAMAGE:
            return ('1.5', 'thermobaric_blast_damage_x1_5') if name == 'thermo_rocket' else ('2', 'explosion_npc_vehicle_damage_x2')
        if tag in {'player_veh_mult', 'player_vehicle_impulse_mult'}:
            return '0.1', 'player_vehicle_blast_protection_div10'
    if base == 'melee.xtbl':
        if tag in MELEE_INCOMING:
            return '0.05', 'player_incoming_melee_div20'
        anim = node.ancestor('AnimSet')
        if name.startswith('sledgehammer_melee_') and anim and anim.get('AnimSetName') == 'Player.xtbl':
            if tag in {'DefaultDamage', 'NPCDamage', 'VehicleDamage'}:
                return '3', 'player_hammer_damage_x3'
            if tag == 'StructureDamage':
                return '2', 'player_hammer_structure_x2'
    if base == 'tweak_table.xtbl' and name == 'Vehicle_player_damage_factor' and tag == 'Value':
        return '0.1', 'player_collision_damage_div10'
    if tag in REINFORCEMENT_FILES.get(base, set()):
        return '0.5', 'reinforcement_delay_div2'
    if base.startswith('activity_'):
        if tag == 'Salvage_Reward':
            return '3', 'activity_salvage_reward_x3'
        if base == 'activity_timed_delivery.xtbl' and tag in {'Time_To_Complete', 'Time_To_Fail', 'Par_Time'}:
            return '3', 'objective_timer_x3'
        if base == 'activity_demolitions_master.xtbl':
            if tag in {'Time_Limit', 'Par_Time'}:
                return '3', 'objective_timer_x3'
            if tag == 'Ammo':
                return '5', 'activity_ammo_x5'
        if base == 'activity_house_arrest.xtbl' and tag == 'Hostage_Kill_Time':
            return '3', 'hostage_grace_period_x3'
        if base == 'activity_mayhem.xtbl' and tag == 'Time_per_score':
            return '3', 'mayhem_time_bonus_x3'
        if base == 'activity_courier_chase.xtbl' and tag == 'Escape_Speed':
            return '1/3', 'courier_escape_speed_div3'
    if base == 'upgrades.xtbl' and tag == 'Cost':
        return '0.5', 'purchase_upgrade_cost_div2'
    return None


def numeric_patch(blob, plans):
    _, nodes = xml_inventory(blob)
    replacements = []
    for path, planned in plans.items():
        n = nodes[path]
        raw = blob[n.text_start:n.text_end]
        a = n.text_start + len(raw) - len(raw.lstrip())
        b = n.text_end - (len(raw) - len(raw.rstrip()))
        replacements.append((a, b, planned.encode('ascii')))
    for a, b, replacement in sorted(replacements, reverse=True):
        blob = blob[:a] + replacement + blob[b:]
    return blob


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis-root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    base, out = args.analysis_root, args.output
    sys.path.insert(0, str(base))
    from repair_ultimate import pack_raw
    from vpp_compare import extract
    src = base / 'campaign_v4_originals'
    state = json.loads((src / 'request_and_pending_policy.json').read_text())
    for package, source in state['sources'].items():
        assert sha(Path(source['path']).read_bytes()) == source['sha256'], package
    out.mkdir(parents=True, exist_ok=False)
    (out / 'game_files').mkdir()
    audit, file_rows, packages = [], [], []
    validation = {'status': 'passed', 'packages': {}, 'game_runtime_tested': False}
    samples = []
    for package in ('misc', 'table'):
        original = read_raw(src / 'raw_original_game_files' / (package + '.vpp_pc'))
        original_manifest = json.loads((src / (package + '_manifest.json')).read_text())
        mh = {e['name']: e['sha256'] for e in original_manifest['entries']}
        assert set(original) == set(mh)
        for name, blob in original.items():
            assert sha(blob) == mh[name] and blob == (src / package / name).read_bytes()
        template = (src / 'raw_original_game_files' / (package + '.vpp_pc')).read_bytes()
        assert pack_raw(template, original) == template
        files = original.copy()
        by_file = {}
        for filename, blob in original.items():
            if not filename.endswith('.xtbl'):
                continue
            if filename == 'credits.xtbl':
                continue
            root, nodes = xml_inventory(blob)
            kinds = schema_types(root)
            plans, events = {}, []
            if filename == 'vehicles.xtbl':
                vehicle_blob = (base / 'vehicle_comfort_1_5x' / 'roundtrip' / package / filename).read_bytes()
                _, vehicle_nodes = xml_inventory(vehicle_blob)
                assert nodes.keys() == vehicle_nodes.keys()
                for path, n in nodes.items():
                    v = vehicle_nodes[path]
                    if n.value == v.value:
                        continue
                    assert not n.children and decimal(n.value) is not None and decimal(v.value) is not None
                    events.append(dict(package=package, file=filename, path=path, tag=n.tag,
                                       original=n.value, planned=v.value, factor=fmt(D(v.value)/D(n.value)),
                                       rule='vehicle_exact_v3', rounding='exact',
                                       schema_types=sorted(kinds.get(n.tag, set()))))
                    plans[path] = v.value
                # Patch original formatting; semantic values must match V3 exactly.
            else:
                for path, n in nodes.items():
                    choice = decision(filename, n)
                    if choice is None:
                        continue
                    factor, label = choice
                    # Courier has integer fields: ceil(original / 3), exactly.
                    raw_value = D(n.value) / 3 if label == 'courier_escape_speed_div3' else D(n.value) * D(factor)
                    rounded, rounding = raw_value, 'exact'
                    if 'Int' in kinds.get(n.tag, set()):
                        rounded = raw_value.to_integral_value(rounding=ROUND_CEILING)
                        if rounded != raw_value:
                            rounding = 'ceil_to_integer'
                    planned = fmt(rounded)
                    if D(planned) == D(n.value):
                        continue
                    plans[path] = planned
                    events.append(dict(package=package, file=filename, path=path, tag=n.tag,
                                       original=n.value, planned=planned, factor=factor,
                                       rule=label, rounding=rounding,
                                       schema_types=sorted(kinds.get(n.tag, set()))))
            if events:
                files[filename] = numeric_patch(blob, plans)
                ET.fromstring(files[filename])
                audit.extend(events)
                by_file[filename] = events
        result = pack_raw(template, files)
        target = out / 'game_files' / (package + '.vpp_pc')
        target.write_bytes(result)
        manifest = extract(target, out / 'roundtrip' / package)
        independent = read_raw(target)
        assert set(independent) == set(original)
        assert {e['name']: e['sha256'] for e in manifest['entries']} == {k: sha(v) for k, v in files.items()}
        xml_valid, exceptions, numeric_count = 0, {}, 0
        protected_reference_count = 0
        for filename, blob in independent.items():
            assert blob == files[filename] == (out / 'roundtrip' / package / filename).read_bytes()
            before = original[filename]
            events = by_file.get(filename, [])
            file_rows.append(dict(package=package, file=filename, changed=blob != before,
                                  original_sha256=sha(before), output_sha256=sha(blob), bytes=len(blob)))
            if not events:
                assert blob == before
            if not filename.endswith('.xtbl'):
                assert blob == before
                continue
            try:
                tree = ET.fromstring(blob)
            except ET.ParseError as error:
                assert filename == 'credits.xtbl' and blob == before
                exceptions[filename] = str(error)
                continue
            xml_valid += 1
            if not events:
                continue
            old_tree = ET.fromstring(before)
            old_map, new_map = values(old_tree), values(tree)
            assert old_map.keys() == new_map.keys()
            actual = {p for p in old_map if old_map[p] != new_map[p]}
            assert actual == {r['path'] for r in events}, (package, filename, actual)
            for path, old in old_map.items():
                if decimal(old) is None:
                    assert new_map[path] == old  # NPC loadouts, spawn refs, names, flags, unlock links.
                    protected_reference_count += 1
                elif D(old) <= 0:
                    assert new_map[path] == old
            for event in events:
                path = event['path']
                assert new_map[path] == event['planned'] and old_map[path] == event['original']
                expected = (D(event['original']) / 3 if event['rule'] == 'courier_escape_speed_div3'
                            else D(event['original']) * D(event['factor']))
                if event['rounding'] == 'ceil_to_integer':
                    expected = expected.to_integral_value(rounding=ROUND_CEILING)
                assert D(new_map[path]) == expected
                if 'Int' in event['schema_types']:
                    assert D(new_map[path]) == D(new_map[path]).to_integral_value()
                numeric_count += 1
            assert not (relations(tree) - relations(old_tree)), (package, filename, relations(tree) - relations(old_tree))
            # No schema/default/template edits; no intentional MP/test entry edits.
            old_elements, new_elements = index_elements(old_tree), index_elements(tree)
            assert old_elements.keys() == new_elements.keys()
            if filename != 'vehicles.xtbl':
                for path in old_map:
                    if not path.startswith('/root/Table[1]/'):
                        assert old_map[path] == new_map[path]
                table = tree.find('Table')
                for record in table:
                    category = record.findtext('_Editor/Category') or ''
                    name = record.findtext('Name') or ''
                    if ('MP' in category or 'Multiplayer' in category
                            or re.search(r'(^mp_|_mp$)', name, re.I) or name.endswith('MP')):
                        # Compare entire subtree against the same original path.
                        for p, e in new_elements.items():
                            if e is record:
                                assert ET.tostring(record) == ET.tostring(old_elements[p])
                                break
        # Numeric vehicle configuration matches V3, including its per-package scope.
        assert values(ET.fromstring(independent['vehicles.xtbl'])) == values(ET.fromstring(
            (base/'vehicle_comfort_1_5x/roundtrip'/package/'vehicles.xtbl').read_bytes()))
        # Shared tables in misc/table get identical V4 payloads except authorized vehicles.
        package_check = dict(file_count=len(files), xml_valid=xml_valid,
                             unchanged_original_xml_exceptions=exceptions,
                             changed_files=sorted(by_file), numeric_changes_verified=numeric_count,
                             protected_text_values_verified=protected_reference_count,
                             roundtrip_passed=True, independent_reader_passed=True,
                             no_new_min_max_violations=True, vehicle_values_exact_v3=True,
                             original_reference_structure_and_binary_assets_preserved=True)
        validation['packages'][package] = package_check
        packages.append(dict(name=package, file_count=len(files), bytes=len(result),
                             original_archive_sha256=state['sources'][package]['sha256'],
                             sha256=sha(result), changed_files=len(by_file),
                             changed_parameters=numeric_count))
        write_json(out/(package+'_manifest.json'), manifest)
        print(package, 'packed and independently verified:', numeric_count, 'values in', len(by_file), 'files', flush=True)
    misc, table = out/'roundtrip/misc', out/'roundtrip/table'
    for p in table.iterdir():
        if p.name != 'vehicles.xtbl':
            assert p.read_bytes() == (misc/p.name).read_bytes(), p.name
    validation['duplicate_tables_consistent_except_v3_vehicles'] = True
    def sample(filename, xpath, expected):
        for package in ('misc', 'table'):
            root = ET.parse(out/'roundtrip'/package/filename).getroot()
            if filename == 'weapons.xtbl':
                record_path, field = xpath.split(']/', 1)
                candidates = [w for w in root.findall(record_path + ']')
                              if w.findtext('_Editor/Category') in HANDHELD]
                assert len(candidates) == 1
                actual = candidates[0].findtext(field)
            else:
                actual = root.findtext(xpath)
            assert actual == expected, (package, filename, xpath, actual, expected)
            samples.append(dict(package=package,file=filename,xpath=xpath,value=actual))
    sample('character.xtbl', ".//Table/Character[Name='rfg_PC']/max_speed", '10')
    sample('character.xtbl', ".//Table/Character[Name='rfg_PC']/max_hit_points", '5500')
    sample('character.xtbl', ".//Table/Character[Name='rfg_PC']/Height", '1.0')
    sample('character.xtbl', ".//Table/Character[Name='Kyle']/max_hit_points", '1200')
    sample('character.xtbl', ".//Table/Character[Name='Admiral_Kobel']/max_hit_points", '800')
    sample('explosions.xtbl', ".//Table/Explosion[Name='remote_charge']/Radius", '4.5')
    sample('explosions.xtbl', ".//Table/Explosion[Name='remote_charge']/Human_Damage_Max", '2500')
    sample('explosions.xtbl', ".//Table/Explosion[Name='remote_charge']/Structural_Damage", '33750')
    sample('explosions.xtbl', ".//Table/Explosion[Name='rocket']/Radius", '5.475')
    sample('explosions.xtbl', ".//Table/Explosion[Name='thermo_rocket']/Radius", '6.5')
    sample('explosions.xtbl', ".//Table/Explosion[Name='thermo_rocket']/Human_Damage_Max", '9000')
    sample('weapons.xtbl', ".//Table/Weapon[Name='m16']/Damage_Scaling_Max/NPC_Damage", '135')
    sample('weapons.xtbl', ".//Table/Weapon[Name='charge_placer']/Max_Rounds", '90')
    sample('weapons.xtbl', ".//Table/Weapon[Name='charge_placer']/Max_Rounds_Upgrade", '150')
    sample('activity_house_arrest.xtbl', ".//Table/house_arrest[Name='je_ha_04']/Hostage_Kill_Time", '90')
    sample('melee.xtbl', ".//Table/MeleeMove[Name='sledgehammer_melee_vert']/MoveDataList/AnimSet[AnimSetName='Player.xtbl']/Damage/StructureDamage", '3000')
    validation['representative_checks'] = samples
    summary = dict(version='Campaign V4', built_from_originals=True, packages=packages,
                   changed_parameters=len(audit), changes_by_rule=dict(Counter(r['rule'] for r in audit)),
                   changes_by_file=dict(Counter(r['file'] for r in audit)), game_runtime_tested=False)
    write_json(out/'parameters.json', audit)
    write_json(out/'summary.json', summary)
    write_json(out/'validation.json', validation)
    for name, rows in [('parameters.csv', audit), ('files.csv', file_rows)]:
        fields = list(dict.fromkeys(k for r in rows for k in r))
        with (out/name).open('w', encoding='utf-8-sig', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
            writer.writeheader()
            writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
