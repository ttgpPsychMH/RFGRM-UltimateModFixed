#!/usr/bin/env python3
"""Create V4 release documentation and ZIPs after the build validation passes."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
import zipfile

BASE = Path('/workspace/rfgrm-vpp-analysis')
OUT = BASE/'campaign_v4'
REPO = Path('/workspace/RFGRM-UltimateModFixed')
DOWNLOADS = REPO/'downloads'
REPORTS = REPO/'reports'


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    summary = json.loads((OUT/'summary.json').read_text())
    validation = json.loads((OUT/'validation.json').read_text())
    assert validation['status'] == 'passed'
    packages = {p['name']: p for p in summary['packages']}
    policy = {
        'version': 'Campaign V4', 'built_from_originals': True,
        'player': {'hp_factor': 10, 'max_speed_mps': 10, 'knockdown_hits_factor': 10,
                   'weapon_melee_incoming_factor': '1/20', 'difficulty_incoming_and_falling_factor': '1/20',
                   'regen_delay_factor': '1/10', 'regen_rate_factor': 10,
                   'vehicle_difficulty_and_collision_factor': '1/10'},
        'npc_hp': {'campaign_allies': 3, 'campaign_enemies': 2,
                   'base_allies': ['Guerilla', 'Civilian'], 'base_enemies': ['EDF', 'Marauder'],
                   'dlc_allies': ['Marauder', 'Civilian', 'Guerrilla prisoners'], 'dlc_enemies': ['EDF'],
                   'dlc_scripted_actors_preserved': ['mis_DLC_Dan', 'mis_DLC_RFCommander']},
        'npc_loadouts': 'original', 'weapons_nonexplosive_handheld_npc_vehicle_damage_factor': 3,
        'hammer_player_animset': {'default_npc_vehicle_damage_factor': 3, 'structural_damage_factor': 2,
                                  'reach_and_impulse': 'original', 'upgrade_links': 'original'},
        'ordinary_explosives': {'blast_crumble_human_falloff_radii_factor': 1.5,
                               'npc_vehicle_damage_factor': 2, 'structural_damage_factor': 1.5,
                               'direct_impact_factor': 2,
                               'names': ['remote_charge', 'mine', 'rocket', 'gauss_rifle', 'gauss_rifle_npc', 'nano_rifle_exp',
                                         'grinder_explosive', 'DLC_remote_charge', 'DLC_missilepod']},
        'thermobaric': {'radii_factor': 1, 'npc_vehicle_and_structural_damage_factor': 1.5,
                        'direct_impact_factor': 1.5},
        'explosion_preserved_fields': ['Impulse', 'FlinchRadius', 'flags', 'durations', 'unique IDs'],
        'environment_scripted_and_npc_only_explosion_offense': 'original',
        'shared_explosion_caveat': 'remote_charge and rocket are also used by turret records; no clone or player-only isolation',
        'vehicles': 'V3 semantic values exactly, retaining its separate misc/table scope',
        'reinforcements_delay_divisor': 2,
        'reinforcements_scope': ['raid_data', 'house_arrest', 'guerrilla_reinforcement', 'reinforcement_profile',
                                 'DLC equivalents when present'],
        'timers_factor': 3, 'timers_scope': ['Time_To_Complete', 'Time_To_Fail', 'Par_Time',
                                           'demolitions Time_Limit', 'Hostage_Kill_Time', 'mayhem Time_per_score'],
        'courier': 'Escape_Speed /3, integer ceiling; other driving modes and kill quotas original',
        'salvage_rewards_factor': 3, 'salvage_rewards_scope': 'explicit positive Salvage_Reward fields only',
        'uncertain_reward_currencies_morale_and_control': 'original',
        'ammo_factor': 5, 'ammo_scope': ['Max_Rounds', 'Max_Rounds_Upgrade', 'Ammo_Box_Restock',
                                       'Num_Magazines', 'demolitions activity Ammo'],
        'ammo_magazine_size_and_difficulty_pickup_multipliers': 'original; avoid an extra x5 multiplier',
        'remote_simultaneously_attached_limit': 'original upgrade progression, not ammunition capacity',
        'purchase_upgrade_cost_divisor': 2, 'cost_rounding': 'positive Int ceiling, minimum 1; original 0 stays 0',
        'unlock_and_upgrade_value_flags': 'original',
        'mode_scope': 'campaign and suitable offline DLC records; explicit MP/test records and templates original except exact V3 vehicle inheritance',
        'game_runtime_tested': False,
    }
    write_json(OUT/'policy.json', policy)
    changes = summary['changed_parameters']
    guide = f'''ULTIMATE MOD — CAMPAIGN V4: DỰNG LẠI TỪ ORIGINAL
Game: Red Faction Guerrilla Re-Mars-tered, chơi offline

CÀI ĐẶT
1. Thoát game. Sao lưu misc.vpp_pc và table.vpp_pc đang dùng.
2. Giải nén ZIP V4 và chép CẢ HAI FILE VPP vào thư mục game có hai file
   cùng tên, đồng ý thay thế. Không cần cài V2/V3 trước.
3. Muốn hoàn tác: thoát game, chép lại hai file đã sao lưu.
4. Nếu dùng công cụ quản lý mod ghi đè các bảng này, kiểm tra thứ tự nạp.
   V4 không cài hoặc thay đổi tiện ích RSL nhảy cao/chạy riêng.

CẤU HÌNH V4 — HỆ SỐ TÍNH TỪ ORIGINAL
- Alec: HP 550 -> 5500; giới hạn tốc độ 5 -> 10 m/s;
  chống gục x10, các hệ số giảm sát thương/hồi phục kiểu V3.
  Sát thương vũ khí/cận chiến tới người chơi /20 ở các trường dương
  thuộc bản campaign; difficulty damage taken và falling damage /20.
  Regen delay /10, regen rate x10, bảo vệ xe người chơi giữ mạnh.
  Đây là cấu hình gần bất khả xâm phạm; không vô hiệu hóa script thất bại.
- NPC campaign chính: Guerilla/Civilian HP x3; EDF/Marauder HP x2.
  Trang bị, tên súng, đội quân, pool xe spawn và cờ AI giữ ORIGINAL.
- Búa: chỉ tăng sát thương tấn công của AnimSet Player.xtbl.
  DefaultDamage/NPCDamage/VehicleDamage x3; StructureDamage x2.
  Tầm đánh, lực hất và liên kết búa/nâng cấp/vàng giữ ORIGINAL.
  StructureDamage thường/u1/u2/vàng: 3000 / 4000 / 5000 / 10000.
- Súng cầm tay không có mẫu nổ: NPC_Damage và Vehicle_Damage x3.
  Súng có mẫu nổ (Gauss/nano/grinder) ưu tiên hệ số nổ thấp hơn bên dưới.
  Không tăng nhịp bắn, giảm nạp đạn, độ giật hay tăng tốc độ đạn.
- Remote, mine, RPG và các mẫu nổ súng cầm tay được chọn:
  sát thương NPC/xe x2, sát thương công trình x1,5;
  Radius/CrumbleRadius/KnockdownRadius dương x1,5.
  KnockdownRadius ở bảng này cũng là mốc ngoài của sát thương người.
  Remote Radius 3 -> 4,5 m; RPG 3,65 -> 5,475 m.
- Thermobaric: sát thương NPC/xe/công trình x1,5; giữ các bán kính gốc,
  gồm bán kính chính 6,5 m. Không tăng thêm theo quy tắc damage súng x3.
  Sát thương va chạm và sát thương vùng là hai phần độc lập; mỗi trường
  chỉ được nhân một lần, không tạo hệ số x3 rồi nhân x2.
- Lực nổ Impulse, FlinchRadius, hiệu ứng, cơ chế kích nổ và ID giữ gốc.
  Mẫu nổ riêng của môi trường, nhiệm vụ, xe tăng và thiết bị NPC giữ gốc.
  Ngoại lệ dùng chung: một số turret tham chiếu mẫu remote/rocket cũng
  nhận thay đổi của mẫu đó. Không tách mẫu nổ hay tuyên bố chỉ Alec mạnh.
- Xe: giữ đúng giá trị V3 trong từng gói; 349 trường tốc độ/động cơ x1,5,
  73 trường HP x5, một ngưỡng tốc độ cho phép đánh lái hết góc giữ x3.
  Đây là các trường V3 đã chọn trong misc, không phải tất cả xe.
  vehicles.xtbl trong table vẫn là original, đúng phạm vi V3 trước đây.
- Tiếp viện: delay dương /2 trong raid, house arrest, profile EDF và viện
  binh đồng minh. Không tăng số quân, đổi đội hình hoặc loại xe.
- Hoạt động: thời gian hoàn thành, par time, thời gian rời xe cho phép,
  demolitions Time_Limit, thời gian trước khi EDF giết con tin x3.
  Mayhem Time_per_score x3. Không đổi ngưỡng chuyển pha tấn công của
  area defense, thời gian nạp asset hoặc thời gian restoration.
- Courier: chỉ Escape_Speed /3; 40 -> 14 và 25 -> 9 vì trường số nguyên.
  Các tốc độ Normal/Evade/Catch_Up và số mục tiêu cần hạ giữ gốc.
- Phần thưởng salvage: trường Salvage_Reward dương x3.
  Morale, giảm EDF control, bảng giá trị salvage rơi từ vật liệu và các
  trường Reward không rõ loại tiền giữ gốc, tránh tác động mở khóa.
- Đạn: Max_Rounds/Max_Rounds_Upgrade, Ammo_Box_Restock, Num_Magazines
  và Ammo của demolitions x5; Magazine_Size giữ gốc.
  Remote mang được 90, nâng cấp 150; giới hạn gắn đồng thời giữ tiến
  trình nâng cấp gốc. Không thêm cờ đạn vô hạn; hệ số pickup difficulty
  giữ gốc để không nhân tiếp thành x25.
- Chi phí mua/nâng cấp: Cost dương /2, số nguyên làm tròn lên.
  25 -> 13; giá 1 vẫn là 1; 0 giữ 0. Không nhân giảm lần hai qua difficulty.
  Không mở khóa sớm, sửa giá trị cấp nâng cấp hoặc đổi điều kiện nhiệm vụ.

PHẠM VI VÀ NGOẠI LỆ
- Dựng từ hai BACKUP mới nhất đã xác minh SHA-256. Không lấy thay đổi
  loadout, tên đội không hợp lệ hoặc dữ liệu lỗi từ Nexus/V3.
  Chỉ giá trị xe được lấy đúng từ V3 theo yêu cầu.
- Các bảng trùng trong misc/table có giá trị V4 giống nhau, trừ vehicles
  cố ý giữ phạm vi riêng V3. Còn phụ thuộc thứ tự nạp xe của engine.
- DLC offline: player rfg_PC_DLC cùng HP/tốc độ/bảo vệ; Marauder là phe
  nhân vật chính nên HP x3, EDF x2, tù nhân Guerilla x3.
  mis_DLC_Dan và mis_DLC_RFCommander giữ HP gốc vì là nhân vật scripted,
  không suy đoán phe thực tế chỉ từ nhãn Team. Các script có thể đổi phe.
- Không chủ đích sửa entry MP/test, template/editor hay online settings;
  giữ ngoại lệ dữ liệu xe V3. Một số định nghĩa vẫn dùng chung với MP;
  đây không phải bản đã kiểm thử hay khuyến nghị cho multiplayer.
- 0, -1 và các cờ đặc biệt được giữ. Trường số nguyên luôn làm tròn lên.
  Trường vắng mặt dùng mặc định gốc; không thêm tag hoặc sửa schema.

ẢNH HƯỞNG KHI CHƠI
- Đồng minh khỏe hơn nhưng vẫn có thể chết do friendly fire, xe đâm,
  nhà sập hoặc script. Bảo vệ Alec không bảo vệ mục tiêu nhiệm vụ.
- Sát thương súng dùng chung có thể tăng cho NPC cầm cùng loại súng.
  Trang bị gốc không có nghĩa sát thương súng của mọi NPC vẫn như gốc.
- Bán kính x1,5 bao phủ diện tích hình tròn lý thuyết x2,25; phá công trình
  x1,5 và búa phá x2 vẫn cần cẩn thận sát con tin/mục tiêu hộ tống.
  Vùng sát thương ngoài của remote là 8,25 m, của mine 14,25 m; Radius
  chính không phải ranh giới tuyệt đối của mọi hiệu ứng nổ.
- Quân tới nhanh hơn /2 có thể tăng giao tranh và tải CPU. Số lượng mỗi
  đợt giữ gốc; không đảm bảo số quân tồn tại đồng thời vẫn bằng gốc.
- Xe thuộc nhóm HP x5 của V3, kể cả xe địch, sẽ bền hơn tương đối so với
  súng x3 và nổ x2. Đây là hệ quả của việc giữ nguyên cấu hình xe V3.
- Tốc độ 10 m/s là giới hạn dữ liệu, không phải cam kết mọi trạng thái
  walking/running/sprinting đều di chuyển 10 m/s hoặc tỷ lệ mới riêng.

KIỂM TRA
- misc: 1208 tệp; table: 423 tệp, không thêm/xóa tệp.
- Đối chiếu {changes} giá trị số từ original; misc sửa 27 bảng, table 26.
- Đọc độc lập cấu trúc VPP: header, hash tên, offset, alignment, padding,
  chiều dài; giải nén đối chiếu toàn bộ 1631 payload.
- Cấu trúc XML, mọi tên/tham chiếu/cờ và nội dung ngoài phạm vi giữ gốc;
  tất cả XML đã sửa hợp lệ; không có vi phạm min/max mới.
- Mỗi gói giữ nguyên lỗi ký tự credits.xtbl có sẵn ở original;
  422/423 XTBL parse được. Không âm thầm sửa dữ liệu ngoài phạm vi.
- Chưa chạy thử trong game. Kiểm tra dữ liệu không xác nhận toàn bộ nhiệm
  vụ, cảm giác điều khiển, thứ tự nạp, FPS hay vật lý của engine.
  Nên thử nhiệm vụ giải cứu, hộ tống, demolitions và lái xe trên save phụ
  trước khi dùng làm bản chơi chính.

SHA-256 CỦA FILE V4
{packages['misc']['sha256']}  misc.vpp_pc
{packages['table']['sha256']}  table.vpp_pc

Báo cáo riêng chứa toàn bộ thay đổi original -> V4, policy, validation,
manifest và mã dựng bản mod. Các báo cáo V3 cũ chỉ mô tả bản V3.
'''
    (OUT/'HUONG_DAN.txt').write_text(guide, encoding='utf-8')
    (DOWNLOADS/'HUONG_DAN.txt').write_text(guide, encoding='utf-8')
    game_sums = ''.join(p['sha256']+'  '+p['name']+'.vpp_pc\n' for p in summary['packages'])
    (OUT/'SHA256SUMS.txt').write_text(game_sums)
    # Detailed comparative explosive report, including falloff endpoints.
    blast_rows = []
    selected = set(policy['ordinary_explosives']['names']) | {'thermo_rocket'}
    for fn in ('explosions.xtbl','dlc01_explosions.xtbl'):
        original = ET.parse(BASE/'campaign_v4_originals/misc'/fn).getroot()
        current = ET.parse(OUT/'roundtrip/misc'/fn).getroot()
        originals = {e.findtext('Name'): e for e in original.find('Table')}
        for record in current.find('Table'):
            name = record.findtext('Name')
            if name not in selected:
                continue
            row = {'file':fn, 'name':name}
            for tag in ('Radius','CrumbleRadius','KnockdownRadius','FlinchRadius',
                        'Structural_Damage','Human_Damage_Max','vehicle_damage_max','Impulse'):
                row['original_'+tag] = originals[name].findtext(tag)
                row['v4_'+tag] = record.findtext(tag)
            blast_rows.append(row)
    with (OUT/'explosives.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(blast_rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(blast_rows)
    report = f'''# Campaign V4 — dựng lại từ original

V4 dùng hai BACKUP gốc đã xác minh; chỉ giữ cấu hình xe từ V3. Trang bị NPC,
liên kết đội quân, xe spawn và điều kiện mở khóa giữ nguyên dữ liệu gốc.

**[Tải V4](../downloads/Ultimate_Mod_Campaign_v4.zip)** ·
[Báo cáo và mã dựng](../downloads/Ultimate_Mod_Campaign_v4_Reports.zip) ·
[Hướng dẫn đầy đủ](../downloads/HUONG_DAN.txt) ·
[Từng giá trị original → V4](campaign-v4-parameters.csv) ·
[Kiểm tra](campaign-v4-validation.json) · [Policy](campaign-v4-policy.json).

## Cấu hình

| Nhóm | V4 |
|---|---|
| Alec | HP 5500; giới hạn tốc độ 10 m/s; bảo vệ/hồi phục mạnh kiểu V3 |
| HP NPC campaign chính | Guerilla/Civilian ×3; EDF/Marauder ×2 |
| Trang bị NPC, đội hình, loại xe spawn | Original |
| Búa, từng bản thường/nâng cấp/vàng | Player AnimSet: sát thương NPC/xe/default ×3; công trình ×2; tầm/lực gốc |
| Súng cầm tay không có mẫu nổ | NPC/vehicle damage ×3; nhịp bắn/nạp/độ giật gốc |
| Remote, mine, RPG, Gauss/nano/grinder và DLC được chọn | Sát thương NPC/xe ×2; công trình ×1,5; các bán kính tác động dương ×1,5 |
| Thermobaric | Sát thương ×1,5; toàn bộ bán kính gốc, Radius 6,5 m |
| Lực hất nổ, FlinchRadius, hiệu ứng/ID/cờ | Original |
| Xe | Đúng giá trị V3 theo từng gói; các trường tốc độ/động cơ được chọn ×1,5 |
| Delay viện binh | Original ÷2; không tăng số quân mỗi đợt |
| Timer mục tiêu / grace period | ×3; giữ ngưỡng chuyển pha area defense |
| Courier | Chỉ Escape_Speed ÷3; làm tròn lên |
| Phần thưởng | Salvage_Reward dương ×3; morale/control và tiền thưởng chưa rõ loại giữ gốc |
| Đạn | Tổng mang theo, giới hạn nâng cấp, restock, số băng cấp và đạn demolitions ×5; cỡ băng gốc |
| Giá mua/nâng cấp | Cost dương ÷2, làm tròn lên; không giảm chồng difficulty |

Sát thương va chạm và sát thương vụ nổ là hai phần độc lập. Mỗi trường chỉ
nhân một lần; vũ khí có mẫu nổ không nhận thêm hệ số súng ×3. Cờ đạn vô hạn,
giới hạn gắn remote cùng lúc và giá trị cấp nâng cấp giữ gốc.

### Búa

| Bản | DefaultDamage, đòn đứng | StructureDamage | NPCDamage, đòn đứng |
|---|---:|---:|---:|
| Thường | 1500 → 4500 | 1500 → 3000 | 750 → 2250 |
| Nâng cấp 1 | 2000 → 6000 | 2000 → 4000 | 950 → 2850 |
| Nâng cấp 2 | 2500 → 7500 | 2500 → 5000 | 1150 → 3450 |
| Vàng | 5000 → 15000 | 5000 → 10000 | 2300 → 6900 |

Chỉ tăng sát thương tấn công trong `AnimSetName=Player.xtbl`. Các trường sát
thương nhận vào của người chơi được giảm riêng. Không tăng tầm/lực hất hay
sát thương tấn công của animset NPC; liên kết búa vàng và vũ khí búa giữ gốc.

### Nổ

| Mẫu | Radius gốc → V4 (m) | Crumble gốc → V4 (m) | Mốc ngoài sát thương người gốc → V4 (m) | Human max gốc → V4 | Structure gốc → V4 |
|---|---:|---:|---:|---:|---:|
'''
    for row in blast_rows:
        def pair(tag):
            return str(row['original_'+tag])+' → '+str(row['v4_'+tag])
        report += '| '+row['name']+' | '+' | '.join(pair(t) for t in ('Radius','CrumbleRadius','KnockdownRadius','Human_Damage_Max','Structural_Damage'))+' |\n'
    report += f'''
[CSV đầy đủ các mẫu nổ đã chọn](campaign-v4-explosives.csv). Số 0 và sentinel
âm giữ nguyên; không thêm trường vắng mặt. `KnockdownRadius` ở schema này
cũng là Human Damage Radius: `Radius` chính không phải ranh giới mọi tác động.
`FlinchRadius` và `Impulse` giữ gốc, kể cả khi vùng gây sát thương rộng hơn.

**Mẫu dùng chung:** remote_charge còn được turret_supergauss_solo/burst dùng;
rocket còn được các rocket turret dùng. Chỉnh mẫu ảnh hưởng cả các consumer
này. Không tạo mẫu mới, ID mới hoặc tách riêng người chơi.

Mẫu nổ riêng của môi trường, nhiệm vụ, xe tăng và thiết bị NPC như grenade,
shockade, singularity giữ công suất gốc. Gauss/nano/grinder có phần nổ nên
dùng mức thấp hơn súng thường. EDF_Super_Gauss có thể mua trong DLC nên cũng
áp dụng mức nổ này, dù mẫu nổ của nó có hậu tố `_npc`.

## Phạm vi và những điểm cần biết

- Dữ liệu gốc mới: misc SHA-256 `{packages['misc']['original_archive_sha256']}`;
  table `{packages['table']['original_archive_sha256']}`.
- Tất cả bảng trùng giữa hai gói có payload V4 giống nhau, trừ vehicles.xtbl.
  Xe giữ đúng giá trị V3: misc có 423 giá trị đổi (349 tốc độ/động cơ,
  73 HP, 1 ngưỡng tốc độ đánh lái); table vehicles vẫn gốc. Chưa xác nhận
  thứ tự ưu tiên nạp xe của engine.
- DLC offline: `rfg_PC_DLC` cùng cấu hình người chơi. Marauder đồng minh ×3,
  EDF ×2, các tù nhân Guerilla ×3. Hai nhân vật scripted `mis_DLC_Dan` và
  `mis_DLC_RFCommander` giữ HP gốc vì không đủ cơ sở phân loại phe runtime.
  Script có thể đổi phe; không suy rộng Team=Guerilla luôn đồng minh trong DLC.
- Các entry MP/test, schema và template giữ gốc ngoài dữ liệu xe V3 được
  yêu cầu giữ. Định nghĩa dùng chung vẫn có thể ảnh hưởng chế độ khác;
  bản phát hành dành cho offline, không có kiểm thử multiplayer.
- `Hostage_Kill_Time` 30 → 90, 60 → 180: tăng thời gian trước khi EDF bắt đầu
  giết con tin. Không vô hiệu hóa thất bại do con tin chết hay công trình sập.
- Chỉ tăng trường `Salvage_Reward` rõ loại tiền. Reward của angel_of_mercy
  là morale, của assassin là EDF control nên giữ gốc; Reward mơ hồ khác
  và salvage rơi từ vật liệu không tự tăng.
- Đạn remote 18/30 → 90/150 là lượng mang theo; giới hạn đặt cùng lúc vẫn
  theo cấp nâng cấp gốc. `Magazine_Size`, hệ số pickup/crate difficulty và
  các cờ gốc giữ nguyên để tránh tăng chồng ngoài hệ số đã chọn.
- God config không bảo vệ mọi mục tiêu nhiệm vụ. Đồng minh có HP cao hơn
  nhưng vẫn chịu friendly fire, vật lý, nhà sập và script. Sát thương súng
  dùng chung cũng tăng cho NPC cầm cùng loại, dù loadout vẫn nguyên bản.
- Bán kính ×1,5 có diện tích hình tròn lý thuyết ×2,25; vẫn tránh dùng thuốc
  nổ sát con tin. Reinforcement ÷2 có thể tăng mật độ quân và tải CPU.
- Các xe được giữ HP ×5 từ V3, kể cả xe địch, bền hơn tương đối so với
  súng ×3/nổ ×2; giữ cấu hình xe V3 cũng giữ hệ quả cân bằng này.
- Tốc độ 10 m/s là giới hạn trong bảng, không phải thay đổi riêng tỷ lệ
  walking/running/sprinting. V4 không kèm hoặc chỉnh tiện ích RSL cũ.

## Xác minh bản dựng

- {changes} giá trị thay đổi so với original: misc {packages['misc']['changed_parameters']}
  trong {packages['misc']['changed_files']} bảng; table {packages['table']['changed_parameters']}
  trong {packages['table']['changed_files']} bảng. Số này đếm cả hai bản sao
  của bảng chung; không phải số hiệu ứng gameplay độc lập.
- Giữ nguyên tên và số lượng 1208/423 tệp. Đọc độc lập header, hash tên,
  offset, padding, chiều dài; giải nén đối chiếu toàn bộ 1631 payload.
- So sánh mọi đường dẫn XML, công thức, kiểu Int, sentinel, trường văn bản,
  dữ liệu ngoài phạm vi; không có vi phạm min/max mới. Các asset nhị phân
  không đổi. Không thêm tên/tham chiếu nên không mang sang các liên kết
  lỗi do Nexus mod từng tạo; điều này không chứng minh mọi script runtime.
- Mọi XML sửa hợp lệ. Mỗi gói còn lỗi ký tự trong credits.xtbl có sẵn ở
  original, giữ nguyên byte; 422/423 XTBL parse được.
- **Chưa chạy thử trong game.** Chưa xác nhận mọi nhiệm vụ, FPS, vật lý hoặc
  thứ tự nạp; thử giải cứu/hộ tống/demolitions/lái xe trên save phụ trước.

## SHA-256 file game

```text
{game_sums.rstrip()}
```

Các báo cáo cân bằng, chuyển động và nổ có chữ V3 trong kho mô tả bản V3.
Báo cáo này và CSV V4 là nguồn đối chiếu cho bản mới.
'''
    (OUT/'README.md').write_text(report,encoding='utf-8')
    (REPORTS/'campaign-v4.md').write_text(report,encoding='utf-8')
    for source, dest in [('parameters.csv','campaign-v4-parameters.csv'),
                         ('summary.json','campaign-v4-summary.json'),
                         ('validation.json','campaign-v4-validation.json'),
                         ('policy.json','campaign-v4-policy.json'),
                         ('explosives.csv','campaign-v4-explosives.csv')]:
        shutil.copyfile(OUT/source,REPORTS/dest)
    code = OUT/'code'
    code.mkdir(exist_ok=True)
    for source in [BASE/'rebalance_work/build_campaign_v4.py',
                   BASE/'rebalance_work/release_campaign_v4.py',
                   BASE/'rebalance_work/rebalance_rules.py',BASE/'rebalance_work/verify_balance.py',
                   BASE/'repair_ultimate.py',BASE/'vpp_compare.py']:
        shutil.copyfile(source,code/source.name)
    (code/'README.txt').write_text('''Mã dựng và kiểm tra V4. Python 3.10+; chỉ thư viện chuẩn.
build_campaign_v4.py là entry point; không chạy CLI của các module legacy.
rebalance_rules: chỉ dùng bộ đọc XML/Decimal/schema/format, không dùng rule cũ.
verify_balance: dùng bộ đọc VPP độc lập, bản đồ XML và kiểm tra min/max.
repair_ultimate: chỉ dùng pack_raw; vpp_compare: dùng bộ giải nén độc lập.

Lệnh dựng:
python build_campaign_v4.py --analysis-root /path/to/analysis --output /new/output

Cần original đã giải nén, manifest, raw original templates và dữ liệu xe V3
theo layout mô tả ở đầu build_campaign_v4.py. Nguồn V3 có ở ZIP V3 trên GitHub.
request_and_pending_policy.json chứa vị trí/SHA nguồn original; cập nhật
đường dẫn cho bản sao cục bộ của chính bạn, không đổi SHA đã xác minh.
Các raw template đã được đối chiếu toàn bộ payload với BACKUP gốc; writer
được calibration bằng cách tái đóng gói nguyên mẫu và so sánh từng byte.
rebuild không cần chạy hoặc tải bất cứ executable của game/Nexus.

release_campaign_v4.py tạo tài liệu/ZIP trong workspace dùng để phát hành;
không cần để chơi. Các đường dẫn workspace trong script này cần điều chỉnh
nếu muốn tạo lại gói phát hành ở máy khác. Chưa có kiểm thử game runtime.
''',encoding='utf-8')
    main_zip = DOWNLOADS/'Ultimate_Mod_Campaign_v4.zip'
    with zipfile.ZipFile(main_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for package in ('misc','table'):
            z.write(OUT/'game_files'/(package+'.vpp_pc'),package+'.vpp_pc')
        z.write(OUT/'HUONG_DAN.txt','HUONG_DAN.txt')
        z.write(OUT/'SHA256SUMS.txt','SHA256SUMS.txt')
    # Capture exact original validation/provenance without redistributing originals.
    provenance = OUT/'source_evidence'
    provenance.mkdir(exist_ok=True)
    for name in ['request_and_pending_policy.json','raw_original_validation.json',
                 'misc_manifest.json','table_manifest.json']:
        shutil.copyfile(BASE/'campaign_v4_originals'/name,provenance/name)
    reports_zip = DOWNLOADS/'Ultimate_Mod_Campaign_v4_Reports.zip'
    with zipfile.ZipFile(reports_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in ['README.md','HUONG_DAN.txt','SHA256SUMS.txt','policy.json','parameters.csv',
                     'parameters.json','files.csv','summary.json','validation.json',
                     'explosives.csv','misc_manifest.json','table_manifest.json']:
            z.write(OUT/name,name)
        for folder in (code,provenance):
            for p in sorted(folder.iterdir()):
                if p.is_file():
                    z.write(p,p.relative_to(OUT))
    # Read back final distributable ZIP: CRC, entry set and exact VPP hashes.
    artifact_checks = {}
    for path in (main_zip,reports_zip):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            assert len(z.namelist()) == len(set(z.namelist()))
            if path == main_zip:
                assert set(z.namelist()) == {'misc.vpp_pc','table.vpp_pc','HUONG_DAN.txt','SHA256SUMS.txt'}
                for package in ('misc','table'):
                    assert sha(z.read(package+'.vpp_pc')) == packages[package]['sha256']
            else:
                assert json.loads(z.read('validation.json'))['status'] == 'passed'
        artifact_checks[path.name] = {'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'zip_crc_passed':True}
    write_json(OUT/'release_validation.json',{'status':'passed','artifacts':artifact_checks,'game_runtime_tested':False})
    shutil.copyfile(OUT/'release_validation.json',REPORTS/'campaign-v4-release-validation.json')
    old_sums = (DOWNLOADS/'SHA256SUMS.txt').read_text().splitlines()
    retained = [line for line in old_sums if line and line.split()[-1] not in
                {'misc.vpp_pc','table.vpp_pc',main_zip.name,reports_zip.name}]
    new_sums = game_sums+'\n'.join(retained)+'\n'
    for name, meta in artifact_checks.items():
        new_sums += meta['sha256']+'  '+name+'\n'
    (DOWNLOADS/'SHA256SUMS.txt').write_text(new_sums)
    print(json.dumps(artifact_checks,indent=2))


if __name__=='__main__':
    main()
