Mã dựng và kiểm tra V4. Python 3.10+; chỉ thư viện chuẩn.
build_campaign_v4.py là entry point; không chạy CLI của các module legacy.
rebalance_rules: chỉ dùng bộ đọc XML/Decimal/schema/format, không dùng rule cũ.
verify_balance: dùng bộ đọc VPP độc lập, bản đồ XML và kiểm tra min/max.
repair_ultimate: chỉ dùng pack_raw; vpp_compare: dùng bộ giải nén độc lập.

Lệnh dựng:
python build_campaign_v4.py --analysis-root /path/to/analysis --output /new/output

Cần original đã giải nén, manifest, raw original templates và dữ liệu xe V3
theo layout mô tả ở đầu build_campaign_v4.py. Nguồn V3 có ở ZIP V3 trên GitHub.
request_and_pending_policy.json chứa vị trí/SHA nguồn original; cập nhật
đường dẫn cho bản sao cục bộ của chính bạn, không đổi SHA đã xác minh.
Các raw template đã được đối chiếu toàn bộ payload với BACKUP gốc; writer
được calibration bằng cách tái đóng gói nguyên mẫu và so sánh từng byte.
rebuild không cần chạy hoặc tải bất cứ executable của game/Nexus.

release_campaign_v4.py tạo tài liệu/ZIP trong workspace dùng để phát hành;
không cần để chơi. Các đường dẫn workspace trong script này cần điều chỉnh
nếu muốn tạo lại gói phát hành ở máy khác. Chưa có kiểm thử game runtime.
