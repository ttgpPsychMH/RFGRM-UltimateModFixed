"""Explicit, reviewable V4.2 targets accepted in the backpack proposal.

Each tuple is (relative route, expected V4.1 text, new text, rationale).
Only current schema fields may be added to the three fuel override records.
Timings derived from fuel are illustrative, not measured game behavior.
"""

BACKPACKS = {
    'Jetpack': [
        ('jetpack/fuel_use_per_second','0.3','0.075','longer_flight'),
        ('jetpack/fuel_regen_per_second','0.15','0.5','faster_refill'),
    ],
    'Fleetfoot': [
        ('activatable/active_abilities/movement_speed_factor','1.45','2','active_speed_x2'),
        ('activatable/uses_fuel/fuel_use_per_second','0.18','0.04','longer_active_time'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.15','0.4','faster_refill'),
        ('activatable/uses_fuel/fuel_activation_cost','0.05','0.02','lower_activation_cost'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','0.25','0.1','partial_fuel_activation'),
        ('activatable/no_fine_aim','True','False','allow_fine_aim_while_active'),
    ],
    'Heal': [
        ('activatable/uses_fuel/fuel_use_per_second','0.91','0.05','longer_active_time'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.10','0.4','faster_refill'),
        ('activatable/uses_fuel/fuel_activation_cost','0.05','0.02','lower_activation_cost'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1.0','0.1','partial_fuel_activation'),
        ('activatable/active_abilities/health_regen/health_regen_per_second','450','900','healing_rate'),
        ('activatable/active_abilities/health_regen/health_regen_radius','5.8','10','healing_radius'),
        ('activatable/active_abilities/health_regen/health_regen_heal_enemies','True','False','disable_enemy_healing'),
    ],
    'Rhino': [
        ('activatable/active_abilities/rhino/rhino_top_speed','8','14','align_existing_legacy_charge_speed'),
        ('activatable/active_abilities/charge/charge_top_speed','8.2','14','longer_faster_charge'),
        ('activatable/uses_fuel/fuel_use_per_second','1.3','0.5','two_second_full_fuel_charge_model'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.2','0.5','faster_refill'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1.0','0.25','partial_fuel_activation'),
        ('activatable/deactivatable/player_deactivatable','False','True','manual_charge_cancel'),
    ],
    'Thrust': [
        ('activatable/active_abilities/jump_boost/jump_boost_vertical','10','15','vertical_velocity_boost_x1_5'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.2','0.5','faster_refill'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1','0.25','partial_fuel_activation'),
    ],
    'Tremor': [
        ('activatable/uses_fuel/fuel_use_per_second','0.25','0.5','short_controlled_burst'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.12','0.4','faster_refill'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1.0','0.5','partial_fuel_activation'),
    ],
    'Shockwave': [
        ('activatable/active_abilities/ripple/ripple_range','6','8','crowd_control_range'),
        ('activatable/active_abilities/ripple/ripple_player_hit_speed','12','18','character_push_x1_5'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.22','0.25','one_charge_refill_model_two_seconds'),
        ('activatable/uses_fuel/fuel_activation_cost','1','0.5','two_uses_from_full_fuel_model'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1','0.5','activation_threshold_matches_cost'),
    ],
    'Commando': [
        ('activatable/active_abilities/direct_damage_dealt_factor','1.25','2','firepower_direct_damage'),
        ('activatable/active_abilities/area_damage_dealt_factor','1.25','1','preserve_base_explosive_damage_while_active'),
        ('activatable/active_abilities/reload_speed_factor','1','0.7','reload_duration_reduced_30_percent'),
        ('activatable/uses_fuel/fuel_use_per_second','0.15','0.05','longer_active_time'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.125','0.4','faster_refill'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','1.0','0.25','partial_fuel_activation'),
    ],
    'Vision': [
        ('activatable/uses_fuel/fuel_use_per_second','0.12','0.035','longer_active_time'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.125','0.4','faster_refill'),
        ('activatable/uses_fuel/fuel_activation_cost','0.1','0.02','lower_activation_cost'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','0.25','0.1','partial_fuel_activation'),
        ('activatable/active_abilities/vision/vision_vfx/vision_vfx_ramp_in_time_ms','250','100','faster_visual_transition'),
        ('activatable/active_abilities/vision/vision_vfx/vision_vfx_ramp_out_time_ms','250','100','faster_visual_transition'),
    ],
    'Stealth': [
        ('activatable/uses_fuel/fuel_use_per_second','0.075','0.033','longer_active_time'),
        ('activatable/uses_fuel/fuel_regen_per_second','0.09','0.4','faster_refill'),
        ('activatable/uses_fuel/fuel_activation_cost','0.1','0.02','lower_activation_cost'),
        ('activatable/uses_fuel/minimum_fuel_to_activate','0.25','0.1','partial_fuel_activation'),
        ('activatable/active_abilities/stealth/stealth_time_ms','1000','250','faster_cloaking_transition'),
        ('activatable/active_abilities/stealth/restealth_time_ms','1000','500','faster_recloaking_delay'),
    ],
}

# Each override lists all four supported fuel fields explicitly, so no old
# per-mode override can restore a conflicting drain/regeneration/threshold.
OVERRIDES = {
    'Commando': [
        ('uses_fuel/fuel_use_per_second',None,'0.05','sync_override_fuel'),
        ('uses_fuel/fuel_regen_per_second','0.1','0.4','sync_override_fuel'),
        ('uses_fuel/fuel_activation_cost',None,'0','sync_override_fuel'),
        ('uses_fuel/minimum_fuel_to_activate',None,'0.25','sync_override_fuel'),
    ],
    'Vision': [
        ('uses_fuel/fuel_use_per_second','0.15','0.035','sync_override_fuel'),
        ('uses_fuel/fuel_regen_per_second','0.11','0.4','sync_override_fuel'),
        ('uses_fuel/fuel_activation_cost','0.2','0.02','sync_override_fuel'),
        ('uses_fuel/minimum_fuel_to_activate',None,'0.1','sync_override_fuel'),
    ],
    'Stealth': [
        ('uses_fuel/fuel_use_per_second','0.1','0.033','sync_override_fuel'),
        ('uses_fuel/fuel_regen_per_second',None,'0.4','sync_override_fuel'),
        ('uses_fuel/fuel_activation_cost',None,'0.02','sync_override_fuel'),
        ('uses_fuel/minimum_fuel_to_activate',None,'0.1','sync_override_fuel'),
    ],
}

EXPLOSIONS = {
    'mp_shockwave_blast': [('Structural_Damage','15000','3000','concussion_structural_damage_reduced_80_percent')],
    'mp_quake': [('Structural_Damage','2500','3750','tremor_structural_damage_per_pulse_x1_5')],
}

PROFILE = {'mp_backpacks.xtbl':BACKPACKS,
           'mp_backpack_overrides.xtbl':OVERRIDES,
           'explosions.xtbl':EXPLOSIONS}

DISPLAY_NAMES = {'Commando':'Firepower','Shockwave':'Concussion'}

LIMITATIONS = [
    'Fuel timing is a model assuming capacity=1, regeneration paused while active, no engine or upgrade modifiers. It is not measured runtime behavior.',
    'Jetpack flight height, lift and ceiling have no verified knob here. Lower drain does not guarantee a higher ceiling.',
    'Heal schema says players; NPC/hostage support in campaign is unverified.',
    'Stealth AI detection and Vision campaign behavior are unverified.',
    'Fleetfoot target speed depends on engine ordering, animation and speed caps; factor=2 does not prove measured 20m/s.',
    'Rhino distance depends on collision, input and activation handling; 28m is an unobstructed fuel-model estimate.',
    'Definitions are shared with MP and Wrecking Crew. This release is for offline play; no runtime tests have been performed.',
]
