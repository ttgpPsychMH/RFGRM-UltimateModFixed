"""Byte-preserving XML inventory and explicit, original-based balance rules."""
from collections import Counter
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from pathlib import Path
import re
from xml.parsers import expat

NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")


@dataclass
class Node:
    tag: str
    start: int
    text_start: int
    parent: object = None
    children: list = field(default_factory=list)
    end: int = 0
    text_end: int = 0
    value: str = ""
    path: str = ""

    def child(self, tag):
        return next((c for c in self.children if c.tag == tag), None)

    def get(self, route):
        node = self
        for tag in route.split("/"):
            node = node.child(tag) if node else None
        return node.value if node else None

    def ancestor(self, tag):
        node = self
        while node is not None:
            if node.tag == tag:
                return node
            node = node.parent
        return None


def xml_inventory(blob):
    parser = expat.ParserCreate()
    stack, all_nodes = [], []

    def start(tag, attrs):
        at = parser.CurrentByteIndex
        end = blob.index(b">", at) + 1
        node = Node(tag, at, end, stack[-1] if stack else None)
        if stack:
            stack[-1].children.append(node)
        all_nodes.append(node)
        stack.append(node)

    def finish(tag):
        node = stack.pop()
        node.end = parser.CurrentByteIndex
        node.text_end = node.children[0].start if node.children else node.end
        # Empty self-closing tags have no text region.
        if blob[node.start:node.text_start].rstrip().endswith(b"/>"):
            node.text_end = node.text_start
        node.value = blob[node.text_start:node.text_end].decode("utf-8").strip()

    parser.StartElementHandler = start
    parser.EndElementHandler = finish
    parser.Parse(blob, True)
    root = all_nodes[0]
    result = {}

    def paths(node, path):
        node.path = path
        result[path] = node
        seen = Counter()
        for c in node.children:
            label = c.tag
            if c.get("Name") is not None:
                label += "[Name=" + c.get("Name") + "]"
                if c.get("_Editor/Category") is not None:
                    label += "[Category=" + c.get("_Editor/Category") + "]"
            seen[label] += 1
            paths(c, path + "/" + label + f"[{seen[label]}]")
    paths(root, "/" + root.tag)
    return root, result


def decimal(value):
    if not NUMBER.fullmatch(value):
        return None
    try:
        return Decimal(value)
    except InvalidOperation:
        return None


def fmt(value):
    text = format(value, "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def is_hammer(node):
    record = node.ancestor("Weapon") or node.ancestor("MeleeMove")
    name = record.get("Name") if record else ""
    return bool(name and ("sledge" in name.lower() or "hammer" in name.lower()))


def rule(filename, old, mod):
    """Return arithmetic and rationale using the confirmed user policies."""
    tag = mod.tag
    original = decimal(old.value)
    if (filename == "vehicles.xtbl" and tag == "Max_RPM" and original is not None
            and decimal(mod.value) is None and mod.ancestor("Vehicle").get("Name") == "Min_SupplyTruck_3"):
        # The supplied mod splits 3200 as '32\r\n\t\t\t00'. This is an
        # already-modified Float field with a valid original value of 3000.
        return Decimal(10), "vehicle_rpm_x10_repair_malformed_mod_float"
    if original is None or decimal(mod.value) is None:
        return None, "keep_mod_non_numeric"
    if original <= 0:
        return None, "keep_mod_zero_or_negative_original"
    character = mod.ancestor("Character")
    if filename == "character.xtbl" and tag == "Height" and character and character.get("Name") == "rfg_PC":
        return None, "confirmed_keep_mod_height"
    if filename == "character.xtbl":
        if tag == "max_hit_points":
            record = old.ancestor("Character")
            name, team = record.get("Name"), record.get("Team")
            if name == "rfg_PC" or name.startswith("rfg_PC_"):
                return Decimal(10), "main_player_hp_x10"
            if team in ("Guerilla", "Civilian"):
                return Decimal(5), "ally_hp_x5"
            if team in ("EDF", "Marauder"):
                return Decimal(3), "enemy_hp_x3"
            raise ValueError("Unknown character team: " + str((name, team)))
        if tag in ("max_speed", "knock_down_hits", "Height"):
            return Decimal(10), "player_mobility_or_resistance_x10"
    if filename == "difficulty.xtbl":
        item = old.ancestor("Item")
        name = item.get("Name") if item else ""
        if name in ("MENU_PLAYER_DAMAGE_TAKEN", "MENU_PLAYER_FALLING_DAMAGE"):
            return Decimal(1)/20, "player_damage_div20"
        if name in ("MENU_PLAYER_REGEN_DELAY", "MENU_PLAYER_VEHICLE_DAMAGE", "MENU_UPGRADE_COST_MULTIPLIER"):
            return Decimal(1)/10, "unfavorable_difficulty_factor_div10"
        if name in ("MENU_PLAYER_REGEN_RATE", "MENU_PLAYER_AMMO_CRATES", "MENU_PLAYER_AMMO_PICKUP", "MENU_MORALE_BOOSTS", "MENU_CONTROL_PARKER"):
            return Decimal(10), "favorable_difficulty_factor_x10"
    if filename == "weapons.xtbl":
        if tag == "Player_Damage":
            return Decimal(1)/20, "player_damage_div20"
        if tag in {"Player_Vehicle_Damage", "Default_Refire_Delay", "Default_Reload_Delay", "Reload_Delay", "Recoil_Kick", "Spread_Min", "Spread_Max", "Spread_Fine_Aim_Min", "Overheat_Cool_Down_Time", "Overheat_Percent_Per_Shot", "Min_Engagement_Distance", "Sound_Radius"}:
            return Decimal(1)/20, "unfavorable_weapon_factor_div20"
        if tag in {"NPC_Damage", "Vehicle_Damage", "Magazine_Size", "Num_Magazines", "Max_Rounds", "Max_Rounds_Upgrade", "Ammo_Box_Restock", "Range_Max", "Range_Red", "Max_Engagement_Distance", "Headshot_Multiplier", "Start_Speed", "Max_Speed", "Autoaim_override", "To_Spread_Max", "Threshold"}:
            return Decimal(20), "favorable_weapon_factor_x20"
    if filename == "activity_air_strike_defense.xtbl" and tag == "Num_bombers_to_kill":
        return Decimal(1)/10, "required_enemy_count_div10"
    if filename == "activity_area_defense.xtbl":
        if tag in ("Required_kills", "Kill_Limit"):
            return Decimal(1)/10, "required_enemy_count_div10"
        if tag == "Salvage_Reward":
            return Decimal(10), "reward_x10"
    if filename == "activity_courier_chase.xtbl" and tag == "Escape_Speed":
        return Decimal(1)/10, "courier_escape_speed_div10"
    if filename in ("activity_demolitions_master.xtbl", "activity_timed_delivery.xtbl"):
        if tag in ("Par_Time", "Time_Limit", "Time_To_Complete", "Ammo", "Vehicle_Health", "Vehicle_Hit_Points"):
            return Decimal(10), "activity_time_ammo_or_vehicle_health_x10"
    if filename in ("activity_house_arrest.xtbl", "raid_data.xtbl") and tag in ("spawn_delay", "SpawnDelay"):
        squad = old.parent.get("SquadType") or old.parent.get("squad_def")
        if squad.startswith("guerilla_"):
            return Decimal(1)/10, "ally_reinforcement_delay_div10"
        if squad.startswith("basic_"):
            return Decimal(10), "enemy_reinforcement_delay_x10"
        raise ValueError("Unknown reinforcement squad: " + str(squad))
    if filename == "tweak_table.xtbl" and tag == "Value":
        name = old.parent.get("Name")
        if name in ("Vehicle_player_damage_factor", "Stuntman_min_height_for_bonus"):
            return Decimal(1)/10, "vehicle_damage_or_bonus_requirement_div10"
    if filename == "vehicles.xtbl":
        if tag in {"Torque", "Max_Hitpoints", "EnforcedMaxSpeed", "EnforcedMaxRSpeed", "Min_RPM", "Opt_RPM", "Max_RPM", "Max_Speed_Steering"}:
            return Decimal(10), "shared_vehicle_capacity_x10"
    if filename == "explosions.xtbl":
        if tag in ("player_veh_mult", "player_vehicle_impulse_mult"):
            return Decimal(1)/10, "player_vehicle_damage_or_impulse_div10"
        if tag in {"Radius", "CrumbleRadius", "KnockdownRadius", "FlinchRadius", "vehicle_damage_max", "vehicle_damage_min", "human_damage_min", "Human_Damage_Max", "Structural_Damage"}:
            return Decimal(10), "shared_explosion_radius_or_damage_x10"
    if filename == "melee.xtbl" and tag in {"HitRange", "HitRadius", "ImpactForce"}:
        return Decimal(10), "melee_reach_or_impulse_x10"
    raise ValueError("Unclassified numeric field: " + filename + ": " + mod.path)


def override(filename, old, mod):
    """Explicitly authorized extra fields: hammer damage and bound companions.

    Returns (factor, literal, explanation), or None for the standard scope.
    """
    tag = mod.tag
    weapon = mod.ancestor("Weapon")
    move = mod.ancestor("MeleeMove")
    vehicle = mod.ancestor("Vehicle")
    if filename == "weapons.xtbl" and weapon:
        name = weapon.get("Name")
        old_weapon = old.ancestor("Weapon")
        if name in {"sledgehammer", "golden_hammer"} and tag == "NPC_Damage":
            return None, old.value, "hammer_restore_original_weapon_damage_zero"
        if name == "golden_hammer" and tag in {"StandingPrimary", "StandingTertiary", "CrouchingPrimary", "CrouchingTertiary"}:
            return None, old.value, "hammer_restore_gold_move_reference"
        if name == "turretX_arcwelder" and tag == "Max_Rounds_Upgrade" and old_weapon.get("Max_Rounds") != weapon.get("Max_Rounds"):
            return Decimal(20), None, "extra_bound_companion_ammo_upgrade_capacity_x20"
        if weapon.get("_Editor/Category") == "Entries:MP Overrides":
            if name in {"edf_pistol", "autoblaster"} and tag == "Spread_Min" and old_weapon.get("Spread_Max") != weapon.get("Spread_Max"):
                return Decimal(1)/20, None, "extra_bound_companion_spread_min_div20"
            if name in {"m16", "enforcer", "autoblaster"} and tag == "Threshold" and mod.parent.tag == "Damage_Scaling_Max" and old_weapon.get("Damage_Scaling_Min/Threshold") != weapon.get("Damage_Scaling_Min/Threshold"):
                return Decimal(20), None, "extra_bound_companion_threshold_max_x20"
    if filename == "vehicles.xtbl" and vehicle and vehicle.get("Name") == "Col_FixedFlatbed_2" and tag in {"Opt_RPM", "Max_RPM"} and old.ancestor("Vehicle").get("Engine/Min_RPM") != vehicle.get("Engine/Min_RPM"):
        return Decimal(10), None, "extra_bound_companion_engine_rpm_x10"
    if filename == "melee.xtbl" and move:
        name = move.get("Name") or ""
        base = {"sledgehammer_melee_side", "sledgehammer_melee_vert"}
        upgrades = {"sledgehammer_melee_side_u1", "sledgehammer_melee_side_u2", "sledgehammer_melee_vert_u1", "sledgehammer_melee_vert_u2"}
        gold = {"sledgehammer_melee_side_gold", "sledgehammer_melee_vert_gold"}
        if name in base | upgrades | gold and decimal(old.value) is not None and not mod.children:
            if tag in {"PlayerDamage", "PlayerDamageFromNPC"}:
                return Decimal(1)/20, None, "hammer_incoming_player_damage_div20"
            if tag in {"DefaultDamage", "NPCDamage", "StructureDamage", "VehicleDamage"}:
                multiplier = 50 if name in base else 20 if name in upgrades else 100
                return Decimal(multiplier), None, "hammer_original_damage_x" + str(multiplier)
    return None


def schema_types(root):
    result = {}
    description = root.child("TableDescription")
    def walk(node):
        if node.tag == "Element":
            name, kind = node.get("Name"), node.get("Type")
            if name and kind:
                result.setdefault(name, set()).add(kind)
        for c in node.children:
            walk(c)
    if description:
        walk(description)
    return result


def calculate(original, factor, kinds):
    desired = original * factor
    if "Int" in kinds and desired != desired.to_integral_value():
        # Counts and millisecond delays must remain integers; round upward
        # so positive requirements/delays do not become zero.
        return desired.to_integral_value(rounding=ROUND_CEILING), "ceil_to_integer"
    return desired, "exact"


def plan_file(filename, original_blob, mod_blob):
    old_root, before = xml_inventory(original_blob)
    mod_root, after = xml_inventory(mod_blob)
    types = schema_types(old_root)
    changes, replacements = [], []
    for path, node in after.items():
        old = before.get(path)
        if old is None:
            continue
        extra = override(filename, old, node)
        if old.value == node.value and extra is None:
            continue
        literal = None
        if extra:
            factor, literal, why = extra
        else:
            factor, why = rule(filename, old, node)
        row = dict(path=path, tag=node.tag, original=old.value, mod=node.value,
                   planned=node.value, rule=why, factor=None, rounding=None,
                   schema_types=sorted(types.get(node.tag, set())),
                   originally_modified=old.value != node.value,
                   authorized_exception=extra is not None)
        if factor is not None:
            value, rounding = calculate(decimal(old.value), factor, types.get(node.tag, set()))
            row.update(planned=fmt(value), factor=fmt(factor), rounding=rounding)
        elif literal is not None:
            row.update(planned=literal, rounding="literal_original_restore")
        if factor is not None or literal is not None:
            raw = mod_blob[node.text_start:node.text_end]
            start = node.text_start + len(raw) - len(raw.lstrip())
            end = node.text_end - (len(raw) - len(raw.rstrip()))
            if node.value != row["planned"]:
                replacements.append((start, end, row["planned"].encode("ascii")))
        changes.append(row)
    patched = mod_blob
    for start, end, value in sorted(replacements, reverse=True):
        patched = patched[:start] + value + patched[end:]
    _, check = xml_inventory(patched)
    intended = {r["path"]:r["planned"] for r in changes}
    if after.keys() != check.keys():
        raise ValueError("XML structure changed")
    for path, node in check.items():
        if node.value != intended.get(path, after[path].value):
            raise ValueError("Untargeted XML value changed: " + path)
    return changes, patched
