#!/usr/bin/env python3
"""Package validated V4.2 archives and truthful configuration/runtime notes."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

BASE=Path('/workspace/rfgrm-vpp-analysis')
OUT=BASE/'campaign_v4_2'
REPO=Path('/workspace/RFGRM-UltimateModFixed')
REPORTS=REPO/'reports'
DL=REPO/'downloads'


def sha(blob):return hashlib.sha256(blob).hexdigest()


def write_json(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    summary=json.loads((OUT/'summary.json').read_text())
    validation=json.loads((OUT/'validation.json').read_text());assert validation['status']=='passed'
    packages={r['name']:r for r in summary['packages']}
    model=json.loads((OUT/'fuel-model.json').read_text())
    sums=''.join(p['sha256']+'  '+p['name']+'.vpp_pc\n' for p in summary['packages'])
    (OUT/'SHA256SUMS.txt').write_text(sums)
    guide=f'''RFGRM — CAMPAIGN V4.2 BACKPACKS
Red Faction Guerrilla Re-Mars-tered — chơi offline

CÀI ĐẶT / HOÀN TÁC
1. Thoát game; sao lưu misc.vpp_pc và table.vpp_pc đang dùng.
2. Giải nén ZIP V4.2, chép CẢ HAI VPP vào thư mục game chứa hai file cùng
   tên, đồng ý thay thế. Đây là gói đầy đủ, không cần cài V4/V4.1 trước.
3. Muốn quay lại thì thoát game, chép lại bản sao lưu hoặc hai VPP từ ZIP V4.1.
4. Mod manager/RSL có thể thay đổi thứ tự nạp hoặc hành vi runtime.
   V4.2 không tự cài hook, plugin, RSL, mở khóa backpack hay trang bị cho NPC.

NỀN V4.1 GIỮ NGUYÊN
Alec HP 5500 / giới hạn tốc độ cấu hình 10 m/s / bảo vệ mạnh; búa NPC x10,
xe x20, công trình x5, DefaultDamage x5 original; tầm x1,25, lực x1,5;
nhặt salvage chờ 250 ms, đặt giữ 100% salvage sau chết; giật/tản súng
giảm 20%; các thiết lập NPC, nhiệm vụ, kinh tế, xe và vũ khí khác giữ V4.1.
Những giới hạn runtime của V4.1, gồm giữ salvage sau chết, vẫn cần thử.

BACKPACKS ĐÃ CHỈNH
Các giá trị dưới đây là cấu hình chính xác, không phải kết quả đã đo trong game.

JETPACK
- jetpack/fuel_use_per_second: 0,3 -> 0,075.
- jetpack/fuel_regen_per_second: 0,15 -> 0,5.
- Chưa tìm được nút chỉnh lực nâng/giới hạn độ cao đã xác minh trong VPP.
  Không thêm tag đoán tên. Bay lâu hơn không chứng minh bay cao hơn.

FLEETFOOT
- Hệ số tốc độ active: 1,45 -> 2 (so lúc không bật backpack).
- Tiêu hao/hồi mỗi giây: 0,04 / 0,4; phí bật 0,02; ngưỡng bật 0,1.
- no_fine_aim=False: bỏ hạn chế fine aim của backpack khi active.
  Animation/trạng thái sprint vẫn có thể hạn chế ngắm.
- Mục tiêu khoảng 20 m/s trên nền 10 m/s; cần đo engine có nhân và cap ra sao.

HEAL
- Hồi máu active 450 -> 900 HP/giây; radius 5,8 -> 10.
- health_regen_heal_enemies: True -> False ở nhánh active.
- Tiêu hao/hồi: 0,05 / 0,4; phí bật 0,02; ngưỡng bật 0,1.
- Schema nói hồi cho players. Hồi NPC/đồng minh/con tin campaign chưa được
  xác nhận; đây không phải cam kết đã tạo hệ thống cứu NPC bằng XML.

RHINO
- charge_top_speed: 8,2 -> 14 m/s; trường rhino_top_speed cũ 8 -> 14.
- Tiêu hao/hồi: 0,5 / 0,5; phí bật 0; ngưỡng bật 0,25.
- player_deactivatable=True: cho phép chủ động hủy theo cấu hình.
- Giữ bảo vệ active damage_taken_factor=0; không tăng damage phá công trình.
- Quãng 28 m chỉ là 14 m/s x 2 s trong mô hình, chưa tính va chạm hoặc engine.

THRUST
- jump_boost_vertical: 10 -> 15 (thêm vào vận tốc theo mô tả schema).
- Giữ tiêu hao 0,8; hồi 0,2 -> 0,5; ngưỡng bật 1 -> 0,25.
- Giữ delay boost 180 ms, damage, vùng phá, animation và hành vi active khác.
  x1,5 vận tốc boost không đồng nghĩa x1,5 chiều cao hoặc thời gian bay.

TREMOR
- Tiêu hao 0,25 -> 0,5 để tạo đợt ngắn; hồi 0,12 -> 0,4; ngưỡng 1 -> 0,5.
- Structural_Damage của mp_quake: 2500 -> 3750 mỗi xung.
- Giữ khoảng giữa xung 300 ms, mọi bán kính, impulse và human damage.
- Chủ đích tăng sức từng xung, rút ngắn đợt và hồi nhanh hơn; tổng sức phá
  một đợt không tự suy từ x1,5 vì số xung và engine còn tham gia.

CONCUSSION (TÊN DỮ LIỆU: SHOCKWAVE)
- ripple_range: 6 -> 8; ripple_player_hit_speed: 12 -> 18.
- Phí bật/ngưỡng bật 1 -> 0,5; hồi 0,22 -> 0,25; tiêu hao liên tục vẫn 0.
- Structural_Damage mẫu nổ mp_shockwave_blast: 15000 -> 3000.
- Giữ lực lên vật nặng/xe, các bán kính và impulse của vụ nổ, damage người.
  Vẫn có thể phá vật yếu hoặc gây va chạm phụ, không bảo đảm an toàn con tin.

FIREPOWER (TÊN DỮ LIỆU: COMMANDO)
- direct_damage_dealt_factor: 1,25 -> 2.
- area_damage_dealt_factor: 1,25 -> 1 để không thêm bonus lên nổ nền V4.1.
- reload_speed_factor: 1 -> 0,7; nhịp bắn giữ 1; không thêm đạn vô hạn.
- Tiêu hao/hồi: 0,05 / 0,4; phí bật 0; ngưỡng bật 0,25.
- Hệ số direct=2 có thể cộng dồn với damage súng nền x3 -> x6 original
  nếu engine dùng đường nhân này. Damage cuối và melee cần kiểm tra thực tế.

VISION
- Tiêu hao/hồi: 0,035 / 0,4; phí bật 0,02; ngưỡng bật 0,1.
- Ramp vào/ra hiệu ứng: 250 -> 100 ms.
- Không thêm khả năng xuyên đạn, tăng damage hoặc tự tìm con tin/nhiệm vụ.
  Mục tiêu mà Vision phát hiện trong campaign chưa được kiểm thử.

STEALTH
- Tiêu hao/hồi: 0,033 / 0,4; phí bật 0,02; ngưỡng bật 0,1.
- stealth_time_ms: 1000 -> 250; restealth_time_ms: 1000 -> 500.
- Giữ mức hiển thị/ngụy trang gốc; không sửa trực tiếp hệ thống phát hiện AI.
  Ngụy trang thị giác không chứng minh AI campaign bỏ qua nhân vật.

BẢNG GHI ĐÈ
Commando, Vision và Stealth có profile riêng trong mp_backpack_overrides.xtbl.
V4.2 ghi rõ cả bốn trường fuel_use_per_second, fuel_regen_per_second,
fuel_activation_cost và minimum_fuel_to_activate trong từng profile để đồng bộ
với bảng chính. Có 7 trường optional mới mỗi gói, đều được schema hỗ trợ.
Không thêm tên backpack, ID, asset, unlock hay đổi loadout NPC.
Các trường cũ ngoài nhánh schema hiện tại giữ nguyên, trừ trường tốc độ Rhino
cũ đã được chấp thuận đồng bộ với charge_top_speed.

THỜI GIAN THEO MÔ HÌNH NHIÊN LIỆU — KHÔNG PHẢI ĐO TRONG GAME
Giả định bình đầy=1; regen dừng khi active; không có modifier engine/nâng cấp.
Nếu giả định sai, các thời gian này sẽ không đúng. Xem fuel-model.csv/json.
Jetpack: khoảng 13,33 s sử dụng / 2 s từ rỗng tới đầy.
Fleetfoot: 24,5 s / 2,5 s. Heal: 19,6 s / 2,5 s.
Rhino: 2 s / 2 s. Thrust: cửa sổ tiêu hao 1,25 s / hồi 2 s,
không phải mô tả độ cao/thời lượng quỹ đạo của cú phóng.
Tremor: 2 s / 2,5 s. Firepower: 20 s / 2,5 s.
Vision: 28 s / 2,5 s. Stealth: khoảng 29,7 s / 2,5 s.
Concussion: năng lượng cho 2 lần từ đầy; hồi phần phí một lần khoảng 2 s;
từ rỗng tới đầy khoảng 4 s. Animation/logic có thể giới hạn nhịp thực tế.
Các loại có ngưỡng dưới 1 cho phép bật trước khi đầy và dùng ngắn hơn.

KIỂM TRA ĐÃ ĐẠT
- 128 thay đổi trên hai gói: mỗi gói 64, bao gồm 7 trường override optional mới.
- Chỉ 3 bảng mỗi gói đổi: mp_backpacks.xtbl, mp_backpack_overrides.xtbl,
  explosions.xtbl (chỉ hai trường damage công trình của hai mẫu đã chọn).
- Giữ nguyên 1208/423 tệp; đọc VPP độc lập kiểm tra header, hash tên, offset,
  chiều dài, padding; giải nén đối chiếu toàn bộ 1631 payload.
- Validator riêng dùng ElementTree, không import patcher; kiểm tra từng
  route và giá trị, mọi nội dung ngoài phạm vi, ID 0..9, schema và kiểu dữ liệu.
- 24 đối chiếu fuel giữa bảng chính/override đều khớp; không có lỗi min/max mới.
- Đối chiếu toàn bộ 3365 giá trị khác original, gồm tất cả thay đổi V4.1 cũ.
- credits.xtbl giữ ký tự lỗi XML có sẵn từ original; mọi XML sửa hợp lệ.

GIỚI HẠN VÀ CÁCH THỬ
Chưa chạy thử trong game. Những giá trị được xác nhận là dữ liệu đóng gói,
không phải cam kết về độ cao, tốc độ, thời gian thực hoặc hỗ trợ NPC.
Đây là bảng dùng chung với MP/Wrecking Crew; bản mod dành cho offline.
- Dùng save phụ, thử ở khu vực trống trước khi chơi nhiệm vụ giải cứu/hộ tống.
- Jetpack: từ đầy bình, đo thời gian bay/hồi, kiểm tra có trần độ cao và
  regen khi active hay không. Nâng cấp trong save có thể thay đổi kết quả.
- Fleetfoot: so tốc độ trên cùng một đoạn đường khi bật/tắt, thử fine aim.
- Rhino: thử quãng lao và hủy bằng nút backpack đã gán ở chỗ không có mục tiêu.
- Heal: thử bản thân và NPC bị thương ngoài nhiệm vụ nếu có cách quan sát HP;
  không coi hồi NPC đã hoạt động chỉ từ vòng hiệu ứng hiện ra.
- Stealth/Vision: kiểm tra phản ứng AI/đối tượng phát hiện; hiệu ứng hình ảnh
  không đủ chứng minh gameplay. Thử các backpack phá hủy xa con tin.
- Không tự mở khóa; backpack chưa xuất hiện vẫn theo trạng thái tiến trình V4.1.

SHA-256 FILE GAME
{sums.rstrip()}

Chi tiết GitHub: reports/campaign-v4_2.md. ZIP báo cáo riêng gồm profile,
delta V4.1->V4.2, toàn bộ original->V4.2, mô hình fuel, validator và mã dựng.
'''
    (OUT/'HUONG_DAN.txt').write_text(guide,encoding='utf-8')
    old_guide=DL/'HUONG_DAN_V4_1.txt'
    if not old_guide.exists():shutil.copyfile(DL/'HUONG_DAN.txt',old_guide)
    shutil.copyfile(OUT/'HUONG_DAN.txt',DL/'HUONG_DAN.txt')
    old_report=REPORTS/'campaign-v4_1.md'
    old_report.write_text(old_report.read_text().replace('../downloads/HUONG_DAN.txt','../downloads/HUONG_DAN_V4_1.txt'))
    report=f'''# Campaign V4.2 — cải thiện đủ 10 backpacks

**[Tải V4.2 đầy đủ](../downloads/Ultimate_Mod_Campaign_v4_2.zip)** ·
[Hướng dẫn và cách thử](../downloads/HUONG_DAN.txt) ·
[Báo cáo/mã dựng ZIP](../downloads/Ultimate_Mod_Campaign_v4_2_Reports.zip).

V4.2 dùng **V4.1 đã phát hành** làm nền. Chỉ ba bảng trong mỗi VPP thay đổi:
mp_backpacks.xtbl, mp_backpack_overrides.xtbl và hai trường trong explosions.xtbl.
Tất cả búa, súng, Alec, NPC, nhiệm vụ, kinh tế, xe, salvage và camera-shake
ngoài các trường này giữ nguyên V4.1. Không thêm backpack, ID, asset, unlock
hoặc trang bị cho NPC. Các profile là định nghĩa dùng chung với MP/Wrecking Crew;
đây là bản dành cho chơi offline.

## Cấu hình đã áp dụng

| Backpack | Thay đổi chính |
|---|---|
| Jetpack | Tiêu hao 0,3 → 0,075; hồi 0,15 → 0,5; không thêm tham số độ cao/lực nâng chưa xác minh |
| Fleetfoot | Hệ số active 1,45 → 2; tiêu hao/hồi 0,04/0,4; phí/ngưỡng 0,02/0,1; bỏ chặn fine aim của backpack |
| Heal | 450 → 900 HP/s; radius 5,8 → 10; tắt cờ hồi địch ở nhánh active; fuel 0,05/0,4, phí/ngưỡng 0,02/0,1 |
| Rhino | charge_top_speed và trường tốc độ cũ cùng 14; fuel 0,5/0,5, ngưỡng 0,25; cho phép chủ động hủy |
| Thrust | Boost vận tốc dọc 10 → 15; hồi 0,2 → 0,5; ngưỡng 1 → 0,25; damage và delay giữ V4.1 |
| Tremor | Đợt ngắn: tiêu hao 0,5, hồi 0,4, ngưỡng 0,5; damage công trình mp_quake 2500 → 3750/xung; giữ nhịp 300 ms và bán kính |
| Concussion / Shockwave | Tầm ripple 6 → 8; tốc độ hất nhân vật 12 → 18; phí/ngưỡng 0,5/0,5, hồi 0,25; structure blast 15000 → 3000 |
| Firepower / Commando | Direct damage factor 1,25 → 2; area factor 1,25 → 1; reload factor 1 → 0,7; fuel 0,05/0,4, ngưỡng 0,25 |
| Vision | Fuel 0,035/0,4, phí/ngưỡng 0,02/0,1; ramp hiệu ứng vào/ra 250 → 100 ms |
| Stealth | Fuel 0,033/0,4, phí/ngưỡng 0,02/0,1; vào ngụy trang 1000 → 250 ms, tái ngụy trang 1000 → 500 ms |

`fuel` trong bảng viết theo thứ tự tiêu hao/hồi mỗi giây. Chỉ Rhino được đổi
quyền hủy chủ động mới; các điều khiển khác giữ V4.1. Nhịp bắn, unlimited_ammo,
hướng/độ cao va chạm và preset rung camera không được tự tăng/đổi.

Firepower direct factor=2 là bonus trên damage hiện tại; súng nền ×3 có thể
thành ×6 original nếu engine nhân theo nhánh này. Area factor=1 giữ nổ nền
V4.1, không thêm bonus ×1,25 của Firepower cũ. Chưa xác nhận đường tính melee.

## Mô hình năng lượng, không phải kết quả đo trong game

Giả định bình tối đa=1, regen dừng khi active, không có modifier engine/nâng
cấp. Các giá trị sau là phép tính từ cấu hình; nếu giả định sai thì phải đo
và hiệu chỉnh. Kích hoạt trước khi đầy cho thời lượng ngắn hơn.

| Backpack | Thời lượng active từ đầy (s) | Rỗng → đầy (s) | Ghi chú |
|---|---:|---:|---|
'''
    for row in model:
        active=row['model_full_fuel_active_seconds'] or '—'
        note=''
        if row['name']=='Shockwave':note='Mô hình 2 lần từ đầy; hồi phí một lần 2 s; nhịp action chưa đo'
        elif row['name']=='Thrust':note='Cửa sổ fuel, không phải độ cao/thời lượng quỹ đạo'
        elif row['name']=='Rhino':note='14 m/s × 2 s = 28 m chỉ khi không bị cản theo mô hình'
        report+='| '+row['display_name']+' | '+active+' | '+row['model_empty_to_full_refill_seconds']+' | '+note+' |\n'
    report+='''
Các giới hạn còn cần thử:

- Jetpack: giảm tiêu hao không bảo đảm tăng trần độ cao hoặc lực nâng.
- Fleetfoot: hệ số 2 chưa chứng minh tốc độ đo được là 20 m/s; engine có thể cap.
- Heal: schema nói players. Hồi NPC/đồng đội/con tin campaign chưa xác nhận;
  đặt cờ heal_enemies=False không tự tạo khả năng hồi NPC.
- Stealth: thay timing ngụy trang chưa chứng minh AI campaign mất dấu.
- Vision: tập đối tượng hiển thị trong campaign chưa kiểm thử.
- Rhino: quãng lao và hủy phụ thuộc input, collision và logic engine.
- Concussion/Tremor vẫn có thể gây sập nhà, va chạm phụ hoặc hại con tin.
  Không có cam kết mọi nhiệm vụ an toàn từ kiểm tra cấu hình.

## Rà soát bảng ghi đè và schema

Commando, Vision và Stealth có override fuel riêng. V4.2 ghi đủ bốn trường
tiêu hao, hồi, phí kích hoạt, ngưỡng kích hoạt trong cả ba override, khớp bảng
chính. Có **7 trường optional thêm mỗi gói**, đều có trong TableDescription;
không thêm tag đoán tên. Không nhân dồn hai profile.

Đã cập nhật cả charge_top_speed có trong schema và rhino_top_speed cũ có sẵn
theo phương án được chấp thuận. Các giá trị legacy khác ở cấp ngoài giữ
nguyên; không tự coi mọi trường trùng tên cùng một chức năng. Không sửa
schema, entry category, số/tên backpack hoặc Unique_ID.

## Xác minh

- **128 thay đổi so V4.1:** 64 mỗi gói, gồm 7 trường optional mới mỗi gói;
  tổng **3365** giá trị khác original, đếm cả bản sao ở hai gói.
- Giữ nguyên tập 1208/423 tên tệp. Mọi payload ngoài ba bảng giữ từng byte.
- Writer được calibration trên V4.1; giải nén đối chiếu 1631 payload.
  Validator độc lập không import patcher, dùng bộ đọc raw VPP và ElementTree
  để kiểm header, hash tên, offset, padding, kích thước và từng route XML.
- Mọi field/schema/type, ID 0..9, nội dung ngoài phạm vi và full audit
  original/V4.2 đã đối chiếu. **24 so sánh fuel** giữa main/override đều khớp.
  Không có vi phạm min/max mới. Mọi XML sửa hợp lệ.
- credits.xtbl giữ lỗi ký tự có sẵn từ original; không đổi byte.
- **Chưa chạy thử trong game.** Không có thử nghiệm runtime giả lập nào được
  dùng để tuyên bố đã đạt độ cao, thời gian hoặc hỗ trợ AI/NPC.

[Delta V4.1 → V4.2](campaign-v4_2-parameters.csv) ·
[Toàn bộ original → V4.2](campaign-v4_2-parameters-original.csv) ·
[Profile chính xác](campaign-v4_2-policy.json) ·
[Mô hình fuel](campaign-v4_2-fuel-model.csv) ·
[Validation](campaign-v4_2-validation.json) · [Nền V4.1](campaign-v4_1.md).

## Thử trên save phụ

Thử Jetpack từ đầy bình và quan sát hồi khi active; so tốc độ Fleetfoot trên
cùng đoạn đường; thử hủy Rhino ở khu vực trống. Kiểm tra Heal lên bản thân
và NPC bị thương ngoài nhiệm vụ khi có cách quan sát HP; vòng hiệu ứng không
đủ chứng minh HP NPC tăng. Thử Stealth/Vision với AI trước khi dùng trong
nhiệm vụ. Xem hướng dẫn ZIP để biết giới hạn và cách hoàn tác.
'''
    report+='\n```text\n'+sums.rstrip()+'\n```\n'
    (OUT/'README.md').write_text(report,encoding='utf-8')
    (REPORTS/'campaign-v4_2.md').write_text(report,encoding='utf-8')
    for name in ['parameters.csv','parameters-original.csv','summary.json','validation.json','policy.json','fuel-model.csv','fuel-model.json']:
        shutil.copyfile(OUT/name,REPORTS/('campaign-v4_2-'+name))
    code=OUT/'code';code.mkdir(exist_ok=True)
    for src in [BASE/'rebalance_work'/n for n in ['build_campaign_v4_2.py','verify_campaign_v4_2.py',
                'backpack_v4_2_profile.py','release_campaign_v4_2.py','rebalance_rules.py','verify_balance.py']]+[BASE/'repair_ultimate.py',BASE/'vpp_compare.py']:
        shutil.copyfile(src,code/src.name)
    (code/'README.txt').write_text('''Python 3.10+, thư viện chuẩn. Không chạy CLI của module cũ.
Profile yêu cầu: backpack_v4_2_profile.py; patcher và validator là hai entry point riêng.

python code/build_campaign_v4_2.py --analysis-root /path/to/analysis --output /new/output
python code/verify_campaign_v4_2.py --analysis-root /path/to/analysis --output /new/output

Inputs dưới analysis root:
campaign_v4_1/game_files/{misc,table}.vpp_pc: từ ZIP V4.1 chính thức.
campaign_v4_1/parameters-original.json và summary.json: từ ZIP báo cáo V4.1.
campaign_v4_originals/{misc,table}/: payload BACKUP original đã giải nén.
Builder pin SHA V4.1. Validator không import patcher; dùng ET và raw reader độc lập.
release_campaign_v4_2.py chỉ tạo tài liệu/ZIP, dùng đường dẫn workspace riêng.
Mã không chạy executable/asset game. Chưa có kiểm thử game runtime.
''',encoding='utf-8')
    main_zip=DL/'Ultimate_Mod_Campaign_v4_2.zip'
    with zipfile.ZipFile(main_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for package in ('misc','table'):z.write(OUT/'game_files'/(package+'.vpp_pc'),package+'.vpp_pc')
        for name in ['HUONG_DAN.txt','SHA256SUMS.txt']:z.write(OUT/name,name)
    report_zip=DL/'Ultimate_Mod_Campaign_v4_2_Reports.zip'
    with zipfile.ZipFile(report_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in ['README.md','HUONG_DAN.txt','SHA256SUMS.txt','parameters.csv','parameters.json',
                     'parameters-original.csv','parameters-original.json','files.csv','summary.json',
                     'validation.json','policy.json','fuel-model.json','fuel-model.csv','misc_manifest.json','table_manifest.json']:
            z.write(OUT/name,name)
        for path in sorted(code.iterdir()):z.write(path,'code/'+path.name)
    checks={}
    for path in (main_zip,report_zip):
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
            if path==main_zip:
                assert set(z.namelist())=={'misc.vpp_pc','table.vpp_pc','HUONG_DAN.txt','SHA256SUMS.txt'}
                for package in ('misc','table'):assert sha(z.read(package+'.vpp_pc'))==packages[package]['sha256']
            else:assert json.loads(z.read('validation.json'))['status']=='passed'
        checks[path.name]={'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'zip_crc_passed':True}
    for version in ('v4','v4_1'):
        for name,meta in json.loads((REPORTS/('campaign-'+version+'-release-validation.json')).read_text())['artifacts'].items():
            assert sha((DL/name).read_bytes())==meta['sha256']
    write_json(OUT/'release_validation.json',{'status':'passed','artifacts':checks,
        'historical_v4_and_v4_1_zips_unchanged':True,'game_runtime_tested':False})
    shutil.copyfile(OUT/'release_validation.json',REPORTS/'campaign-v4_2-release-validation.json')
    keep=[l for l in (DL/'SHA256SUMS.txt').read_text().splitlines()
          if l and l.split()[-1] not in {'misc.vpp_pc','table.vpp_pc',main_zip.name,report_zip.name}]
    (DL/'SHA256SUMS.txt').write_text(sums+'\n'.join(keep)+'\n'+''.join(m['sha256']+'  '+n+'\n' for n,m in checks.items()))
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
