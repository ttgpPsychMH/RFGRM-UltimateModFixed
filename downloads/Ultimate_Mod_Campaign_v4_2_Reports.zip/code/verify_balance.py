#!/usr/bin/env python3
"""Validate the two balance archives independently of the patching rules."""
import argparse
from collections import Counter
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET


def check(ok, message):
    if not ok:
        raise ValueError(message)


def values(element, path="/root"):
    result = {}
    if (element.text or "").strip() or not len(element):
        result[path] = (element.text or "").strip()
    seen = Counter()
    for child in element:
        label = child.tag
        name, category = child.findtext("Name"), child.findtext("_Editor/Category")
        if name is not None:
            label += "[Name=" + name + "]"
            if category is not None:
                label += "[Category=" + category + "]"
        seen[label] += 1
        result.update(values(child, path + "/" + label + f"[{seen[label]}]"))
    return result


def read_raw(path):
    data = path.read_bytes()
    check(struct.unpack_from("<2I", data) == (0x51890ACE, 3), "Wrong VPP format")
    flags, unknown, count, total, ds, ns, us, cs = struct.unpack_from("<8I", data, 332)
    check(flags == unknown == 0 and total == len(data) and cs == 0xFFFFFFFF, "Bad raw VPP header")
    check(ds == 28 * count, "Bad directory extent")
    names_at = 2048 + ((ds + 2047)//2048)*2048
    body_at = names_at + ((ns + 2047)//2048)*2048
    check(body_at + us == len(data), "Incorrect data length")
    entries = []
    for index in range(count):
        no, ptr, offset, hashed, length, packed, ptr2 = struct.unpack_from("<7I", data, 2048 + index*28)
        check(0 <= no < ns and ptr == ptr2 == 0 and packed == 0xFFFFFFFF, "Bad entry metadata")
        name = data[names_at+no:data.index(b"\0", names_at+no, names_at+ns)].decode("ascii")
        value = 0
        for c in name.lower().encode("ascii"):
            value = (((value << 6) | (value >> 26)) & 0xFFFFFFFF) ^ c
        check(value == hashed, "Bad name hash: " + name)
        entries.append((offset, name, length))
    files, cursor = {}, 0
    for offset, name, length in sorted(entries):
        check(offset == ((cursor+2047)//2048)*2048, "Sequential/directory offsets disagree")
        check(not any(data[body_at+cursor:body_at+offset]), "Nonzero padding")
        blob = data[body_at+offset:body_at+offset+length]
        check(len(blob)==length and name not in files, "Truncated or duplicate file")
        files[name] = blob
        cursor = offset + length
    check(cursor==us, "Trailing or missing bytes")
    return files


def relations(tree):
    problems = []
    pairs = [("Min_RPM","Opt_RPM"),("Opt_RPM","Max_RPM"),
             ("Min_RPM","Max_RPM"),("Start_Speed","Max_Speed"),
             ("Min_Engagement_Distance","Max_Engagement_Distance"),
             ("Spread_Min","Spread_Max"),("human_damage_min","Human_Damage_Max"),
             ("vehicle_damage_min","vehicle_damage_max"),
             ("Magazine_Size","Max_Rounds"),("Max_Rounds","Max_Rounds_Upgrade"),
             ("Damage_Scaling_Min/Threshold","Damage_Scaling_Max/Threshold")]
    for path, node in index_elements(tree).items():
        for lo, hi in pairs:
            a, b = node.findtext(lo), node.findtext(hi)
            if a is None or b is None:
                continue
            try:
                if Decimal(a.strip()) > Decimal(b.strip()):
                    problems.append((path,lo,hi))
            except Exception:
                continue
    return set(problems)


def index_elements(root):
    result = {}
    def walk(node, path):
        result[path] = node
        counts = Counter()
        for c in node:
            label = c.tag
            if c.findtext("Name") is not None:
                label += "[Name="+c.findtext("Name")+"]"
                if c.findtext("_Editor/Category") is not None:
                    label += "[Category="+c.findtext("_Editor/Category")+"]"
            counts[label]+=1
            walk(c,path+"/"+label+f"[{counts[label]}]")
    walk(root,"/root")
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--analysis-root",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    args=p.parse_args(); base,out=args.analysis_root,args.output
    report=json.loads((out/"summary.json").read_text())
    rows=json.loads((out/"parameters.json").read_text())
    grouped={}
    for row in rows:
        grouped.setdefault((row["package"],row["file"]),[]).append(row)
    checks={}; all_payloads={}; arithmetic=0; actual_changes=0; extra_changes=0
    extraction=out/"roundtrip" if (out/"roundtrip").is_dir() else out/"extracted"
    for pkg in ["misc","table"]:
        payloads=read_raw(out/"game_files"/(pkg+".vpp_pc"));all_payloads[pkg]=payloads
        original=base/("ultimate_mod_misc/original" if pkg=="misc" else "table/original")
        old_mod=base/("ultimate_mod_misc/modified" if pkg=="misc" else "repaired_ultimate/repaired_table_files")
        check(set(payloads)=={f.name for f in old_mod.iterdir() if f.is_file()},"Filename set changed")
        xml_ok=0; exceptions={}; changed_files=[]; semantic_count=0; pair_checks=0
        for name,blob in payloads.items():
            check(blob==(extraction/pkg/name).read_bytes(),"Other VPP reader disagrees")
            mb=(old_mod/name).read_bytes();ob=(original/name).read_bytes()
            events=grouped.get((pkg,name),[])
            changed={r["path"]:r for r in events if r["mod"]!=r["planned"]}
            if blob!=mb:changed_files.append(name)
            if not changed:
                check(blob==mb,"Unscheduled byte change: "+name)
            if not name.endswith(".xtbl"):
                check(blob==mb,"Binary asset changed")
                continue
            check(blob.startswith(b"<root>") and blob.rstrip().endswith(b"</root>") and b"\0" not in blob,"Broken XTBL boundary")
            try:
                after_tree=ET.fromstring(blob)
            except ET.ParseError as ex:
                check(name=="credits.xtbl" and blob==ob==mb,"New XML parse failure: "+name)
                exceptions[name]=str(ex);continue
            xml_ok+=1
            if blob==mb:
                continue
            before_tree=ET.fromstring(mb);original_tree=ET.fromstring(ob)
            before_map,after_map,original_map=values(before_tree),values(after_tree),values(original_tree)
            check(before_map.keys()==after_map.keys(),"XML value keys/structure changed")
            semantic={path for path in after_map if before_map[path]!=after_map[path]}
            check(semantic==set(changed),"Changed values differ from audit: "+pkg+"/"+name)
            for path,row in changed.items():
                check(after_map[path]==row["planned"],"Planned value not present")
                # XML parsers normalize CRLF/CR in text. The audit retains raw
                # line endings, including the malformed split RPM in the mod.
                normalized_mod=row["mod"].replace("\r\n","\n").replace("\r","\n")
                normalized_original=row["original"].replace("\r\n","\n").replace("\r","\n")
                check(original_map[path]==normalized_original and before_map[path]==normalized_mod,
                      "Source values differ: "+pkg+"/"+name+": "+path)
                if original_map[path]==before_map[path]:
                    check(row["authorized_exception"],"Changed an unmodified field without exception")
                    check(row["rule"].startswith(("hammer_","extra_bound_companion_")),"Unknown exception")
                    extra_changes+=1
                if row["factor"] is not None:
                    expected=Decimal(row["original"])*Decimal(row["factor"])
                    if row["rounding"]=="ceil_to_integer":
                        expected=expected.to_integral_value(rounding=ROUND_CEILING)
                    check(Decimal(after_map[path])==expected,"Not calculated from original")
                    arithmetic+=1
                elif row["rule"].startswith("hammer_restore_"):
                    check(after_map[path]==original_map[path],"Hammer original restore failed")
                else:
                    raise ValueError("Non-arithmetic change not authorized")
            semantic_count+=len(semantic)
            new_bad=relations(after_tree)-relations(before_tree)-relations(original_tree)
            check(not new_bad,"New min/max violation: "+name+": "+str(new_bad))
            pair_checks+=1
            actual_changes+=len(semantic)
        checks[pkg]=dict(file_count=len(payloads),xml_valid=xml_ok,
                         unchanged_original_xml_exceptions=exceptions,
                         files_changed_vs_repaired_mod=changed_files,
                         modified_xml_documents_checked=pair_checks,
                         semantic_changes=semantic_count,
                         no_new_min_max_violations=True,binary_assets_unchanged=True)

    sample_checks=[]
    samples=[
        ("misc","explosions.xtbl",".//Explosion[Name='remote_charge']/Radius","30"),
        ("table","explosions.xtbl",".//Explosion[Name='remote_charge']/Radius","30"),
        ("misc","character.xtbl",".//Character[Name='rfg_PC']/max_hit_points","5500"),
        ("misc","character.xtbl",".//Character[Name='Kyle']/max_hit_points","2000"),
        ("misc","character.xtbl",".//Character[Name='Admiral_Kobel']/max_hit_points","1200"),
        ("table","character.xtbl",".//Character[Name='rfg_PC']/Height","1.1"),
        ("misc","difficulty.xtbl",".//Difficulty_Items/Item[Name='MENU_PLAYER_DAMAGE_TAKEN']/Easy","0.03"),
        ("misc","vehicles.xtbl",".//Vehicle[Name='Col_FixedFlatbed_2']/Engine/Min_RPM","5000"),
        ("misc","vehicles.xtbl",".//Vehicle[Name='Col_FixedFlatbed_2']/Engine/Opt_RPM","15000"),
        ("misc","vehicles.xtbl",".//Vehicle[Name='Col_FixedFlatbed_2']/Engine/Max_RPM","30000"),
        ("misc","vehicles.xtbl",".//Vehicle[Name='Min_SupplyTruck_3']/Engine/Max_RPM","30000"),
    ]
    for pkg in ["misc","table"]:
        for name,value in [("sledgehammer_melee_side","75000"),("sledgehammer_melee_vert","75000"),
                           ("sledgehammer_melee_side_u1","40000"),("sledgehammer_melee_vert_u1","40000"),
                           ("sledgehammer_melee_side_u2","50000"),("sledgehammer_melee_vert_u2","50000"),
                           ("sledgehammer_melee_side_gold","500000"),("sledgehammer_melee_vert_gold","500000")]:
            samples.append((pkg,"melee.xtbl",f".//MeleeMove[Name='{name}']/MoveDataList/AnimSet[AnimSetName='Player.xtbl']/Damage/DefaultDamage",value))
        samples.append((pkg,"weapons.xtbl",".//Weapon[Name='sledgehammer']/Damage_Scaling_Max/NPC_Damage","0"))
        samples.append((pkg,"weapons.xtbl",".//Weapon[Name='golden_hammer']/MeleeAttacks/StandingPrimary","sledgehammer_melee_side_gold"))
    for pkg,filename,xpath,value in samples:
        actual=ET.fromstring(all_payloads[pkg][filename]).findtext(xpath)
        check(actual==value,"Representative value failed: "+str((pkg,filename,xpath,actual,value)))
        sample_checks.append(dict(package=pkg,file=filename,xpath=xpath,value=actual))
    check(actual_changes==report["parameter_values_changed"],"Wrong total change count")
    check(extra_changes==report["new_fields_changed_by_authorized_exception"],"Wrong exception count")
    result=dict(status="passed",packages=checks,arithmetic_values_checked=arithmetic,
                total_changes_checked=actual_changes,extra_fields_checked=extra_changes,
                representative_checks=sample_checks,game_runtime_tested=False)
    (out/"validation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k!="representative_checks"},indent=2))
    print("Representative checks passed:",len(sample_checks))


if __name__=="__main__":
    main()
