#!/usr/bin/env python3
"""Independently verify V4.2 raw archives with ElementTree and read_raw.

Does not import the patcher. The explicit approved profile is the requirement;
all other text, structure and payloads must match released V4.1 exactly.
"""
import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from backpack_v4_2_profile import PROFILE, BACKPACKS, OVERRIDES
from verify_balance import read_raw,values,index_elements,relations

D=Decimal


def sha(blob):return hashlib.sha256(blob).hexdigest()


def equal(actual,expected):
    if actual is None or expected is None:return actual is expected
    try:return D(actual)==D(expected)
    except Exception:return actual==expected


def element(record,route):
    target=record
    for tag in route.split('/'):
        children=[c for c in target if c.tag==tag]
        if not children:return None
        assert len(children)==1
        target=children[0]
    return target


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();base,out=args.analysis_root,args.output
    summary=json.loads((out/'summary.json').read_text())
    delta=json.loads((out/'parameters.json').read_text())
    full=json.loads((out/'parameters-original.json').read_text())
    assert len(delta)==summary['changed_parameters_vs_v4_1']==128
    assert len(full)==summary['changed_parameters_vs_original']==3365
    assert summary['added_override_fields']==14 and summary['backpack_count']==10
    previous=json.loads((base/'campaign_v4_1/summary.json').read_text())
    assert previous['changed_parameters_vs_original']==3237
    validation={'status':'passed','game_runtime_tested':False,'packages':{},
        'delta_fields_verified':0,'added_optional_fields_verified':0,
        'all_ten_backpacks_covered':True,'fuel_override_consistency_checks':0}
    output_files={}
    for package in ('misc','table'):
        src=base/'campaign_v4_1/game_files'/(package+'.vpp_pc')
        trusted=next(p for p in previous['packages'] if p['name']==package)['sha256']
        assert sha(src.read_bytes())==trusted
        before=read_raw(src)
        target=out/'game_files'/(package+'.vpp_pc')
        after=read_raw(target);output_files[package]=after
        output_meta=next(p for p in summary['packages'] if p['name']==package)
        assert sha(target.read_bytes())==output_meta['sha256']
        assert before.keys()==after.keys() and len(after)==(1208 if package=='misc' else 423)
        xml_ok=0;exceptions={};changed_files=[];full_count=0
        for filename,blob in after.items():
            assert blob==(out/'roundtrip'/package/filename).read_bytes()
            if filename not in PROFILE:assert blob==before[filename]
            if not filename.endswith('.xtbl'):
                assert blob==before[filename];continue
            try:new_tree=ET.fromstring(blob)
            except ET.ParseError as error:
                assert filename=='credits.xtbl' and blob==before[filename]
                assert blob==(base/'campaign_v4_originals'/package/filename).read_bytes()
                exceptions[filename]=str(error);continue
            xml_ok+=1
            if filename not in PROFILE:continue
            assert blob!=before[filename];changed_files.append(filename)
            old_tree=ET.fromstring(before[filename]);old_idx=index_elements(old_tree);new_idx=index_elements(new_tree)
            old_map,new_map=values(old_tree),values(new_tree)
            assert old_map.keys()<=new_map.keys()
            permitted={};additions={}
            old_records={n.findtext('Name'):n for n in old_tree.find('Table')}
            new_records={n.findtext('Name'):n for n in new_tree.find('Table')}
            assert old_records.keys()==new_records.keys()
            for name,rows in PROFILE[filename].items():
                for route,expected,want,rule in rows:
                    old=element(old_records[name],route)
                    new=element(new_records[name],route)
                    assert equal(old.text.strip() if old is not None else None,expected)
                    assert new is not None and (new.text or '').strip()==want
                    assert not len(new)
                    path=next(p for p,n in new_idx.items() if n is new)
                    audit=[r for r in delta if r['package']==package and r['file']==filename and r['path']==path]
                    assert len(audit)==1
                    row=audit[0]
                    assert row['record']==name and row['route']==route and row['planned']==want and row['rule']==rule
                    if expected is None:
                        assert old is None and filename=='mp_backpack_overrides.xtbl'
                        assert path not in old_idx
                        additions[path]=want
                        validation['added_optional_fields_verified']+=1
                    else:
                        assert old is not None and row['v4_1']==old_map[path]
                    permitted[path]=want
                    validation['delta_fields_verified']+=1
            assert set(new_map)-set(old_map)==set(additions)
            actual={p for p in old_map if old_map[p]!=new_map[p]}
            assert actual==set(permitted)-set(additions)
            for path,value in old_map.items():assert new_map[path]==permitted.get(path,value)
            # The only new nodes are the seven optional override leaves.
            assert set(new_idx)-set(old_idx)==set(additions)
            assert set(old_idx)<=set(new_idx)
            for path,node in old_idx.items():assert node.attrib==new_idx[path].attrib
            assert not (relations(new_tree)-relations(old_tree))
            for block in ['TableTemplates','TableDescription','EntryCategories']:
                old_block,new_block=old_tree.find(block),new_tree.find(block)
                if old_block is not None:assert ET.tostring(old_block)==ET.tostring(new_block)
            # All numeric fields have finite valid numbers; only approved flags change.
            for row in [r for r in delta if r['package']==package and r['file']==filename]:
                if row['schema_type'] in {'Float','Int'}:
                    val=D(row['planned']);assert val.is_finite() and val>=0
                    if row['schema_type']=='Int':assert val==val.to_integral_value()
                else:assert row['planned'] in {'True','False'}
        # Check the complete original-based audit, including all prior V4.1 settings.
        tracked={r['file'] for r in full if r['package']==package}
        for filename in tracked:
            original=ET.parse(base/'campaign_v4_originals'/package/filename).getroot()
            now=ET.fromstring(after[filename])
            a,z=values(original),values(now)
            assert set(a)<=set(z)
            actual={p for p in a if a[p]!=z[p]} | (set(z)-set(a))
            audited={r['path']:r for r in full if r['package']==package and r['file']==filename}
            assert actual==set(audited),(package,filename)
            for path,row in audited.items():
                assert a.get(path)==row['original'] and z[path]==row['planned']
            full_count+=len(actual)
        backpack_root=ET.fromstring(after['mp_backpacks.xtbl'])
        packs={n.findtext('Name'):n for n in backpack_root.find('Table')}
        assert set(packs)==set(BACKPACKS)
        assert sorted(int(n.findtext('Unique_ID')) for n in packs.values())==list(range(10))
        for name,pack in packs.items():
            if name=='Jetpack':
                fuel=pack.find('jetpack');assert D(fuel.findtext('fuel_use_per_second'))>0
                assert D(fuel.findtext('fuel_regen_per_second'))>0
            else:
                fuel=pack.find('activatable/uses_fuel')
                use,regen,cost,minimum=[D(fuel.findtext(tag)) for tag in ['fuel_use_per_second','fuel_regen_per_second','fuel_activation_cost','minimum_fuel_to_activate']]
                assert use>=0 and regen>0 and D(0)<=cost<=minimum<=D(1)
        overrides=ET.fromstring(after['mp_backpack_overrides.xtbl'])
        assert {n.findtext('Name') for n in overrides.find('Table')}==set(OVERRIDES)
        for rec in overrides.find('Table'):
            base_fuel=packs[rec.findtext('Name')].find('activatable/uses_fuel')
            for field in ['fuel_use_per_second','fuel_regen_per_second','fuel_activation_cost','minimum_fuel_to_activate']:
                assert D(rec.findtext('uses_fuel/'+field))==D(base_fuel.findtext(field))
                validation['fuel_override_consistency_checks']+=1
        # High consequence checks: immunity stays on, enemy heal off, blast area intact.
        assert packs['Heal'].findtext('activatable/active_abilities/health_regen/health_regen_heal_enemies')=='False'
        assert packs['Fleetfoot'].findtext('activatable/no_fine_aim')=='False'
        assert packs['Rhino'].findtext('activatable/deactivatable/player_deactivatable')=='True'
        assert D(packs['Rhino'].findtext('activatable/active_abilities/damage_taken_factor'))==0
        assert D(packs['Thrust'].findtext('activatable/active_abilities/damage_taken_factor'))==0
        assert D(packs['Commando'].findtext('activatable/active_abilities/area_damage_dealt_factor'))==1
        assert D(packs['Commando'].findtext('activatable/active_abilities/refire_delay_factor'))==1
        assert D(packs['Tremor'].findtext('activatable/active_abilities/kaboom/kaboom_delay_ms'))==300
        for name in ['mp_quake','mp_shockwave_blast']:
            now=ET.fromstring(after['explosions.xtbl']).find("Table/Explosion[Name='%s']"%name)
            prev=ET.fromstring(before['explosions.xtbl']).find("Table/Explosion[Name='%s']"%name)
            for field in ['Radius','CrumbleRadius','KnockdownRadius','FlinchRadius','Impulse','human_damage_min','Human_Damage_Max','player_mult','player_veh_mult']:
                assert now.findtext(field)==prev.findtext(field)
        assert set(changed_files)==set(PROFILE)
        validation['packages'][package]=dict(file_count=len(after),xml_valid=xml_ok,
            unchanged_original_xml_exceptions=exceptions,changed_files_vs_v4_1=sorted(changed_files),
            delta_fields_verified=sum(r['package']==package for r in delta),
            full_original_delta_verified=full_count,all_unselected_payloads_byte_identical=True,
            all_unselected_values_attributes_and_schema_preserved=True,
            unique_backpack_ids_preserved=True,no_new_min_max_violations=True,
            independent_raw_reader_passed=True,roundtrip_extraction_passed=True,
            no_added_backpack_unlock_or_npc_loadout=True)
    for filename,blob in output_files['table'].items():
        if filename!='vehicles.xtbl':assert blob==output_files['misc'][filename]
    assert validation['delta_fields_verified']==128 and validation['added_optional_fields_verified']==14
    assert validation['fuel_override_consistency_checks']==24
    assert sum(p['full_original_delta_verified'] for p in validation['packages'].values())==3365
    validation['theoretical_timing_is_not_runtime_validation']=True
    validation['unverified_runtime_behavior']=['Jetpack ceiling/lift','Fleetfoot actual speed cap',
        'fuel capacity, active regen and upgrade multipliers','Heal on campaign NPCs','Stealth AI detection','Vision campaign targets','Rhino cancellation and distance']
    (out/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(validation,indent=2))


if __name__=='__main__':main()
