#!/usr/bin/env python3
"""Extract and compare RFG VPP v3 packages without modifying the input files.

Format reference: gibbed/Gibbed.Volition, commit
5f921fa3e4f510977939e3342360dcf89ea92150, PackageFileV3.cs,
Package/HeaderV3.cs, Package/HeaderFlagsV3.cs and VPP/Unpacker.cs.
This is an independent Python implementation; no third-party modules required.
Supports the little-endian v3 modes observed in the supplied RFG Re-Mars-tered
archives: raw, per-entry zlib and condensed (solid) zlib.
"""

import argparse
import collections
import csv
import difflib
import hashlib
import json
from pathlib import Path, PurePosixPath
import struct
import zlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def align(value, boundary):
    return (value + boundary - 1) // boundary * boundary


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def inflate(data, expected):
    # Game archives may end with Z_SYNC_FLUSH rather than a finished zlib
    # stream. Never fabricate an Adler-32 trailer or bypass an existing one.
    dec = zlib.decompressobj()
    raw = dec.decompress(data, expected + 1)
    require(len(raw) == expected, f"Inflated size {len(raw)} != {expected}")
    require(not dec.unconsumed_tail, "Inflated data exceeds expected size")
    require(not dec.unused_data, "Unexpected bytes after zlib stream")
    require(dec.eof or data.endswith(b"\x00\x00\xff\xff"),
            "Neither finished zlib nor sync-flushed stream")
    return raw, "finished" if dec.eof else "sync_flush_without_final_trailer"


def extract(source, destination):
    blob = source.read_bytes()
    require(len(blob) >= 2048, "Short header")
    require(struct.unpack_from("<2I", blob) == (0x51890ACE, 3),
            "Only little-endian VPP v3 is supported")
    flags, unknown, count, total, directory_size, names_size, raw_size, compressed_size = (
        struct.unpack_from("<8I", blob, 0x14C))
    require(flags in (0, 1, 3), f"Unsupported flags: {flags:#x}")
    require(total == len(blob), "Package size does not match header")
    require(directory_size == count * 28, "Unexpected directory size")
    names_start = 2048 + align(directory_size, 2048)
    data_start = names_start + align(names_size, 2048)
    require(data_start <= len(blob), "Header exceeds package size")
    names = blob[names_start:names_start + names_size]
    entries = []
    seen = set()
    for index in range(count):
        np, runtime, offset, name_hash, size, compressed, pointer = (
            struct.unpack_from("<7I", blob, 2048 + index * 28))
        require(np < len(names), "Name offset out of range")
        end = names.find(b"\x00", np)
        require(end >= 0, "Unterminated entry name")
        name = names[np:end].decode("ascii")
        path = PurePosixPath(name.replace("\\", "/"))
        require(name and not path.is_absolute() and ".." not in path.parts
                and ":" not in name and "\x00" not in name, "Unsafe entry name")
        require(str(path).casefold() not in seen, "Duplicate/colliding entry name")
        seen.add(str(path).casefold())
        entries.append(dict(name=name, path=path, offset=offset, size=size,
                            compressed_size=compressed, name_hash=name_hash))

    destination.mkdir(parents=True, exist_ok=False)
    stream_statuses = collections.Counter()
    if flags == 3:
        require(data_start + compressed_size == len(blob), "Solid extent mismatch")
        data, status = inflate(blob[data_start:data_start + compressed_size], raw_size)
        stream_statuses[status] += 1
    else:
        data = None
    compressed_cursor = data_start
    manifest = []
    for entry in sorted(entries, key=lambda item: item["offset"]):
        size = entry["size"]
        if flags == 3:
            offset = entry["offset"]
            raw = data[offset:offset + size]
        elif flags == 1 and entry["compressed_size"] != 0xFFFFFFFF:
            end = compressed_cursor + entry["compressed_size"]
            require(end <= len(blob), "Compressed entry out of range")
            raw, status = inflate(blob[compressed_cursor:end], size)
            stream_statuses[status] += 1
            compressed_cursor += align(entry["compressed_size"], 2048)
        else:
            offset = data_start + entry["offset"]
            raw = blob[offset:offset + size]
        require(len(raw) == size, f"Truncated entry: {entry['name']}")
        target = destination.joinpath(*entry["path"].parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as output:
            output.write(raw)
        manifest.append({key: value for key, value in entry.items() if key != "path"}
                        | {"sha256": sha256(raw)})

    return dict(source_name=source.name, source_bytes=len(blob), source_sha256=sha256(blob),
                version=3, flags=flags, mode={0: "uncompressed", 1: "per_entry_zlib",
                3: "solid_zlib"}[flags], file_count=count, data_offset=data_start,
                declared_uncompressed_data_bytes=raw_size,
                extracted_file_bytes=sum(item["size"] for item in manifest),
                zlib_stream_statuses=dict(stream_statuses), entries=manifest)


def as_text(data):
    if b"\x00" in data:
        return None
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            pass
    return None


def compare(original, modified, root):
    before = {item["name"]: item for item in original["entries"]}
    after = {item["name"]: item for item in modified["entries"]}
    rows = []
    diff_root = root / "diffs"
    diff_root.mkdir(exist_ok=False)
    for name in sorted(before.keys() | after.keys()):
        old, new = before.get(name), after.get(name)
        status = ("added" if old is None else "removed" if new is None else
                  "unchanged" if old["sha256"] == new["sha256"] else "modified")
        row = dict(name=name, status=status,
                   original_bytes=old["size"] if old else None,
                   modified_bytes=new["size"] if new else None,
                   original_sha256=old["sha256"] if old else None,
                   modified_sha256=new["sha256"] if new else None)
        if status != "unchanged":
            old_data = (root / "original" / name).read_bytes() if old else b""
            new_data = (root / "modified" / name).read_bytes() if new else b""
            old_text, new_text = as_text(old_data), as_text(new_data)
            if old_text is not None and new_text is not None:
                row["text_equal_ignoring_bom_and_line_endings"] = (
                    old_text.splitlines() == new_text.splitlines())
                diff = "".join(difflib.unified_diff(
                    old_text.splitlines(keepends=True), new_text.splitlines(keepends=True),
                    fromfile="original/" + name, tofile="modified/" + name))
                diff_path = diff_root / (name + ".diff")
                diff_path.parent.mkdir(parents=True, exist_ok=True)
                with diff_path.open("w", encoding="utf-8", newline="") as output:
                    output.write(diff)
        rows.append(row)
    with (root / "comparison.csv").open("w", encoding="utf-8-sig", newline="") as output:
        fields = ["name", "status", "original_bytes", "modified_bytes",
                  "original_sha256", "modified_sha256",
                  "text_equal_ignoring_bom_and_line_endings"]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    result = dict(counts=dict(collections.Counter(row["status"] for row in rows)), files=rows)
    (root / "comparison.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--modified", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    original = extract(args.original, args.output / "original")
    (args.output / "original_manifest.json").write_text(json.dumps(original, indent=2))
    print("Original:", original["file_count"], "files; mode:", original["mode"])
    if args.modified:
        modified = extract(args.modified, args.output / "modified")
        (args.output / "modified_manifest.json").write_text(json.dumps(modified, indent=2))
        print("Modified:", modified["file_count"], "files; mode:", modified["mode"])
        result = compare(original, modified, args.output)
        print(json.dumps(result["counts"]))
        for row in result["files"]:
            if row["status"] != "unchanged":
                print(row["status"], row["name"], row["original_bytes"], "->", row["modified_bytes"])


if __name__ == "__main__":
    main()
