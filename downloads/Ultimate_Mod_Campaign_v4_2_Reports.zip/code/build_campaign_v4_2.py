#!/usr/bin/env python3
"""Build the approved V4.2 backpack patch on immutable released V4.1."""
import argparse
from collections import Counter, defaultdict
from decimal import Decimal
import csv
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from rebalance_rules import xml_inventory, decimal, fmt
from backpack_v4_2_profile import PROFILE, BACKPACKS, DISPLAY_NAMES, LIMITATIONS

V4_1_HASHES = {
    'misc':'5440347d5500aeb430b0bfb042e8d0c4a97fd66aae05e89ba8d1d925b4ad0818',
    'table':'bf8f648e718704e83f5fa8579316ac28e92cacd87358b3b7d117e1552a357590',
}
D=Decimal


def sha(blob):return hashlib.sha256(blob).hexdigest()


def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def write_csv(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(rows)


def equivalent(actual,expected):
    if actual is None or expected is None:return actual is expected
    a,b=decimal(actual),decimal(expected)
    return a==b if a is not None and b is not None else actual==expected


def schema_for(root,route):
    element=root.child('TableDescription')
    for part in route.split('/'):
        element=next((e for e in element.children if e.tag=='Element' and e.get('Name')==part),None) if element else None
    return element


def patch(filename,blob,package):
    root,nodes=xml_inventory(blob)
    table=root.child('Table');events=[];edits=[];insertions=defaultdict(list)
    for record_name,changes in PROFILE[filename].items():
        records=[n for n in table.children if n.get('Name')==record_name]
        assert len(records)==1,(filename,record_name)
        record=records[0]
        for route,expected,planned,rule in changes:
            n=record
            for part in route.split('/'):n=n.child(part) if n else None
            actual=n.value if n else None
            assert equivalent(actual,expected),(filename,record_name,route,actual,expected)
            schema=schema_for(root,route)
            if schema is None:
                assert (filename,record_name,route)==('mp_backpacks.xtbl','Rhino','activatable/active_abilities/rhino/rhino_top_speed')
                assert n is not None and decimal(planned)>0
                kind='Float';schema_status='existing_legacy_field_explicitly_approved'
            else:
                kind=schema.get('Type');schema_status='declared'
                assert kind in {'Float','Int','Selection'}
                if kind in {'Float','Int'}:
                    value=decimal(planned);assert value is not None
                    if kind=='Int':assert value==value.to_integral_value()
                    for bound,compare in [('MinValue',lambda a,b:a>=b),('MaxValue',lambda a,b:a<=b)]:
                        text=schema.get(bound)
                        if text is not None:assert compare(value,D(text))
                else:
                    assert planned in [c.value for c in schema.children if c.tag=='Choice']
            if n is None:
                assert filename=='mp_backpack_overrides.xtbl' and schema is not None
                assert schema.get('Required')=='false'
                parent_route,tag=route.rsplit('/',1)
                parent=record
                for part in parent_route.split('/'):parent=parent.child(part)
                assert parent is not None and parent.child(tag) is None
                path=parent.path+'/'+tag+'[1]'
                insertions[parent.path].append((parent,tag,planned))
                change_kind='added_override_field'
            else:
                assert not n.children and actual!=planned
                path=n.path;raw=blob[n.text_start:n.text_end]
                start=n.text_start+len(raw)-len(raw.lstrip())
                end=n.text_end-(len(raw)-len(raw.rstrip()))
                edits.append((start,end,planned.encode('ascii')))
                change_kind='modified_value'
            events.append(dict(package=package,file=filename,record=record_name,
                display_name=DISPLAY_NAMES.get(record_name,record_name),route=route,path=path,
                v4_1=actual,planned=planned,change_kind=change_kind,rule=rule,
                schema_type=kind,schema_status=schema_status))
    for items in insertions.values():
        parent=items[0][0]
        at=blob.rfind(b'\n',0,parent.end)+1
        assert not blob[at:parent.end].strip()
        child=parent.children[0]
        line=blob.rfind(b'\n',0,child.start)+1
        indent=blob[line:child.start];assert not indent.strip()
        newline=b'\r\n' if b'\r\n' in blob else b'\n'
        block=b''.join(indent+('<'+tag+'>'+value+'</'+tag+'>').encode('ascii')+newline for _,tag,value in items)
        edits.append((at,at,block))
    for start,end,value in sorted(edits,reverse=True):blob=blob[:start]+value+blob[end:]
    ET.fromstring(blob)
    return blob,events


def fuel_model(files):
    root=ET.fromstring(files['mp_backpacks.xtbl']);rows=[]
    for rec in root.find('Table'):
        name=rec.findtext('Name')
        jet=rec.find('jetpack')
        fuel=jet if jet is not None else rec.find('activatable/uses_fuel')
        use=D(fuel.findtext('fuel_use_per_second'))
        regen=D(fuel.findtext('fuel_regen_per_second'))
        cost=D(fuel.findtext('fuel_activation_cost') or '0')
        minimum=D(fuel.findtext('minimum_fuel_to_activate') or '0')
        model=lambda value:fmt(value.quantize(D('0.001')))
        rows.append(dict(name=name,display_name=DISPLAY_NAMES.get(name,name),
            fuel_use_per_second=str(use),fuel_regen_per_second=str(regen),
            activation_cost=str(cost),minimum_fuel_to_activate=str(minimum),
            model_full_fuel_active_seconds=model((D(1)-cost)/use) if use>0 else None,
            model_empty_to_full_refill_seconds=model(D(1)/regen),
            model_activation_cost_refill_seconds=model(cost/regen),
            model_uses_from_full_fuel=int(D(1)/cost) if use==0 and cost>0 else None,
            model_assumptions='capacity=1; regeneration paused while active; no engine/upgrade modifiers; not measured'))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--analysis-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();base,out=args.analysis_root,args.output
    sys.path.insert(0,str(base))
    from verify_balance import read_raw,values
    from repair_ultimate import pack_raw
    from vpp_compare import extract
    out.mkdir(parents=True,exist_ok=False);(out/'game_files').mkdir()
    delta,files_audit,packages=[],[],[];all_files={}
    for package in ('misc','table'):
        source=base/'campaign_v4_1/game_files'/(package+'.vpp_pc')
        template=source.read_bytes();assert sha(template)==V4_1_HASHES[package]
        before=read_raw(source);after=before.copy()
        assert pack_raw(template,before)==template
        for filename in PROFILE:
            after[filename],events=patch(filename,before[filename],package)
            delta.extend(events)
        result=pack_raw(template,after)
        target=out/'game_files'/(package+'.vpp_pc');target.write_bytes(result)
        manifest=extract(target,out/'roundtrip'/package)
        assert {e['name']:e['sha256'] for e in manifest['entries']}=={name:sha(blob) for name,blob in after.items()}
        write_json(out/(package+'_manifest.json'),manifest)
        for filename,blob in after.items():
            files_audit.append(dict(package=package,file=filename,changed_vs_v4_1=blob!=before[filename],
                                    v4_1_sha256=sha(before[filename]),output_sha256=sha(blob)))
        packages.append(dict(name=package,file_count=len(after),bytes=len(result),sha256=sha(result),
                             v4_1_sha256=sha(template)))
        all_files[package]=after
        print(package,'packed',len(events),'explosion events;',sum(r['package']==package for r in delta),'total backpack edits',flush=True)
    # Complete original -> V4.2 audit, including explicitly added override fields.
    full={}
    for row in json.loads((base/'campaign_v4_1/parameters-original.json').read_text()):
        row=dict(row,v4_1=row['planned'])
        full[(row['package'],row['file'],row['path'])]=row
    originals={}
    for row in delta:
        k=(row['package'],row['file'])
        if k not in originals:
            originals[k]=values(ET.parse(base/'campaign_v4_originals'/k[0]/k[1]).getroot())
        copy=dict(row,original=originals[k].get(row['path']),literal=row['planned'],factor=None)
        assert (copy['original'] is None)==(row['change_kind']=='added_override_field')
        full[(row['package'],row['file'],row['path'])]=copy
    full_rows=sorted(full.values(),key=lambda r:(r['package'],r['file'],r['path']))
    model=fuel_model(all_files['misc'])
    summary=dict(version='Campaign V4.2 Backpacks',base_version='Campaign V4.1',packages=packages,
        backpack_count=len(BACKPACKS),changed_parameters_vs_v4_1=len(delta),
        added_override_fields=sum(r['change_kind']=='added_override_field' for r in delta),
        changed_parameters_vs_original=len(full_rows),changes_by_file=dict(Counter(r['file'] for r in delta)),
        changes_by_backpack=dict(Counter(r['record'] for r in delta)),game_runtime_tested=False)
    policy=dict(version='Campaign V4.2 Backpacks',base_version='Campaign V4.1',
        target_profile=PROFILE,limitations=LIMITATIONS,
        scope='three shared XTBLs in both archives; no new backpack/ID/asset/unlock/loadout',
        additions='Seven optional fuel fields per archive, explicitly supported by override schema',
        legacy_field_exception='Existing Rhino activatable/active_abilities/rhino/rhino_top_speed=14; current charge_top_speed also 14',
        preserved='all V4.1 hero, hammer, weapons, NPC, mission, economy, vehicle and camera-shake settings outside these exact fields')
    for name,data in [('parameters.json',delta),('parameters-original.json',full_rows),('summary.json',summary),
                      ('policy.json',policy),('fuel-model.json',model)]:write_json(out/name,data)
    for name,data in [('parameters.csv',delta),('parameters-original.csv',full_rows),('files.csv',files_audit),('fuel-model.csv',model)]:
        write_csv(out/name,data)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
