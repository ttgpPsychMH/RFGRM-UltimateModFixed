Python 3.10+, thư viện chuẩn. Không chạy CLI của module cũ.
Profile yêu cầu: backpack_v4_2_profile.py; patcher và validator là hai entry point riêng.

python code/build_campaign_v4_2.py --analysis-root /path/to/analysis --output /new/output
python code/verify_campaign_v4_2.py --analysis-root /path/to/analysis --output /new/output

Inputs dưới analysis root:
campaign_v4_1/game_files/{misc,table}.vpp_pc: từ ZIP V4.1 chính thức.
campaign_v4_1/parameters-original.json và summary.json: từ ZIP báo cáo V4.1.
campaign_v4_originals/{misc,table}/: payload BACKUP original đã giải nén.
Builder pin SHA V4.1. Validator không import patcher; dùng ET và raw reader độc lập.
release_campaign_v4_2.py chỉ tạo tài liệu/ZIP, dùng đường dẫn workspace riêng.
Mã không chạy executable/asset game. Chưa có kiểm thử game runtime.
