#!/usr/bin/env python3
"""Repair the supplied Ultimate Mod table archive, retaining its own edits.

Uses the original solid stream as a recovery source and the exactly reproduced
legacy Align(16) window as the edit baseline. Edits are applied only if their
old bytes match the corresponding intact original span. No game assets run.
"""
import argparse
import collections
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import struct
import xml.etree.ElementTree as ET

from vpp_compare import align, extract, inflate


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def byte_edits(before, after):
    old_lines, new_lines = before.splitlines(keepends=True), after.splitlines(keepends=True)
    offsets = [0]
    for line in old_lines:
        offsets.append(offsets[-1] + len(line))
    edits = []
    for tag, i, j, k, l in difflib.SequenceMatcher(
            None, old_lines, new_lines, autojunk=False).get_opcodes():
        if tag != "equal":
            edits.append(dict(start=offsets[i], end=offsets[j],
                              before=before[offsets[i]:offsets[j]],
                              after=b"".join(new_lines[k:l])))
    replay = before
    for edit in reversed(edits):
        replay = replay[:edit["start"]] + edit["after"] + replay[edit["end"]:]
    need(replay == after, "Edit replay does not reconstruct supplied mod bytes")
    return edits


def pack_raw(template, files):
    """Retain the supplied raw archive's metadata and rewrite sizes/offsets.

    Raw v3 layout follows Gibbed.Volition PackerBase.cs / PackageFileV3.cs:
    2048-byte header, padded directory and names, 2048-aligned raw entries.
    No filename hashes need changing because the name set is unchanged.
    """
    flags, unknown, count, total, ds, ns, us, cs = struct.unpack_from("<8I", template, 0x14C)
    need(flags == 0 and cs == 0xFFFFFFFF, "Expected an uncompressed v3 template")
    need(total == len(template), "Invalid template size")
    names_at = 2048 + align(ds, 2048)
    data_at = names_at + align(ns, 2048)
    header = bytearray(template[:data_at])
    names = template[names_at:names_at + ns]
    items = []
    for index in range(count):
        fields = list(struct.unpack_from("<7I", template, 2048 + 28 * index))
        name = names[fields[0]:names.index(b"\0", fields[0])].decode("ascii")
        need(fields[1] == fields[6] == 0, "Unexpected runtime entry pointers")
        items.append((index, name, fields))
    need({name for _, name, _ in items} == set(files), "Filename set differs from template")
    data = bytearray()
    for index, name, fields in sorted(items, key=lambda item: item[2][2]):
        data.extend(b"\0" * (align(len(data), 2048) - len(data)))
        fields[2], fields[4], fields[5] = len(data), len(files[name]), 0xFFFFFFFF
        struct.pack_into("<7I", header, 2048 + 28 * index, *fields)
        data.extend(files[name])
    struct.pack_into("<I", header, 0x158, data_at + len(data))
    struct.pack_into("<I", header, 0x164, len(data))
    return bytes(header) + bytes(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis-root", type=Path, required=True)
    parser.add_argument("--original-table", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.analysis_root, args.output
    output.mkdir(parents=True, exist_ok=False)
    assets = output / "repaired_table_files"
    assets.mkdir()
    dist = output / "game_files"
    dist.mkdir()
    original_manifest = json.loads((root / "table/original_manifest.json").read_text())
    mod_manifest = json.loads((root / "table/modified_manifest.json").read_text())
    rar_manifest = json.loads((root / "ultimate_mod_package.manifest.json").read_text())
    old_package = root / "ultimate_mod_package/table.vpp_pc"
    old_blob, original_blob = old_package.read_bytes(), args.original_table.read_bytes()
    need(digest(old_blob) == mod_manifest["source_sha256"], "Wrong mod table source")
    need(digest(original_blob) == original_manifest["source_sha256"], "Wrong original table source")
    solid, zstatus = inflate(original_blob[original_manifest["data_offset"]:],
                             original_manifest["declared_uncompressed_data_bytes"])
    expected_mod_files = {e["name"]: e for e in mod_manifest["entries"]}
    repaired_files, mod_files, file_report, edit_report = {}, {}, [], []
    cursor = 0
    for entry in sorted(original_manifest["entries"], key=lambda e: e["offset"]):
        name, size, offset = entry["name"], entry["size"], entry["offset"]
        original = solid[offset:offset + size]
        need(digest(original) == entry["sha256"], "Original extraction mismatch: " + name)
        baseline = solid[cursor:cursor + size]
        mod = (root / "table/modified" / name).read_bytes()
        need(digest(mod) == expected_mod_files[name]["sha256"], "Mod extraction mismatch: " + name)
        mod_files[name] = mod
        delta = offset - cursor
        need(delta >= 0 and len(baseline) == size, "Unexpected legacy window")
        changes = byte_edits(baseline, mod) if mod != baseline else []
        edits = []
        for change in changes:
            start, end = change["start"], change["end"]
            if end <= delta:
                # This span is entirely BEFORE this file, in a preceding file
                # or its padding. The only observed case is one stray 't'.
                disposition = "discarded_change_to_foreign_prefix"
            elif start >= delta and end <= len(baseline):
                a, b = start - delta, end - delta
                need(original[a:b] == change["before"], "Mapped edit old bytes mismatch")
                edits.append((a, b, change["after"]))
                disposition = "applied_to_intact_original"
            else:
                raise ValueError("Edit crosses recovery boundary: " + name)
            edit_report.append(dict(file=name, disposition=disposition,
                                    legacy_start=start, legacy_end=end,
                                    original_start=start - delta,
                                    original_end=end - delta,
                                    before_hex=change["before"].hex(),
                                    after_hex=change["after"].hex()))
        fixed = original
        for a, b, replacement in reversed(edits):
            fixed = fixed[:a] + replacement + fixed[b:]
        need(fixed.startswith(b"<root>"), "Repaired file has an invalid prefix: " + name)
        need(b"\0" not in fixed, "NUL remained in repaired text: " + name)
        need(fixed.rstrip().endswith(b"</root>"), "Repaired file is missing its root end: " + name)
        xml_error = None
        try:
            ET.fromstring(fixed)
        except ET.ParseError as ex:
            xml_error = str(ex)
            need(name == "credits.xtbl" and fixed == original,
                 "Unexpected XML error after repair: " + name + ": " + str(ex))
        (assets / name).write_bytes(fixed)
        repaired_files[name] = fixed
        file_report.append(dict(name=name, original_sha256=digest(original),
                                broken_mod_sha256=digest(mod), repaired_sha256=digest(fixed),
                                original_bytes=len(original), broken_mod_bytes=len(mod),
                                repaired_bytes=len(fixed), applied_edit_blocks=len(edits),
                                mod_edits_retained=bool(edits),
                                differs_from_original=fixed != original,
                                repaired_vs_broken=fixed != mod, xml_error=xml_error))
        cursor += align(size, 16)

    need(len(repaired_files) == 423, "Unexpected table file count")
    need(sum(r["mod_edits_retained"] for r in file_report) == 6, "Unexpected edited file count")
    dispositions = collections.Counter(r["disposition"] for r in edit_report)
    need(dispositions == {"applied_to_intact_original": 215,
                          "discarded_change_to_foreign_prefix": 1}, "Unexpected edit model")
    # A meaningful writer calibration: packing the ORIGINAL broken payloads
    # must reproduce the entire supplied raw VPP byte-for-byte.
    calibration = pack_raw(old_blob, mod_files)
    need(calibration == old_blob, "Raw archive writer does not reproduce source format")
    package = pack_raw(old_blob, repaired_files)
    (dist / "table.vpp_pc").write_bytes(package)
    misc_source = root / "ultimate_mod_package/misc.vpp_pc"
    misc_expected = next(e["sha256"] for e in rar_manifest["entries"] if e["name"] == "misc.vpp_pc")
    need(digest(misc_source.read_bytes()) == misc_expected, "Wrong misc source")
    shutil.copyfile(misc_source, dist / "misc.vpp_pc")
    need(digest((dist / "misc.vpp_pc").read_bytes()) == misc_expected, "misc copy changed")
    roundtrip = extract(dist / "table.vpp_pc", output / "roundtrip_extracted")
    for entry in roundtrip["entries"]:
        need(entry["sha256"] == digest(repaired_files[entry["name"]]),
             "Round-trip payload differs from recovered file")
    (output / "roundtrip_manifest.json").write_text(json.dumps(roundtrip, indent=2), encoding="utf-8")
    report = dict(original_table_sha256=digest(original_blob),
                  broken_table_sha256=digest(old_blob), repaired_table_sha256=digest(package),
                  repaired_table_bytes=len(package), misc_sha256=misc_expected,
                  misc_copied_without_changes=True, table_file_count=len(repaired_files),
                  table_files_byte_identical_to_original=sum(not r["differs_from_original"] for r in file_report),
                  table_files_with_mod_edits=sum(r["mod_edits_retained"] for r in file_report),
                  table_files_changed_by_repair=sum(r["repaired_vs_broken"] for r in file_report),
                  edit_dispositions=dict(dispositions),
                  broken_package_repacked_byte_identically=True,
                  roundtrip_payloads_verified=len(roundtrip["entries"]),
                  original_stream_status=zstatus, game_runtime_tested=False,
                  files=file_report, edits=edit_report)
    (output / "repair_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key not in ("files", "edits")}, indent=2))


if __name__ == "__main__":
    main()
