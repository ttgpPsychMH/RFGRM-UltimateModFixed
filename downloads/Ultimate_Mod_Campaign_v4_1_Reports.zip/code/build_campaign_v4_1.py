#!/usr/bin/env python3
"""Patch released V4 with original-based player hammer values and modest QoL.

No game assets execute. Uses released V4 as immutable base; only six named
XTBL files may change. Independent raw VPP reading and XML parsing verify
every payload, numeric formula, unchanged leaf and previous V4 setting.
"""
import argparse
from collections import Counter
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

from rebalance_rules import xml_inventory, decimal, fmt, schema_types
from verify_balance import read_raw, values, index_elements, relations
from build_campaign_v4 import record_of, is_campaign, numeric_patch

D = Decimal
V4_HASHES = {'misc':'bd2cec4003673b44a1f17c7319986ccc78ea365ad95b11c0a7dffa01735a5982',
             'table':'839985e20922972c70f8d0c8bb9bd6f82e575b1657ab58ecfe582733c3ce867b'}
HAMMER = {'NPCDamage':('10','hammer_npc_x10'),
          'VehicleDamage':('20','hammer_vehicle_x20'),
          'StructureDamage':('5','hammer_structure_x5'),
          'DefaultDamage':('5','hammer_default_x5'),
          'HitRange':('1.25','hammer_reach_x1_25'),
          'HitRadius':('1.25','hammer_hit_radius_x1_25'),
          'ImpactForce':('1.5','hammer_impact_force_x1_5'),
          'RagdollImpulse':('1.5','hammer_ragdoll_impulse_x1_5')}
HANDHELD = {'Entries:EDF','Entries:Guerilla','Entries:Marauder'}
GUN_CLASSES = {'bullet','arc_welder','nano_rifle','grinder','harpoon','launcher'}
HANDLING = {'Recoil_Kick','Spread_Min','Spread_Max','Spread_Fine_Aim_Min','Spread_Fine_Aim_Max'}
ALLOWED_FILES = {'melee.xtbl','dlc01_melee.xtbl','weapons.xtbl',
                 'dlc01_weapons.xtbl','tweak_table.xtbl','dlc01_tweak_table.xtbl'}


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def write_csv(path,rows):
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields,lineterminator='\n')
        writer.writeheader();writer.writerows(rows)


def decision(filename,node):
    """Return original factor, literal, rationale; explicit names beat heuristics."""
    record=record_of(node)
    if node.children or not is_campaign(record):return None
    base=filename.removeprefix('dlc01_')
    # 0.0 here is a documented fraction, not a sentinel. Explicitly authorized.
    if base=='tweak_table.xtbl' and node.tag=='Value':
        name=record.get('Name')
        if name=='Player_death_salvage_percent_kept':
            assert node.value=='0.0'
            return None,'1','salvage_kept_on_death_fraction_1'
        if name=='Salvage_touch_delay_ms':
            assert D(node.value)==1000
            return None,'250','salvage_touch_delay_250_ms'
    original=decimal(node.value)
    if original is None or original<=0:return None
    if base=='melee.xtbl':
        anim=node.ancestor('AnimSet')
        if ((record.get('Name') or '').startswith('sledgehammer_melee_')
                and anim and anim.get('AnimSetName')=='Player.xtbl' and node.tag in HAMMER):
            factor,label=HAMMER[node.tag]
            if node.tag=='HitRange' and node.parent.tag=='SecondaryImpact':
                label='hammer_secondary_reach_x1_25'
            return factor,None,label
    if (base=='weapons.xtbl' and record.get('_Editor/Category') in HANDHELD
            and record.get('Weapon_Class') in GUN_CLASSES and node.tag in HANDLING):
        return '0.8',None,'player_weapon_recoil_or_spread_x0_8'
    return None


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();base,out=args.analysis_root,args.output
    sys.path.insert(0,str(base))
    from repair_ultimate import pack_raw
    from vpp_compare import extract
    out.mkdir(parents=True,exist_ok=False);(out/'game_files').mkdir()
    full={}
    for row in json.loads((base/'campaign_v4/parameters.json').read_text()):
        row=dict(row,v4=row['planned'])
        full[(row['package'],row['file'],row['path'])]=row
    delta,files_audit,packages=[],[],[]
    validation={'status':'passed','game_runtime_tested':False,'packages':{}}
    for package in ('misc','table'):
        source_path=base/'campaign_v4/game_files'/(package+'.vpp_pc')
        template=source_path.read_bytes();assert sha(template)==V4_HASHES[package]
        before=read_raw(source_path);after=before.copy();grouped={}
        assert pack_raw(template,before)==template
        for filename in sorted(ALLOWED_FILES):
            original_blob=(base/'campaign_v4_originals'/package/filename).read_bytes()
            original_root,original=xml_inventory(original_blob)
            _,current=xml_inventory(before[filename]);assert original.keys()==current.keys()
            kinds=schema_types(original_root);events=[];plans={}
            for path,node in original.items():
                choice=decision(filename,node)
                if choice is None:continue
                factor,literal,label=choice
                planned=literal if literal is not None else fmt(D(node.value)*D(factor))
                if D(current[path].value)==D(planned):continue
                types=sorted(kinds.get(node.tag,set()))
                if 'Int' in types:assert D(planned)==D(planned).to_integral_value()
                row=dict(package=package,file=filename,path=path,tag=node.tag,
                         original=node.value,v4=current[path].value,planned=planned,
                         factor=factor,literal=literal,rule=label,rounding='exact',schema_types=types)
                events.append(row);plans[path]=planned
                full[(package,filename,path)]=row
            if events:
                after[filename]=numeric_patch(before[filename],plans)
                grouped[filename]=events;delta.extend(events)
        result=pack_raw(template,after)
        output_path=out/'game_files'/(package+'.vpp_pc');output_path.write_bytes(result)
        manifest=extract(output_path,out/'roundtrip'/package)
        check=read_raw(output_path)
        assert before.keys()==check.keys()
        assert {e['name']:e['sha256'] for e in manifest['entries']}=={n:sha(b) for n,b in after.items()}
        count=0;xml_valid=0;exceptions={};fine_aim_pairs=0
        for filename,blob in check.items():
            assert blob==after[filename]==(out/'roundtrip'/package/filename).read_bytes()
            events=grouped.get(filename,[])
            if not events:assert blob==before[filename]
            files_audit.append(dict(package=package,file=filename,changed_vs_v4=blob!=before[filename],
                                    v4_sha256=sha(before[filename]),v4_1_sha256=sha(blob)))
            if not filename.endswith('.xtbl'):
                assert blob==before[filename];continue
            try:tree=ET.fromstring(blob)
            except ET.ParseError as ex:
                assert filename=='credits.xtbl' and blob==before[filename]
                assert blob==(base/'campaign_v4_originals'/package/filename).read_bytes()
                exceptions[filename]=str(ex);continue
            xml_valid+=1
            if not events:continue
            old_tree=ET.fromstring(before[filename])
            original_tree=ET.parse(base/'campaign_v4_originals'/package/filename).getroot()
            old_map,new_map,original_map=values(old_tree),values(tree),values(original_tree)
            assert old_map.keys()==new_map.keys()==original_map.keys()
            actual={p for p in old_map if old_map[p]!=new_map[p]}
            assert actual=={r['path'] for r in events}
            for row in events:
                path=row['path']
                assert old_map[path]==row['v4'] and new_map[path]==row['planned']
                assert original_map[path]==row['original']
                expected=D(row['literal']) if row['literal'] is not None else D(original_map[path])*D(row['factor'])
                assert D(new_map[path])==expected
                count+=1
            for path,value in old_map.items():
                if path not in actual:assert new_map[path]==value
                if path not in actual and decimal(value) is not None and D(value)<=0:
                    assert new_map[path]==value
            assert not (relations(tree)-relations(old_tree))
            old_idx,new_idx=index_elements(old_tree),index_elements(tree)
            assert old_idx.keys()==new_idx.keys()
            for path,node in new_idx.items():
                lo,hi=node.findtext('Spread_Fine_Aim_Min'),node.findtext('Spread_Fine_Aim_Max')
                if lo is not None and hi is not None:
                    if D(lo)>D(hi):
                        assert D(old_idx[path].findtext('Spread_Fine_Aim_Min'))>D(old_idx[path].findtext('Spread_Fine_Aim_Max'))
                    fine_aim_pairs+=1
            # Player hammer branches only; NPC and legacy melee stay byte-semantically V4.
            if filename.endswith('melee.xtbl'):
                for path,node in new_idx.items():
                    if node.tag=='AnimSet' and node.findtext('AnimSetName')!='Player.xtbl':
                        assert ET.tostring(node)==ET.tostring(old_idx[path])
        # Independent full original->current inventory must match merged V4 audit.
        full_count=0
        for filename in {k[1] for k in full if k[0]==package}:
            original_tree=ET.parse(base/'campaign_v4_originals'/package/filename).getroot()
            now_tree=ET.fromstring(check[filename])
            original_map,now_map=values(original_tree),values(now_tree)
            assert original_map.keys()==now_map.keys()
            actual={p for p in original_map if original_map[p]!=now_map[p]}
            expected={k[2] for k in full if k[:2]==(package,filename)}
            assert actual==expected
            for path in actual:
                row=full[(package,filename,path)]
                assert original_map[path]==row['original'] and now_map[path]==row['planned']
            full_count+=len(actual)
        validation['packages'][package]=dict(file_count=len(check),xml_valid=xml_valid,
            unchanged_original_xml_exceptions=exceptions,changed_files_vs_v4=sorted(grouped),
            numeric_delta_verified=count,full_original_delta_verified=full_count,
            fine_aim_pairs_checked=fine_aim_pairs,no_new_min_max_violations=True,
            roundtrip_passed=True,independent_reader_passed=True,
            all_unselected_payloads_and_xml_values_preserved=True,
            nonplayer_hammer_branches_preserved=True,
            camera_shake_remote_limits_vehicle_settings_preserved=True)
        packages.append(dict(name=package,file_count=len(check),bytes=len(result),sha256=sha(result),
                             v4_sha256=sha(template),changed_parameters_vs_v4=count,
                             changed_parameters_vs_original=full_count))
        write_json(out/(package+'_manifest.json'),manifest)
        print(package,'packed and verified:',count,'new edits;',full_count,'total vs original',flush=True)
    for p in (out/'roundtrip/table').iterdir():
        if p.name!='vehicles.xtbl':assert p.read_bytes()==(out/'roundtrip/misc'/p.name).read_bytes()
    # Representative values independently queried with ElementTree.
    samples=[]
    def sample(filename,xpath,expected):
        for package in ('misc','table'):
            actual=ET.parse(out/'roundtrip'/package/filename).getroot().findtext(xpath)
            assert actual==expected,(filename,xpath,actual,expected)
            samples.append(dict(package=package,file=filename,xpath=xpath,value=actual))
    move="./Table/MeleeMove[Name='sledgehammer_melee_vert']/MoveDataList/AnimSet[AnimSetName='Player.xtbl']/"
    for route,want in [('Damage/NPCDamage','7500'),('Damage/VehicleDamage','5000'),
                       ('Damage/StructureDamage','7500'),('Damage/DefaultDamage','7500'),
                       ('Damage/PlayerDamageFromNPC','37.5'),('HitRange','2.75'),
                       ('HitRadius','0.5'),('SecondaryImpact/HitRange','2.5'),
                       ('ImpactForce','450'),('RagdollImpulse','120'),('AwayImpulseScale','1.0')]:
        sample('melee.xtbl',move+route,want)
    sample('tweak_table.xtbl',"./Table/Tweak_Table_Entry[Name='Salvage_touch_delay_ms']/Value",'250')
    sample('tweak_table.xtbl',"./Table/Tweak_Table_Entry[Name='Player_death_salvage_percent_kept']/Value",'1')
    sample('character.xtbl',"./Table/Character[Name='rfg_PC']/max_speed",'10')
    validation['representative_checks']=samples
    full_rows=sorted(full.values(),key=lambda r:(r['package'],r['file'],r['path']))
    summary=dict(version='Campaign V4.1',base_version='Campaign V4',packages=packages,
                 changed_parameters_vs_v4=len(delta),changed_parameters_vs_original=len(full_rows),
                 changes_by_rule=dict(Counter(r['rule'] for r in delta)),
                 changes_by_file=dict(Counter(r['file'] for r in delta)),game_runtime_tested=False)
    for name,data in [('parameters.json',delta),('parameters-original.json',full_rows),
                      ('summary.json',summary),('validation.json',validation)]:write_json(out/name,data)
    for name,data in [('parameters.csv',delta),('parameters-original.csv',full_rows),('files.csv',files_audit)]:
        write_csv(out/name,data)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
