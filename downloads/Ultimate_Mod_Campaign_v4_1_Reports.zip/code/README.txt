Python 3.10+, thư viện chuẩn. Entry point là build_campaign_v4_1.py.
Không chạy CLI của các module cũ: chỉ các helper được import.
python code/build_campaign_v4_1.py --analysis-root /path/to/analysis --output /new/output

Inputs dưới analysis root:
- campaign_v4/game_files/{misc,table}.vpp_pc: lấy từ ZIP V4 đã phát hành.
- campaign_v4/parameters.json: lấy từ ZIP báo cáo V4.
- campaign_v4_originals/{misc,table}/: payload giải nén từ BACKUP gốc.
Builder pin SHA V4, kiểm tra toàn bộ output bằng hai bộ đọc và hai parser XML.
release_campaign_v4_1.py chỉ tạo tài liệu/ZIP, dùng đường dẫn workspace riêng;
không cần chạy nó để chơi. Các module khác chỉ phục vụ đọc XML/VPP và pack.
