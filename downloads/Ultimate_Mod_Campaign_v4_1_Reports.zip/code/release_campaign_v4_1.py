#!/usr/bin/env python3
"""Package the validated V4.1 build, preserving historical V4 downloads."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET
import zipfile

BASE=Path('/workspace/rfgrm-vpp-analysis')
OUT=BASE/'campaign_v4_1'
REPO=Path('/workspace/RFGRM-UltimateModFixed')
REPORTS=REPO/'reports'
DL=REPO/'downloads'


def sha(blob):return hashlib.sha256(blob).hexdigest()


def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    summary=json.loads((OUT/'summary.json').read_text())
    validation=json.loads((OUT/'validation.json').read_text());assert validation['status']=='passed'
    pkgs={p['name']:p for p in summary['packages']}
    policy=json.loads((REPORTS/'campaign-v4-policy.json').read_text())
    policy.update(version='Campaign V4.1',base_version='Campaign V4',
                  hammer_player_animset={'npc_damage_factor':10,'vehicle_damage_factor':20,
                    'structural_damage_factor':5,'default_damage_factor':5,
                    'hit_range_and_secondary_hit_range_factor':1.25,'hit_radius_factor':1.25,
                    'impact_force_and_ragdoll_impulse_factor':1.5,
                    'factor_basis':'original value of each move, not V4',
                    'scope':'existing fields in Player.xtbl animsets of sledgehammer_melee_*; base and DLC',
                    'incoming_player_damage_away_impulse_height_direction_flags_and_timing':'preserve V4',
                    'missing_fields':'do not add missing NPC/vehicle/structure fields to small attack'},
                  player_gun_handling={'factor':0.8,'basis':'original',
                    'fields':['Recoil_Kick','Spread_Min','Spread_Max','Spread_Fine_Aim_Min','Spread_Fine_Aim_Max'],
                    'scope':'positive fields of campaign handheld firearms and launchers',
                    'npc_spread_fields':'preserve V4',
                    'notes':'Recoil_Kick is player-only per schema; explicit NPC spreads remain unchanged, runtime fallback is not proven'},
                  salvage_touch_delay_ms=250,salvage_kept_on_death_fraction=1,
                  salvage_death_status='experimental; field description says 1 means all; live death/save behavior not tested',
                  salvage_pickup_radius='unchanged: no unambiguous tunable distance/radius located in supplied VPP tables',
                  preserved_from_v4=['camera_shake presets','remote attached limit and upgrades',
                    'vehicle standing/ragdoll thresholds','all other payloads/fields outside the explicit V4.1 delta'])
    write_json(OUT/'policy.json',policy)
    sums=''.join(p['sha256']+'  '+p['name']+'.vpp_pc\n' for p in summary['packages'])
    (OUT/'SHA256SUMS.txt').write_text(sums)
    guide=f'''ULTIMATE MOD — CAMPAIGN V4.1: BÚA MẠNH HƠN VÀ TIỆN ÍCH SALVAGE
Red Faction Guerrilla Re-Mars-tered — offline

CÀI ĐẶT
1. Thoát game, sao lưu misc.vpp_pc và table.vpp_pc đang dùng.
2. Giải nén ZIP V4.1; chép CẢ HAI VPP vào thư mục game chứa hai file
   cùng tên, đồng ý thay thế. Đây là gói đầy đủ, không cần cài V4 trước.
3. Hoàn tác bằng cách thoát game và chép lại bản sao lưu.
4. Công cụ quản lý mod/RSL có thể ghi đè bảng hoặc hành vi runtime;
   V4.1 không cài hoặc thay đổi tiện ích RSL nhảy cao/chạy riêng.

THAY ĐỔI MỚI SO VỚI V4 — TÍNH TỪ ORIGINAL
Chỉ 6 bảng thay đổi trong mỗi gói: melee, weapons, tweak_table và bản DLC.

BÚA: NHÁNH ANIMSET PLAYER.XTBL
- NPCDamage x10; VehicleDamage x20; StructureDamage x5.
- DefaultDamage x5 theo đề xuất trước; đây là nhánh chung, không cộng với
  damage NPC/xe/công trình. Các nhánh riêng ưu tiên theo xử lý của engine.
- HitRange và SecondaryImpact/HitRange x1,25; HitRadius x1,25.
  Tầm ngang/dọc 2 -> 2,5 m / 2,2 -> 2,75 m; bán kính chính 0,4 -> 0,5 m.
- ImpactForce và RagdollImpulse x1,5.
- Tính riêng từ original từng đòn thường/u1/u2/vàng; không nhân từ V4.
- Giữ sát thương người chơi nhận, AwayImpulseScale, HitHeight, hướng,
  animation timing, flags và liên kết nâng cấp theo V4.
- Chỉ sửa trường đã có. small có DefaultDamage 150 -> 750; không tự thêm
  các nhánh NPC/xe/công trình đang vắng. Nhánh animset NPC giữ V4.
- Default_Refire_Delay bị engine bỏ qua với melee theo schema; không sửa
  nó như cách tăng tốc vung. Cửa sổ va chạm và hoạt ảnh vẫn như trước.
- Nhân vật DLC dùng Samanya.xtbl có Parent_Skeleton=Player; cần thử thực tế
  đường kế thừa/chọn damage của engine, chưa cam kết mọi đòn DLC.

DAMAGE BÚA V4.1 (NGANG / DỌC NẾU CÓ HAI SỐ)
Thường: NPC 6500/7500; xe 5000; công trình 7500; DefaultDamage 7500.
Nâng cấp 1: NPC 8500/9500; xe 7000; công trình 10000; DefaultDamage 10000.
Nâng cấp 2: NPC 10500/11500; xe 9000; công trình 12500; DefaultDamage 12500.
Vàng: NPC 21000/23000; xe 18000; công trình 25000; DefaultDamage 25000.
Đây là giá trị cấu hình, không phải damage cuối đã đo sau giáp/difficulty.

SALVAGE
- Salvage_touch_delay_ms: 1000 -> 250 ms (0,25 giây).
  Đây là thời gian chờ nhặt salvage mới sinh, không phải tốc độ hút đồ.
- Player_death_salvage_percent_kept: 0,0 -> 1.
  Mô tả trong dữ liệu: 1 là giữ toàn bộ salvage sau khi chết. Đây là mức
  thử nghiệm được cho phép; chưa xác minh tương tác chết/load/save trong game.
- Bán kính nhặt giữ gốc: chưa tìm được trường distance/radius rõ nghĩa
  trong các bảng được cung cấp. Không đổi kích thước mesh/va chạm và không
  nhầm Value=1 của nâng cấp salvage_collector thành bán kính một mét.
- Không đổi lượng salvage rơi, giá trị vật liệu, thời gian spawn đồ hay
  điều kiện mở khóa salvage_collector.

SÚNG DỄ KIỂM SOÁT HƠN
- Các giá trị dương Recoil_Kick, Spread_Min/Max, Spread_Fine_Aim_Min/Max
  của súng cầm tay/launcher campaign được đưa về x0,8 original: giảm 20%.
- Ví dụ M16: Recoil_Kick 0,9 -> 0,72; Spread_Min/Max 1/2,3 -> 0,8/1,84;
  fine aim 0,7/1,1 -> 0,56/0,88. Theo schema spread là góc tính bằng độ.
- Recoil_Kick là lực giật camera hướng lên chỉ cho người chơi theo schema.
  Các trường NPC_Spread_Min/Max, RecoilImpulse, nhịp bắn/nạp, multiplier
  chạy và To_Spread_Min/Max giữ V4. Giá trị 0 giữ 0; không thêm trường thiếu.
- Không sửa preset rung camera khi đánh/nổ, đúng lựa chọn của người dùng.
  Các vũ khí dùng chung hoặc nhánh thiếu NPC spread vẫn cần kiểm tra fallback
  trong game; không cam kết AI hoàn toàn không bị ảnh hưởng gián tiếp.

CẤU HÌNH NỀN V4 GIỮ LẠI
- Alec HP 5500; giới hạn tốc độ 10 m/s; giảm sát thương/hồi phục mạnh kiểu V4.
- NPC campaign chính: Guerilla/Civilian HP x3; EDF/Marauder x2; trang bị gốc.
  DLC Marauder/tù nhân đồng minh x3, EDF x2; hai actor scripted Dan và
  RFCommander DLC vẫn giữ HP gốc theo ngoại lệ V4.
- Súng không có mẫu nổ: damage NPC/xe x3; súng có mẫu nổ dùng quy tắc nổ.
- Remote/mine/RPG/Gauss/nano/grinder và mẫu DLC được chọn: damage NPC/xe
  x2, công trình x1,5, các bán kính tác động dương x1,5. Thermobaric damage
  x1,5, bán kính gốc 6,5 m. Mẫu nổ riêng môi trường/nhiệm vụ giữ V4.
- Xe giữ giá trị V3 theo từng gói; nhóm tốc độ/động cơ được chọn x1,5,
  HP được chọn x5. Ngưỡng đứng trên xe/ragdoll không đổi ở V4.1.
- Tiếp viện delay /2, số quân và pool xe gốc; timer mục tiêu x3;
  chỉ courier Escape_Speed /3; salvage reward rõ loại tiền x3;
  đạn mang/tiếp tế x5, cỡ băng gốc; Cost mua/nâng cấp /2 làm tròn lên.
- Giới hạn gắn remote cùng lúc, morale/control, các điều kiện mở khóa,
  camera shake và các thông số ngoài phạm vi V4.1 giữ V4.

KIỂM TRA VÀ GIỚI HẠN
- Mỗi gói có 203 giá trị mới so V4; tổng 406, đếm cả bản sao ở hai gói.
  Tổng so original là {summary['changed_parameters_vs_original']} giá trị.
- Đọc độc lập cấu trúc VPP, giải nén đối chiếu mọi payload; mọi XML sửa
  hợp lệ; không có vi phạm min/max mới, gồm spread fine aim.
- Giữ nguyên tập tên và số lượng tệp 1208/423; mọi nội dung ngoài phạm vi
  và nhánh melee không phải Player.xtbl giữ V4.
- Mỗi gói còn ký tự credits.xtbl không hợp lệ từ original, giữ nguyên byte.
- Chưa chạy thử trong game. Búa phá công trình x5 và lực hất cao hơn có thể
  làm sập nhà, hại con tin hoặc gây va chạm phụ. Bảo vệ Alec không bảo vệ
  mục tiêu nhiệm vụ. Nên thử giải cứu/hộ tống/demolitions trên save phụ.

SHA-256 FILE GAME V4.1
{sums.rstrip()}

Báo cáo trên GitHub: reports/campaign-v4_1.md. ZIP báo cáo riêng có toàn bộ
giá trị original/V4/V4.1, validation, policy, manifest và mã dựng.
Các báo cáo mang tên V4 hoặc cũ hơn mô tả đúng phiên bản ghi trên tên.
'''
    (OUT/'HUONG_DAN.txt').write_text(guide,encoding='utf-8')
    # Preserve the old guide for historical report links.
    historical=DL/'HUONG_DAN_V4.txt'
    if not historical.exists():shutil.copyfile(DL/'HUONG_DAN.txt',historical)
    shutil.copyfile(OUT/'HUONG_DAN.txt',DL/'HUONG_DAN.txt')
    old_report=REPORTS/'campaign-v4.md'
    old_report.write_text(old_report.read_text().replace('../downloads/HUONG_DAN.txt','../downloads/HUONG_DAN_V4.txt'))
    hammer=[]
    for fn in ('melee.xtbl','dlc01_melee.xtbl'):
        trees=[ET.parse(p/fn).getroot() for p in [BASE/'campaign_v4_originals/misc',
                                                BASE/'campaign_v4/roundtrip/misc',OUT/'roundtrip/misc']]
        for record in trees[2].find('Table'):
            name=record.findtext('Name') or ''
            if not name.startswith('sledgehammer_melee_'):continue
            row={'file':fn,'move':name}
            for stage,tree in zip(('original','v4','v4_1'),trees):
                a=tree.find("Table/MeleeMove[Name='%s']/MoveDataList/AnimSet[AnimSetName='Player.xtbl']"%name)
                for path in ['Damage/DefaultDamage','Damage/NPCDamage','Damage/VehicleDamage','Damage/StructureDamage',
                             'Damage/PlayerDamageFromNPC','HitRange','HitRadius','SecondaryImpact/HitRange',
                             'ImpactForce','RagdollImpulse','AwayImpulseScale']:
                    row[stage+'_'+path]=a.findtext(path)
            hammer.append(row)
    with (OUT/'hammer.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(hammer[0]),lineterminator='\n');writer.writeheader();writer.writerows(hammer)
    report=f'''# Campaign V4.1 — búa mạnh hơn, nhặt salvage nhanh và súng dễ kiểm soát

**[Tải V4.1 đầy đủ](../downloads/Ultimate_Mod_Campaign_v4_1.zip)** ·
[Hướng dẫn](../downloads/HUONG_DAN.txt) · [Báo cáo/mã dựng ZIP](../downloads/Ultimate_Mod_Campaign_v4_1_Reports.zip).

V4.1 dùng V4 đã phát hành làm nền. Mọi hệ số búa tính từ **original từng
đòn**, không nhân từ V4. Chỉ sáu bảng mỗi gói thay đổi; các phần khác giữ V4.

| Nhóm | Cấu hình V4.1 |
|---|---|
| Búa NPCDamage | Original ×10 |
| Búa VehicleDamage | Original ×20 |
| Búa StructureDamage | Original ×5 |
| Búa DefaultDamage | Original ×5 theo đề xuất đã chấp thuận; không cộng với nhánh theo mục tiêu |
| HitRange và SecondaryImpact/HitRange | Original ×1,25 |
| HitRadius | Original ×1,25; các đòn chính 0,4 → 0,5 m |
| ImpactForce / RagdollImpulse | Original ×1,5 |
| Nhặt salvage mới sinh | Thời gian chờ 1000 → 250 ms |
| Salvage sau khi chết | Fraction 0,0 → 1: giữ 100% theo mô tả; thử nghiệm, chưa xác minh runtime |
| Độ giật/tản súng | Recoil_Kick và spread thường/fine aim dương ×0,8 original, giảm 20% |

Giữ V4 ở sát thương Alec nhận, hướng/độ cao/away impulse của đòn, hoạt ảnh,
NPC melee, các cờ, camera shake, ngưỡng đứng trên xe, remote limit và unlock.
Chỉ sửa nhánh Player.xtbl của búa, không tăng mọi nhánh NPC cùng lúc.

## Búa: giá trị V4.1

| Bản | NPCDamage ngang/dọc | VehicleDamage | StructureDamage | DefaultDamage |
|---|---:|---:|---:|---:|
| Thường | 6500 / 7500 | 5000 | 7500 | 7500 |
| Nâng cấp 1 | 8500 / 9500 | 7000 | 10000 | 10000 |
| Nâng cấp 2 | 10500 / 11500 | 9000 | 12500 | 12500 |
| Vàng | 21000 / 23000 | 18000 | 25000 | 25000 |

Tầm ngang/dọc 2,5 / 2,75 m; kiểm tra phụ 2,375 / 2,5 m. small có
DefaultDamage 750 và tầm 0,625; các nhánh riêng đang thiếu không được thêm.
[CSV đủ original/V4/V4.1 của mọi đòn](campaign-v4_1-hammer.csv).

Đây là giá trị cấu hình, không phải damage cuối sau giáp/difficulty. Búa vàng
có lực gốc cao nên vẫn có thể hất mạnh. Không sửa tốc độ vung: schema nói
Default_Refire_Delay bị bỏ qua với melee; event/animation timing giữ V4.
Samanya DLC kế thừa Player skeleton trong dữ liệu, nhưng đường chọn melee
runtime chưa được kiểm thử. Các liên kết đòn di chuyển cũ giữ V4.

## Salvage và điều khiển súng

- Thời gian nhặt 250 ms chỉ rút ngắn chờ đối với salvage mới sinh, không mở
  rộng phạm vi hút. Không tìm được trường bán kính nhặt có nghĩa/đơn vị rõ
  trong hai gói; không giả lập bằng cách tăng mesh/collision hoặc coi
  Value=1 của salvage_collector là khoảng cách.
- Player_death_salvage_percent_kept=1 theo mô tả là giữ toàn bộ; cần thử
  chết và load save để xác nhận engine thực hiện. Đây là phép thử được yêu cầu.
- Giảm 20% Recoil_Kick, Spread_Min/Max, Spread_Fine_Aim_Min/Max dương của
  16 định nghĩa súng/launcher cầm tay campaign. Không sửa entry MP/test.
  Recoil_Kick được schema ghi rõ chỉ áp dụng người chơi; không đổi
  RecoilImpulse hoặc preset rung camera của đánh/nổ.
- Ví dụ M16: recoil 0,9 → 0,72; spread 1/2,3 → 0,8/1,84 độ;
  fine aim 0,7/1,1 → 0,56/0,88 độ. NPC_Spread_Min/Max giữ V4.
  Nhánh thiếu NPC spread vẫn có thể dùng fallback; chưa xác nhận engine.
- Không sửa NPC equipment, tốc độ bắn/nạp, recoil vật lý, giới hạn remote,
  điều kiện mở khóa, ngưỡng ragdoll khi đứng trên xe hoặc lượng salvage rơi.

## Kiểm tra

- **406 thay đổi so V4**, mỗi gói 203; tổng **{summary['changed_parameters_vs_original']}** so original.
  Đếm cả bản sao bảng chung giữa hai gói, không phải số hiệu ứng độc lập.
- Giữ tập tên 1208/423 tệp. Chỉ melee.xtbl, weapons.xtbl, tweak_table.xtbl
  và bản DLC tương ứng thay đổi. Mọi payload khác giữ từng byte của V4.
- Đọc VPP độc lập, kiểm tra header/offset/hash tên/padding/chiều dài,
  giải nén đối chiếu toàn bộ 1631 payload; kiểm tra từng đường dẫn XML,
  công thức theo original và toàn bộ giá trị ngoài phạm vi.
- Mọi XML sửa hợp lệ; không có lỗi min/max mới, gồm fine-aim spread.
  credits.xtbl giữ lỗi ký tự có sẵn từ original và không đổi byte.
- **Chưa chạy thử trong game.** Structure damage ×5 và lực hất cao hơn có
  thể phá nhà, hại con tin/mục tiêu hộ tống. Thử trên save phụ trước.

[Delta V4 → V4.1](campaign-v4_1-parameters.csv) ·
[Toàn bộ original → V4.1](campaign-v4_1-parameters-original.csv) ·
[Policy đầy đủ kế thừa V4](campaign-v4_1-policy.json) ·
[Validation](campaign-v4_1-validation.json) · [Cấu hình nền V4](campaign-v4.md).

```text
{sums.rstrip()}
```
'''
    (OUT/'README.md').write_text(report,encoding='utf-8')
    (REPORTS/'campaign-v4_1.md').write_text(report,encoding='utf-8')
    for name in ['parameters.csv','parameters-original.csv','summary.json','validation.json','policy.json','hammer.csv']:
        shutil.copyfile(OUT/name,REPORTS/('campaign-v4_1-'+name))
    code=OUT/'code';code.mkdir(exist_ok=True)
    for src in [BASE/'rebalance_work'/n for n in ['build_campaign_v4_1.py','release_campaign_v4_1.py',
                'build_campaign_v4.py','rebalance_rules.py','verify_balance.py']]+[BASE/'repair_ultimate.py',BASE/'vpp_compare.py']:
        shutil.copyfile(src,code/src.name)
    (code/'README.txt').write_text('''Python 3.10+, thư viện chuẩn. Entry point là build_campaign_v4_1.py.
Không chạy CLI của các module cũ: chỉ các helper được import.
python code/build_campaign_v4_1.py --analysis-root /path/to/analysis --output /new/output

Inputs dưới analysis root:
- campaign_v4/game_files/{misc,table}.vpp_pc: lấy từ ZIP V4 đã phát hành.
- campaign_v4/parameters.json: lấy từ ZIP báo cáo V4.
- campaign_v4_originals/{misc,table}/: payload giải nén từ BACKUP gốc.
Builder pin SHA V4, kiểm tra toàn bộ output bằng hai bộ đọc và hai parser XML.
release_campaign_v4_1.py chỉ tạo tài liệu/ZIP, dùng đường dẫn workspace riêng;
không cần chạy nó để chơi. Các module khác chỉ phục vụ đọc XML/VPP và pack.
''',encoding='utf-8')
    main_zip=DL/'Ultimate_Mod_Campaign_v4_1.zip'
    with zipfile.ZipFile(main_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for package in ('misc','table'):z.write(OUT/'game_files'/(package+'.vpp_pc'),package+'.vpp_pc')
        for name in ('HUONG_DAN.txt','SHA256SUMS.txt'):z.write(OUT/name,name)
    report_zip=DL/'Ultimate_Mod_Campaign_v4_1_Reports.zip'
    with zipfile.ZipFile(report_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in ['README.md','HUONG_DAN.txt','SHA256SUMS.txt','parameters.csv','parameters.json',
                     'parameters-original.csv','parameters-original.json','files.csv','summary.json',
                     'validation.json','policy.json','hammer.csv','misc_manifest.json','table_manifest.json']:
            z.write(OUT/name,name)
        for p in sorted(code.iterdir()):z.write(p,'code/'+p.name)
    checks={}
    for p in (main_zip,report_zip):
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            assert len(z.namelist())==len(set(z.namelist()))
            if p==main_zip:
                assert set(z.namelist())=={'misc.vpp_pc','table.vpp_pc','HUONG_DAN.txt','SHA256SUMS.txt'}
                for package in ('misc','table'):assert sha(z.read(package+'.vpp_pc'))==pkgs[package]['sha256']
            else:assert json.loads(z.read('validation.json'))['status']=='passed'
        checks[p.name]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'zip_crc_passed':True}
    # Historical V4 distributions must remain immutable.
    for name,meta in json.loads((REPORTS/'campaign-v4-release-validation.json').read_text())['artifacts'].items():
        assert sha((DL/name).read_bytes())==meta['sha256']
    write_json(OUT/'release_validation.json',{'status':'passed','artifacts':checks,
                                           'historical_v4_zips_unchanged':True,'game_runtime_tested':False})
    shutil.copyfile(OUT/'release_validation.json',REPORTS/'campaign-v4_1-release-validation.json')
    keep=[l for l in (DL/'SHA256SUMS.txt').read_text().splitlines()
          if l and l.split()[-1] not in {'misc.vpp_pc','table.vpp_pc',main_zip.name,report_zip.name}]
    (DL/'SHA256SUMS.txt').write_text(sums+'\n'.join(keep)+'\n'+''.join(
        m['sha256']+'  '+n+'\n' for n,m in checks.items()))
    print(json.dumps(checks,indent=2))


if __name__=='__main__':main()
