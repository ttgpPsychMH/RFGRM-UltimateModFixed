#!/usr/bin/env python3
"""Read-only inventory of direct hammer configuration in originals and V4."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).parent))
from verify_balance import index_elements

BASE = Path('/workspace/rfgrm-vpp-analysis')
REPO = Path('/workspace/RFGRM-UltimateModFixed')
OUT = REPO/'reports'
OLD = BASE/'campaign_v4_originals/misc'
NEW = BASE/'campaign_v4/roundtrip/misc'
EXPLANATIONS = {
    'Name': 'Tên định danh; đổi tên phải cập nhật mọi tham chiếu liên quan.',
    'Category': 'Phân loại editor; không tự chứng minh phe hoặc chế độ runtime.',
    'Weapon_Class': 'Lớp xử lý vũ khí của engine; búa dùng melee_sledgehammer.',
    'Trigger_Type': 'Kiểu kích hoạt nút; single là bấm từng lần. Không phải tốc độ hoạt ảnh.',
    'Ammo_Type': 'Kiểu xử lý va chạm/đạn; melee là cận chiến.',
    'Magazine_Size': 'Số đạn một băng; schema nói bỏ qua đối với melee.',
    'Max_Rounds': 'Sức chứa đạn; schema nói bỏ qua đối với melee.',
    'Num_Magazines': 'Số băng khi vũ khí spawn, gồm cả băng đang lắp; búa không dùng đạn như súng.',
    'Ammo_Box_Restock': 'Đạn cấp tại thùng tiếp tế; búa đang là 0.',
    'Range_Max': 'Tầm tối đa NPC cố sử dụng vũ khí; không phải tầm trúng búa của Alec.',
    'Range_Red': 'Khoảng cách đổi tâm ngắm sang đỏ; không phải bán kính sát thương.',
    'Default_Refire_Delay': 'Độ trễ giữa phát bắn, ms; schema xác nhận bỏ qua cho melee/thrown.',
    'NPC_Damage': 'Nhánh sát thương NPC trong weapons; búa gốc bằng 0 và có dữ liệu melee riêng.',
    'Player_Damage': 'Nhánh sát thương lên người chơi trong weapons; búa gốc bằng 0.',
    'Vehicle_Damage': 'Nhánh sát thương xe trong weapons; -1 là giá trị đặc biệt giữ gốc, không phải đòn búa gây -1 HP.',
    'Player_Vehicle_Damage': 'Nhánh sát thương xe người chơi; -1 là giá trị đặc biệt cần giữ.',
    'Animation_Group': 'Nhóm hoạt ảnh nhân vật; búa dùng Hammer.',
    'Flag': 'Cờ hành vi; ý nghĩa tùy nhóm Flags. Xem glossary/chi tiết trong báo cáo.',
    'Min_Engagement_Distance': 'Khoảng cách giao chiến tối thiểu NPC mong muốn; không tăng tầm tay người chơi.',
    'Max_Engagement_Distance': 'Khoảng cách giao chiến tối đa NPC mong muốn; không tăng tầm tay người chơi.',
    'StandingPrimary': 'Tham chiếu đòn chính khi đứng; búa ánh xạ sang đòn ngang side.',
    'StandingTertiary': 'Tham chiếu đòn tertiary khi đứng; búa ánh xạ sang đòn dọc vert.',
    'CrouchingPrimary': 'Tham chiếu đòn chính khi ngồi/cúi; dùng nhánh side tương ứng.',
    'CrouchingTertiary': 'Tham chiếu đòn tertiary khi ngồi/cúi; dùng nhánh vert tương ứng.',
    'MovingPrimary': 'Tham chiếu opening move khi di chuyển; tên legacy có sẵn từ original.',
    'MovingSecondary': 'Tham chiếu opening move phụ khi di chuyển; chưa giải quyết đường chọn đòn runtime.',
    'Crouching': 'Tham chiếu legacy khi cúi; giữ nguyên, chưa xác minh engine ưu tiên với CrouchingPrimary.',
    'CrouchMoving': 'Tham chiếu legacy khi vừa cúi vừa di chuyển.',
    'ProneAttackPrimary': 'Tham chiếu legacy của trạng thái prone; tồn tại không chứng minh campaign sử dụng.',
    'ProneAttackSecondary': 'Tham chiếu legacy đòn phụ prone; tồn tại không chứng minh campaign sử dụng.',
    'Inventory_Item': 'Tham chiếu bản ghi vật phẩm trong inventory.',
    'Item_3d': 'Tham chiếu mesh/vật phẩm 3D; không phải chỉ số sát thương.',
    'Attachment_prop': 'Tên prop gắn/đeo vũ khí, ví dụ holster-hammer.',
    'Acceleration': 'Trường gia tốc vũ khí/projectile; búa là 0, không có bằng chứng đây là tốc độ vung.',
    'Player_Move_Speed': 'Hệ số tốc độ di chuyển khi cầm vũ khí; búa 1.01. Không phải tốc độ hoạt ảnh vung.',
    'NPC_Firing_Pattern': 'Tham chiếu mẫu sử dụng/bắn của AI.',
    'icon_name': 'Tên tài nguyên icon HUD.', 'reticule_name': 'Tên tài nguyên tâm ngắm.',
    'Max_AI_Penetrating_Distance': 'Khoảng cách AI bắn xuyên tường, chỉ áp dụng vũ khí xuyên theo schema; không phải búa dài 40m.',
    'dummy': 'Cờ bản ghi dummy MP; mặc định False.',
    'Melee_Group': 'Tham chiếu nhóm hiệu ứng va chạm theo vật liệu, không phải multiplier sát thương.',
    'Unique_ID': 'ID vũ khí; schema đặc biệt lưu ý ID MP phải duy nhất.',
    'Default_team': 'Phe mặc định của vũ khí; không quyết định vũ khí chỉ người chơi dùng.',
    'Zoom_Magnification': 'Độ phóng đại khi engine dùng zoom; không bảo đảm búa có zoom hoạt động.',
    'aim_assist': 'Hệ số hỗ trợ ngắm; schema không mô tả chi tiết cách tác động lên búa.',
    'AttackAnim': 'Tên action hoạt ảnh, như melee/melee2/melee3; tra tiếp trong player.xtbl.',
    'AttackLimb': 'Trường chi tấn công cấp MeleeMove cũ; player AnimSet có AttackPoint riêng.',
    'AttackPoint': 'Bộ phận tạo va chạm; Weapon là vị trí vũ khí, không phải tay/chân.',
    'HitRange': 'Khoảng cách xét trúng; trong SecondaryImpact là tầm kiểm tra bổ sung từ tâm controller. Không mặc định cộng với HitRadius để suy ra tầm cuối.',
    'HitRadius': 'Bán kính cầu quét va chạm, mét; không phải bán kính vụ nổ.',
    'HitHeight': 'Độ cao xét trúng; SecondaryImpact đo từ chân nhân vật, mét theo schema.',
    'ImpactForce': 'Xung lực va chạm áp lên vật thể; độc lập với HP damage.',
    'RagdollImpulse': 'Xung lực lúc bắt đầu ragdoll; tăng lực không tự bảo đảm luôn làm ngã.',
    'AwayImpulseScale': 'Hệ số thành phần hất ra xa người đánh, bổ sung lên xung lực thường.',
    'X': 'Thành phần X của vector hướng va chạm; hệ trục runtime cần xác minh.',
    'Y': 'Thành phần Y của vector hướng va chạm; không tự coi là hướng lên thế giới.',
    'Z': 'Thành phần Z của vector hướng va chạm; không tự coi là hướng lên thế giới.',
    'DefaultDamage': 'Mức sát thương chung trong Damage; các nhánh theo loại mục tiêu có cấu hình riêng. Không cộng mọi nhánh thành tổng.',
    'NPCDamage': 'Trong AnimSet/Damage là sát thương tới NPC; cấp MeleeMove/DefaultDamage là cấu hình legacy riêng.',
    'StructureDamage': 'Sát thương công trình; tăng dễ phá cột/tường và gây sập nhà gần con tin.',
    'VehicleDamage': 'Sát thương xe; không đồng nghĩa sát thương công trình hoặc NPC.',
    'PlayerDamageFromNPC': 'Sát thương tới người chơi từ NPC; V4 giảm riêng /20, không phải lực đánh của Alec.',
    'PlayerDamage': 'Trường nhận sát thương người chơi cấp legacy; V4 giảm riêng /20.',
    'OnlineDamage': 'Trường legacy liên quan online; không dùng để tăng búa offline.',
    'AnimSetName': 'Chọn bộ hoạt ảnh; Player.xtbl và Male.xtbl là các nhánh khác nhau.',
    'MinAttackDist': 'Khoảng cách tấn công AI tối thiểu của nhánh animset tương ứng.',
    'MaxAttackDist': 'Khoảng cách tấn công AI tối đa của nhánh animset tương ứng.',
    'CameraShake': 'Tên preset rung camera, không tăng sát thương vật lý.',
    'Value': 'Giá trị tùy record: tweak multiplier hoặc mã/cấp nâng cấp. Không được nhân chung mọi Value.',
    'Cost': 'Chi phí; trong upgrades là giá cấp nâng cấp, trong items_inventory là chi phí inventory riêng chưa xác nhận đường dùng campaign.',
    'Available': 'Trạng thái khả dụng trong dữ liệu; các script/unlock khác vẫn có thể tham gia.',
    'Show_Locked': 'Có hiện mục bị khóa trong giao diện hay không.',
    'Unlock_Action': 'Sự kiện/trạng thái unlock, như Unlocked/Purchased; không phải hệ số sức mạnh.',
    'Also_Unlock_Level': 'Cấp mở khóa kèm theo; không phải multiplier damage.',
    'Activity_Count': 'Điều kiện số hoạt động trong cấu hình nâng cấp; không tự giảm để tránh đổi tiến trình.',
    'Description': 'Mô tả hoặc khóa chuỗi dịch; không phải thông số combat.',
    'Upgrade_Name': 'Khóa tên nâng cấp trong giao diện.', 'Display_Name': 'Khóa tên hiển thị.',
    'Type': 'Loại nâng cấp/vật liệu/hiệu ứng tùy ngữ cảnh.',
    'Icon_Image': 'Tài nguyên icon nâng cấp.', 'Blueprint': 'Tài nguyên ảnh blueprint nâng cấp.',
    'Weapon': 'Tham chiếu vũ khí của nâng cấp.', 'Default_Count': 'Số vật phẩm inventory mặc định.',
    'Max_Inventory': 'Giới hạn số vật phẩm inventory; không phải số đòn/đạn của búa.',
    'Spin_Time': 'Thời gian quay hiển thị vật phẩm, không phải tốc độ đánh.',
    'streaming_category': 'Nhóm streaming tài nguyên.', 'Touch_Script': 'Script khi chạm/nhặt vật phẩm.',
    'Filename': 'Tham chiếu file mesh hoặc animation; dữ liệu asset thực nằm ở file khác.',
    'MaterialEffect': 'Hiệu ứng vật liệu hiển thị; tên invulnerability ở item không chứng minh Alec được bất tử.',
    'Parent': 'Nhóm animation cha để kế thừa.', 'Path': 'Đường dẫn nhóm animation/asset.',
    'Default': 'Giá trị mặc định hoặc cờ group; phụ thuộc record.',
    'Material': 'Vật liệu mặt bị đánh; dùng chọn hiệu ứng va chạm.',
    'Effect': 'Tên hiệu ứng cho vật liệu tương ứng; không tự thêm blast damage.',
    'group': 'Tên group hoạt ảnh, búa dùng Hammer.',
    'ID': 'Tên state/action của animation set; không phải tốc độ hoặc sát thương.',
    'Preload': 'Có nạp trước asset animation hay không.',
    'Frame': 'Chỉ số frame của trigger/âm thanh/IK; không tự đổi ra giây nếu chưa biết timing asset.',
    'Looping': 'Cờ lặp âm thanh/animation tùy ngữ cảnh.', 'Foley': 'Tên âm thanh foley.',
    'Line': 'Tên voice line khi vung/va chạm.', 'Enable': 'Bật/tắt IK ở frame tương ứng.',
    'Location': 'Vị trí chi dùng IK.', 'Blend': 'Thông số chuyển IK, cần giữ đồng bộ hoạt ảnh.',
    'File': 'File animation biến thể.', 'Anim_Tag': 'Điều kiện/nhãn biến thể như Forward/Air.',
    'Playstyle': 'Cách phát hoạt ảnh như Fullbody.',
    'Time': 'Trong Strength_Graph là mốc thời gian hiệu ứng; trong Variant là trường timing riêng chưa xác minh đơn vị/ý nghĩa, không phải mặc định tốc độ vung.',
    'Freq_Min': 'Tham số tần suất chọn animation variant; không phải tần số đánh búa.',
    'Freq_Max': 'Tham số tần suất chọn animation variant; không phải tần số đánh búa.',
    'Cyclic_Chance': 'Xác suất/cấu hình chọn cyclic variant, chưa xác minh chi tiết engine.',
    'Cyclic_Percentage': 'Tham số phân bổ cyclic variant.', 'Percentage': 'Trọng số/phần trăm chọn variant.',
    'Pitch': 'Thành phần rung/nghiêng camera theo trục pitch.',
    'Yaw': 'Thành phần rung/nghiêng camera theo trục yaw.', 'Roll': 'Thành phần nghiêng camera theo trục roll.',
    'Variation': 'Độ biến thiên của rung camera.', 'Frequency': 'Tần số thành phần hiệu ứng camera.',
    'Wobble': 'Biên độ/weight thành phần lắc camera.', 'Destable': 'Weight thành phần destabilization camera.',
    'Direct': 'Weight thành phần rung trực tiếp.', 'Wander': 'Weight thành phần wander camera.',
    'Wander_Direct': 'Weight thành phần wander trực tiếp.', 'Jitter': 'Weight thành phần giật/rung nhanh.',
    'Blur': 'Weight blur trong preset camera.', 'Strong_Vibration': 'Weight rung mạnh tay cầm.',
    'Weak_Vibration': 'Weight rung nhẹ tay cầm.', 'Oscillation1': 'Weight dao động camera kênh 1.',
    'Oscillation2': 'Weight dao động camera kênh 2.',
    'Owner': 'Chủ sở hữu prop/asset của sự kiện animation; Self là nhân vật hiện tại.',
    'Action': 'Hành động tạo/xóa prop tại sự kiện animation; không phải nút tấn công.',
    'Dest_Owner': 'Đối tượng nhận prop/attachment trong sự kiện animation.',
    'Dest_Tag': 'Điểm gắn đích của prop/attachment, ví dụ Mainhand.',
    'Anim_set': 'Tham chiếu animation set của vật phẩm 3D; None/none là giá trị có sẵn.',
    'Touch_Sound': 'Tên âm thanh khi chạm/nhặt vật phẩm.',
}


def csv_write(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), lineterminator='\n')
        w.writeheader(); w.writerows(rows)


def main():
    files = ['weapons.xtbl','dlc01_weapons.xtbl','melee.xtbl','dlc01_melee.xtbl',
             'upgrades.xtbl','dlc01_upgrades.xtbl','tweak_table.xtbl','dlc01_tweak_table.xtbl',
             'camera_shake.xtbl','rfg_melee_groups.xtbl','anim_groups.xtbl',
             'player.xtbl','anim_files.xtbl','dlc01_anim_files.xtbl',
             'items_3d.xtbl','dlc01_items_3d.xtbl','items_inventory.xtbl']
    rows, records, moves, upgrades, inputs = [], [], [], [], {}
    for filename in files:
        old_blob, new_blob = (OLD/filename).read_bytes(), (NEW/filename).read_bytes()
        assert old_blob == (BASE/'campaign_v4_originals/table'/filename).read_bytes()
        assert new_blob == (BASE/'campaign_v4/roundtrip/table'/filename).read_bytes()
        inputs[filename] = {'original_sha256':hashlib.sha256(old_blob).hexdigest(),
                            'v4_sha256':hashlib.sha256(new_blob).hexdigest()}
        old, new = ET.fromstring(old_blob), ET.fromstring(new_blob)
        old_map, new_map = index_elements(old), index_elements(new)
        assert old_map.keys() == new_map.keys()
        paths = {id(n):p for p,n in old_map.items()}
        parents = {id(c):p for p in old.iter() for c in p}
        selected = []
        base_name = filename.removeprefix('dlc01_')
        if base_name == 'player.xtbl':
            selected = [(n,'Hammer animation group') for n in old.iter('Group') if n.findtext('group')=='Hammer']
        elif base_name == 'anim_files.xtbl':
            selected = [(n,n.findtext('Animation/Filename')) for n in old.iter('Anim_file')
                        if 'plyr_hmr_' in (n.findtext('Animation/Filename') or '')]
        else:
            for n in old.find('Table'):
                name = n.findtext('Name') or ''
                select = False
                if base_name == 'weapons.xtbl': select = n.findtext('Weapon_Class')=='melee_sledgehammer'
                elif base_name == 'melee.xtbl': select = name.startswith('sledgehammer')
                elif base_name == 'upgrades.xtbl': select = name.startswith('sledgehammer') or name=='golden_hammer'
                elif base_name == 'tweak_table.xtbl': select = 'melee' in name.lower() or name=='Salvage_touch_delay_ms'
                elif base_name == 'camera_shake.xtbl': select = name in {'hammer_impact','hammer_alt_impact'}
                elif base_name == 'rfg_melee_groups.xtbl': select = name=='Sledgehammer'
                elif base_name == 'anim_groups.xtbl': select = name=='Hammer'
                elif base_name in {'items_3d.xtbl','items_inventory.xtbl'}:
                    select = name.startswith('sledge') or name in {'golden_hammer','mar_dlc_sledge'}
                if select: selected.append((n,name))
        for n, name in selected:
            path = paths[id(n)]
            current = new_map[path]
            records.append({'file':filename,'record':name,'path':path,
                            'original_xml':ET.tostring(n,encoding='unicode'),
                            'v4_xml':ET.tostring(current,encoding='unicode')})
            for leaf in n.iter():
                if len(leaf): continue
                leaf_path = paths[id(leaf)]
                before = (leaf.text or '').strip()
                after = (new_map[leaf_path].text or '').strip()
                context = 'shared/metadata'
                ancestor = leaf
                while id(ancestor) in parents:
                    if ancestor.tag == 'AnimSet':
                        context = ancestor.findtext('AnimSetName') or 'unknown animset'
                        break
                    ancestor = parents[id(ancestor)]
                explanation = EXPLANATIONS.get(leaf.tag)
                if filename.endswith('tweak_table.xtbl') and leaf.tag=='Value':
                    explanation = n.findtext('Description') or explanation
                if not explanation:
                    # Empty containers are explicitly represented, not values equal to zero.
                    assert not before, (filename,name,leaf.tag,before)
                    explanation = 'Container rỗng trong cấu hình; không đồng nghĩa số 0 hoặc đã bật tính năng.'
                rows.append({'file':filename,'record':name,'scope':context,'path':leaf_path,
                             'tag':leaf.tag,'original':before,'v4':after,'changed':before!=after,
                             'explanation':explanation})
            if base_name=='melee.xtbl':
                a=n.find("./MoveDataList/AnimSet[AnimSetName='Player.xtbl']")
                a4=current.find("./MoveDataList/AnimSet[AnimSetName='Player.xtbl']")
                if a is not None:
                    row={'file':filename,'move':name}
                    for route in ['Damage/DefaultDamage','Damage/NPCDamage','Damage/StructureDamage',
                                  'Damage/VehicleDamage','Damage/PlayerDamageFromNPC','HitRange','HitRadius',
                                  'ImpactForce','RagdollImpulse','AwayImpulseScale','HitHeight',
                                  'SecondaryImpact/HitRange','SecondaryImpact/HitHeight','AttackAnim','CameraShake']:
                        row['original_'+route]=a.findtext(route)
                        row['v4_'+route]=a4.findtext(route)
                    moves.append(row)
            if base_name=='upgrades.xtbl':
                old_levels=n.findall('Levels/Level'); new_levels=current.findall('Levels/Level')
                for i,(a,a4) in enumerate(zip(old_levels,new_levels),1):
                    row={'file':filename,'upgrade':name,'level_index':i}
                    for key in ['Cost','Value','Available','Show_Locked','Unlock_Action','Activity_Count','Upgrade_Name']:
                        row['original_'+key]=a.findtext(key); row['v4_'+key]=a4.findtext(key)
                    upgrades.append(row)
    csv_write(OUT/'hammer-parameters-original-v4.csv',rows)
    csv_write(OUT/'hammer-moves-original-v4.csv',moves)
    csv_write(OUT/'hammer-upgrades-original-v4.csv',upgrades)
    result={'source':'Verified originals and released Campaign V4', 'gameplay_modified':False,
            'game_runtime_tested':False,'misc_table_selected_files_identical':True,
            'input_files':inputs,'record_count':len(records),'parameter_count':len(rows),
            'records_by_file':dict(Counter(r['file'] for r in records)),
            'glossary':EXPLANATIONS,'records':records}
    (OUT/'hammer-reference-data.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in {'records','glossary','input_files'}},indent=2))


if __name__=='__main__':main()
